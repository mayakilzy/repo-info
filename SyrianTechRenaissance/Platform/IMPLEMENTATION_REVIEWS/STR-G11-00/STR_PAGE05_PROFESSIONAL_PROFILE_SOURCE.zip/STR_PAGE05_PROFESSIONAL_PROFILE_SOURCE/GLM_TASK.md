# STR-UI-05 — COPY SOURCE, BIND FUNCTIONALITY ONLY

**Status:** visual design OWNER APPROVED / FROZEN. **No redesign.**

1. Obtain the exact owner-uploaded ZIP and inspect every file.
2. Reuse the supplied `index.html`, `styles.css`, `app.js`, and `assets/` as the sole source for the member Professional Profile page. Convert HTML→JSX and JS→React state **mechanically**, preserving DOM classes, CSS selectors, color tokens, spacing, breakpoints, fonts, images and RTL/LTR placement.
3. Integrate with the existing Next.js shared AppShell. Avoid duplicating the sidebar or topbar. If the shared shell differs, use the established shared shell while preserving approved presentation and report the specific constraint; never creatively rebuild the page.
4. Wire real authenticated profile data: name, headline, location, availability, skills, experience, projects, counts, verified state, completion progress and privacy settings. Do not fabricate values or use illustrative mockup content as production data. An unverified profile must not receive a verified badge.
5. Wire the existing edit-profile, public-profile, projects and privacy routes. Enforce privacy and authorization on the server, not only in the UI. Do not invent API endpoints, schema columns or permissions.
6. Ensure Arabic `rtl` sidebar physically RIGHT and English `ltr` sidebar physically LEFT; correct Cairo/IBM Plex Sans and mobile drawer direction. Use existing next-intl messages and navigation.
7. Perform TypeScript, lint, relevant unit/integration tests and real browser E2E for desktop/tablet/mobile, AR/EN and auth/privacy edge cases. Report results truthfully.
8. **NO alternative mockups, NO visual comparison images, NO additional versions.** Do not generate any comparison assets or screenshot collages. Functional test evidence may be recorded as text; only create browser screenshots if required by an existing test policy, and do not publish design comparisons.
9. Deliver implementation PR and concise technical report. **NO MERGE, NO DEPLOY** without explicit MASTER approval.

**Standing rule:** MASTER designs and approves. GLM integrates and binds functionality. The design is frozen.
