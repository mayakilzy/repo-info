# STR — Page 05 — Professional Profile / الملف المهني

## Approved visual source package

This is the standalone implementation of the **owner-approved bilingual Professional Profile design**, with source HTML, CSS, JavaScript, illustrative local image assets and exact visual reference crops. Open `index.html` in a browser; the language toggle switches between Arabic RTL and English LTR. No framework/build step is required for the static demo.

### Files
- `index.html`: complete semantic layout and component markup.
- `styles.css`: all styling, responsive behavior and locale mirroring. Keep unchanged when integrating unless a strictly necessary mechanical adjustment is documented.
- `app.js`: complete bilingual strings and demo rendering, navigation, mobile drawer and actions.
- `assets/hero-scene.webp`: local scenic artwork derived from the approved design.
- `assets/portrait.webp`: illustrative avatar, NOT a real member photo.
- `assets/project-*.webp`: project imagery derived from the approved design.
- `assets/APPROVED_REFERENCE_AR.png` and `APPROVED_REFERENCE_EN.png`: the two portions of the approved bilingual design. These are **design references only**; do not display them as the application UI or make comparisons unless the owner explicitly asks.
- `assets/APPROVED_REFERENCE_BILINGUAL.png`: original approved image.
- `GLM_TASK.md`: integration contract.

### Strict distinction between design and data
The sample name, portrait, badges, percentages, completed project counts, experience, skills and privacy visibility are **illustrative**. They must not be represented as authenticated user facts or verified accomplishments. The developer must bind these to actual application models/services, with empty/unknown states where appropriate. Never infer a verified badge from a mockup.

### Design fidelity and limitations
This package supplies all markup, styles, strings and assets, so GLM must not creatively design the page. The approved visual image is a generated mockup rather than a browser render: exact pixel equivalence is not guaranteed by this static source. If integration reveals a difference, do not invent new artwork or change the approved composition; report only necessary mechanical differences. Cropped hero artwork is intentionally decorative and does not contain a flag.

### Functional binding
Existing authenticated profile, skills, projects, availability, privacy, verification and membership services must be inspected in the repository. The sample routes in `app.js` are visual-demo placeholders and must be mapped to real canonical routes. Access control must be enforced server-side. Keep the existing platform `AppShell` if it is the shared implementation, while preserving the supplied visual output.

### Scope
This is the member **Professional Profile** page, not a public Talent Directory profile, although it contains a button that should navigate to a public profile if authorized. No new data model, APIs or privileges are authorized by this handoff.
