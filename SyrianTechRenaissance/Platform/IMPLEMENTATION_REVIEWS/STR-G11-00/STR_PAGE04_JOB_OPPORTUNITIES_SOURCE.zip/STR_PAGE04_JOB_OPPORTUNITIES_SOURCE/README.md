# STR — Page 04: Job Opportunities / فرص العمل

**OWNER STATUS: AR + EN visual designs approved.**

This is a **standalone, source-based design handoff** for integration into the existing Syrian Tech Renaissance Next.js application. It is not a replacement app, and it does not implement server APIs.

## Contents

- `index.html` — semantic markup and fixed DOM/component hierarchy.
- `styles.css` — comprehensive CSS, responsive layout, RTL/LTR physical sidebar placement, gradients, glow, cards, spacing, typography.
- `app.js` — bilingual translations, functional search and filters, grid/list view, save UI state, dialogs, mobile menu, keyboard shortcut.
- `assets/APPROVED_REFERENCE_BILINGUAL.png` — original owner-approved combined visual reference.
- `assets/APPROVED_REFERENCE_AR.png`, `assets/APPROVED_REFERENCE_EN.png` — reference panels split for side-by-side inspection only. **Never use these whole screenshots as page backgrounds.**
- `assets/hero-scene.webp`, `assets/*.webp` — extracted decorative fragments from the reference. These do not contain full-page UI and are only temporary artwork.
- `GLM_TASK.md` — strict implementation instructions.

## Run standalone preview

From this directory: `python3 -m http.server 8080`; open `http://localhost:8080`. Default Arabic; use AR/EN switch in the topbar. No build step. Google Fonts require network access.

## Visual source of truth

The approved screenshot is the **visual acceptance reference**, and the HTML/CSS/JS files are the **implementation specification**. Use both together. The screenshot was generated as visual artwork; some decorative elements and pictorial effects cannot be recovered pixel-perfectly as independent semantic components solely from that raster image. This handoff reproduces the layout and interaction using genuine DOM/CSS; pixel-level matching must be checked by screenshot comparison. **Do not redesign or creatively reinterpret it.**

## Integration constraints

1. Inspect and reuse existing `AppShell`, Next.js route structure, authentication, next-intl and opportunity services (`getPublishedOpportunities`, `getMyApplications` or verified equivalents). Avoid duplicate shell and APIs.
2. Convert markup to React components with **minimal, mechanical changes only** (JSX attributes, state/events, i18n bindings, server data props). Preserve CSS selectors, tokens, spacing, colors, backgrounds, order, density, labels and typography.
3. Arabic: Cairo, RTL, sidebar physically RIGHT. English: IBM Plex Sans, LTR, sidebar physically LEFT. Hero sunset/fortress remains toward the right of English layout; no flag. Never flip a photograph or use a full screenshot background.
4. Real listings and stats must come from existing authenticated APIs and published records. All records and statistics in `app.js` are **fictional visual placeholders** and must not ship as live opportunities.
5. Verify publishing permission before enabling `Post a Job Opportunity`; preserve role checks, tenant boundaries, security and input validation.
6. If a reference control lacks a real backend capability, keep its exact visual appearance and show a truthful unavailable/empty state rather than inventing data or endpoints.
7. Reuse real authorized logos and images where possible; attractive neutral fallbacks are fine, but don't alter card dimensions.
8. Add accessible focus, keyboard, loading/error/empty states without altering approved normal-state appearance.
9. Test 1536×1024 desktop AR/EN, 768×1024 tablet AR/EN, 375×667 mobile AR/EN; inspect menu-open RTL/LTR, no overflow and console errors.
10. Provide actual screenshots and side-by-side comparisons, tests executed, unresolved issues, PR links and SHAs. **NO MERGE / NO DEPLOYMENT** without owner's approval.

## Design sample vs production

The sample has 4 opportunity cards, 6 KPI values and category counts that are deliberately illustrative. In production, counts must reflect the real query results and permissions. Saving a card in this standalone demo is local UI state only, not persisted. Dialogs simulate navigation without pretending to have a backend.
