# STR-UI-04 — OWNER-APPROVED SOURCE INTEGRATION (NO DESIGN AUTHORITY)

**Source package:** `STR_PAGE04_JOB_OPPORTUNITIES_SOURCE.zip`  
**Scope:** Page 04 — Job Opportunities / فرص العمل  
**Decision:** Owner approved Arabic + English visual designs.

## Your role

You are an **integration engineer, not a visual designer**. Do not create a new visual proposal, simplify cards, change typography, reposition sections, replace decorative imagery or improvise a new component system.

## Required workflow

1. Read `README.md`; inspect `index.html`, `styles.css`, `app.js` and both `APPROVED_REFERENCE_*` files.
2. Run the standalone HTML preview and capture AR/EN screenshots. Compare against the supplied approved references before touching Next.js.
3. Inspect existing platform shell, page routing, auth and opportunities APIs. Reuse them.
4. Port the approved markup and CSS to React/TypeScript as mechanically as possible. Preserve DOM structure, class names, tokens, CSS and approved responsive breakpoints. Reuse shared AppShell instead of duplicating global navigation. Only adapt the page-specific elements where needed to avoid shell duplication.
5. Replace demo records and counts with real published opportunities and authorized server data. Do not invent fields or API responses.
6. Wire search, category filters, location, type, technical field, experience, grid/list, save (only if supported), detail navigation and publishing action to verified existing capabilities. Unsupported functionality must be documented honestly.
7. Preserve bilingual text with next-intl; Cairo Arabic RTL RIGHT sidebar; IBM Plex Sans English LTR LEFT sidebar. No flag. No whole screenshot as UI background.
8. Run typecheck, lint, relevant unit/integration/E2E tests, auth and authorization tests, and desktop/tablet/mobile screenshot comparisons for AR and EN.
9. Publish evidence with screenshot links, clear visual deviations (if any), CI outcomes, SHAs and code/evidence PRs. If approved design cannot be achieved from supplied source, report the exact blocking asset or CSS issue — **do not redesign**.
10. **Do not merge or deploy** without owner's explicit approval.

## Delivery

`READY FOR OWNER REVIEW` or `PARTIAL — BLOCKERS REMAIN` with evidence.
