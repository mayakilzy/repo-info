# STR — Page 03 / My Projects — Approved Visual Source v1.0

**Status:** Visual designs approved by project owner, both Arabic RTL and English LTR.  
**Purpose:** GitHub handoff to GLM for faithful integration into the existing Next.js platform.  
**IMPORTANT:** This package is a standalone **design reference**, not production-ready application code. It includes illustrative demo data only.

## Files
- `index.html` — semantic standalone page structure.
- `styles.css` — responsive dark glass UI, Cairo/IBM Plex Sans, locale-aware sidebar.
- `app.js` — bilingual translations, interactive search/filter/sort, grid/list, mobile menu, example project detail dialog.
- `assets/APPROVED_REFERENCE_AR.png` — owner's approved Arabic design, **visual authority**.
- `assets/APPROVED_REFERENCE_EN.png` — owner's approved English design, **visual authority**.
- `assets/hero-*-scene.webp` — cropped **decorative fragments** extracted from approved visual references, not full UI screenshots.
- `assets/{education,agriculture,government,robotics,knowledge,energy}.webp` — cropped project-thumbnail fragments from approved references.

## Preview
Serve the directory with a static HTTP server, for example:
`python3 -m http.server 8080` and open `http://localhost:8080/`.
The page defaults to Arabic. Use the AR/EN button to switch language.

## Implementation instructions for GLM
1. Use the two `APPROVED_REFERENCE_*.png` images as the authoritative layout, visual-density and content references.
2. Integrate into the existing Next.js 16 / React 19 / TypeScript application using existing `AppShell`, next-intl, and shared design tokens. Reuse the approved Page 02 shell, don't duplicate it.
3. Sidebar **RIGHT** for AR RTL, **LEFT** for EN LTR. Preserve the page's dense two-column project grid on desktop and adaptive layout on tablet/mobile.
4. Build real accessible React components for hero, metrics, filters, project cards, progress, avatars and navigation; **never render the full approved reference PNG as an interface background**.
5. Use real authenticated user/project data through the existing service layer. Never ship the demo values in `app.js` as real user records. Do not invent APIs or database fields. Respect authorization and tenant/user isolation.
6. The reference image may include illustrative dates, names, projects, metrics and labels; these are **visual examples only**. Real values must come from APIs or clearly marked placeholders/empty states.
7. Use existing project creation, opportunities and detail routes; buttons in this standalone demo intentionally show dialogs instead of pretending to perform real server operations.
8. Preserve the no-flag castle requirement. Keep the castle/sunset on the **far right of the English hero** without horizontally flipping the photograph.
9. Preserve engineer/member profile photos when actual authorized images exist; provide attractive fallbacks otherwise.
10. Add loading/empty/error states and i18n translations for every label, status and action. Use `next/font/google` (Cairo + IBM Plex Sans) per platform conventions.
11. Verify desktop AR/EN (1536×1024), tablet AR/EN (768×1024), mobile AR/EN (375×667), including mobile drawer positions, keyboard accessibility, no overflow, console errors, and real authenticated project views.
12. Publish side-by-side screenshot comparisons and evidence to repo-info, create or update a dedicated Page 03 PR, **NO MERGE / NO DEPLOYMENT without owner's approval**.

## Design notes
- English approved image shows `Craft-EduBridge`; Arabic approved image displays the Syrian technical education platform. This standalone demo deliberately follows each approved visual. GLM should resolve naming against real project data rather than introduce language-dependent project identity.
- The six displayed cards are **illustrative**; the summary counts are illustrative and intentionally do not equal the number of cards in the sample. The production implementation must derive both from backend data.
- Visual fragments are cropped from generated design mockups. They are only temporary artwork; prefer original licensed artwork and real project imagery when available.
- Do not introduce the blue/green comparison footer banners from the Page 02 comparison image. This is a separate Page 03 design.
