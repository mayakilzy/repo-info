
/* STR Page 03: standalone visual/interaction reference. All sample records are DEMO DATA.
   GLM must replace with authenticated project APIs and preserve security boundaries. */
const copy={
 ar:{brandSub:"نهضة سوريا التقنية",welcome:"أهلاً وسهلاً",user:"أحمد العبدالله",workspaces:"مساحات العمل",promo:"معاً نبني مستقبل سوريا التقني",join:"انضم إلى المجتمع ←",title:"مشاريعي",heroSubtitle:"مشاريعي ومساهماتي في بناء مستقبل سوريا",heroDescription:"إدارة مشاريعك، متابعة التقدم، التعاون مع الفريق، وتحقيق الأهداف معاً.",create:"إنشاء مشروع جديد",explore:"استكشاف فرص العمل",holoTitle:"معاً نبني سوريا تقنية مستقرة ومتقدمة",close:"إغلاق",demoNotice:"واجهة مرجعية — بيانات توضيحية فقط",globalSearch:"ابحث عن مشاريع، مهندسين، فرص...",projectSearch:"ابحث في مشاريعي...",sortLabel:"الترتيب",typeLabel:"نوع المشروع",statusLabel:"الحالة",all:"الكل",active:"قيد التنفيذ",completed:"مكتملة",hold:"متوقفة مؤقتاً",draft:"مقترحات",stats:["إجمالي مشاريعي","قيد التنفيذ","مكتملة","متوقفة مؤقتاً","إجمالي أعضاء الفرق","إجمالي مساهماتي"],tabs:["الكل","قيد التنفيذ","مكتملة","متوقفة","مقترحات"],sorts:["الأحدث أولاً","الأقدم أولاً","الأعلى تقدماً","حسب الاسم"],types:["الكل","تعليم","زراعة","حكومة رقمية","روبوتات","معرفة","طاقة"],statuses:["الكل","قيد التنفيذ","مكتملة","متوقفة","مقترحات"],nav:["لوحة التحكم","مشاريعي","فرص العمل","المشاريع","المهندسون","المجتمع","التعلم والتطوير","الفعاليات","الرسائل","الإعدادات"],workspace:["مشاريعي الشخصية","فريق العمل","المشاريع المفضلة","المنظمات"],updated:"آخر تحديث",tasks:"مهام مفتوحة",members:"أعضاء",details:"عرض التفاصيل ←",noResults:"لا توجد مشاريع مطابقة للفلاتر.",newTitle:"إنشاء مشروع جديد",newText:"هذه معاينة تصميمية فقط. يجب ربط إنشاء المشاريع بنموذج Next.js المعتمد، والتحقق من صلاحيات المستخدم على الخادم.",opportunityTitle:"فرص العمل",opportunityText:"هذه معاينة تصميمية. اربط هذا الزر بصفحة فرص العمل الموجودة في المنصة.",joinTitle:"مجتمع STR",joinText:"اربط هذا الزر بمسار المجتمع الحقيقي في التطبيق.",projectType:"نوع المشروع",status:"الحالة",progress:"التقدم",sample:"بيانات توضيحية وليست بيانات حساب حقيقي"},
 en:{brandSub:"A Tech-Powered Syria",welcome:"Welcome",user:"Ahmed Abdullah",workspaces:"Workspaces",promo:"Together We Build a Tech-Powered Syria",join:"Join the Community →",title:"My Projects",heroSubtitle:"Turn Ideas Into Real Impact for Syria",heroDescription:"Manage your projects, track progress, collaborate with your team, and contribute to a brighter future.",create:"Create New Project",explore:"Explore Opportunities",holoTitle:"My Projects · Stronger Teams · A Brighter Syria",close:"Close",demoNotice:"Design reference — illustrative demo data only",globalSearch:"Search for projects, engineers, opportunities, technologies ...",projectSearch:"Search my projects ...",sortLabel:"Sort by",typeLabel:"Project Type",statusLabel:"Status",all:"All",active:"Active",completed:"Completed",hold:"On Hold",draft:"Draft",stats:["Total Projects","Active Projects","Completed","On Hold","Team Members","Total Contributions"],tabs:["All","Active","Completed","On Hold","Drafts"],sorts:["Recently Updated","Oldest First","Highest Progress","By Name"],types:["All","Education","Agriculture","Government","Robotics","Knowledge","Energy"],statuses:["All","Active","Completed","On Hold","Draft"],nav:["Dashboard","My Projects","Job Opportunities","Projects","Engineers","Community","Learning & Development","Events","Messages","Settings"],workspace:["My Workspace","My Team","Saved Projects","Organizations"],updated:"Updated",tasks:"Open Tasks",members:"Members",details:"View Details →",noResults:"No projects match your filters.",newTitle:"Create New Project",newText:"This is a design-only preview. Connect this action to the existing authenticated Next.js project creation flow with server-side authorization.",opportunityTitle:"Job Opportunities",opportunityText:"This is a design preview. Connect this action to the existing opportunities route.",joinTitle:"STR Community",joinText:"Connect this action to the real community route.",projectType:"Project Type",status:"Status",progress:"Progress",sample:"Illustrative data, not a real account"}
};
const projects=[
 {id:"edu",image:"education",type:1,status:"active",progress:68,members:8,tasks:12,date:"2026-10-20",ar:["منصة التعليم التقني السوري","منصة متكاملة لتطوير المهارات التقنية للشباب السوري","تعليم","منصة ويب","ذكاء اصطناعي"],en:["Craft-EduBridge","AI-powered learning platform for Syrian children","Education","AI","Web Platform"]},
 {id:"agri",image:"agriculture",type:2,status:"active",progress:45,members:6,tasks:12,date:"2026-10-18",ar:["النظام الذكي للزراعة المستدامة","حلول تقنية لدعم الزراعة الذكية في سوريا","زراعة","إنترنت الأشياء","تحليل بيانات"],en:["Smart Agriculture for Syria","Technology solutions for sustainable agriculture and food security","Agriculture","IoT","Data Analysis"]},
 {id:"gov",image:"government",type:3,status:"completed",progress:100,members:8,tasks:0,date:"2026-09-15",ar:["أتمتة البلديات والخدمات الحكومية","منصة مفتوحة المصدر لأتمتة عمل البلديات","حكومة رقمية","خدمات عامة","منصة ويب"],en:["Digital Government Services","Modern and efficient digital services for Syrian municipalities","Government","Civic Tech","Digital Services"]},
 {id:"robot",image:"robotics",type:4,status:"active",progress:32,members:5,tasks:19,date:"2026-10-12",ar:["مركز التدريب على الروبوتات","منصة تدريبية لبناء جيل من المهندسين في مجال الروبوتات","روبوتات","تعليم","مختبرات"],en:["Robotics Training Center","Practical training platform for Syrian engineers in robotics","Robotics","Education","Hardware"]},
 {id:"know",image:"knowledge",type:5,status:"hold",progress:60,members:9,tasks:3,date:"2026-09-01",ar:["مكتبة المعرفة والابتكار","جمع وتحليل المصادر العلمية لإنتاج أفكار وتطبيقات جديدة","ذكاء اصطناعي","بحث علمي","قاعدة معرفة"],en:["Knowledge & Innovation Library","Collecting and analyzing global knowledge to generate ideas and applications","AI","Research","Knowledge Base"]},
 {id:"energy",image:"energy",type:6,status:"draft",progress:10,members:4,tasks:2,date:"2026-10-05",ar:["نظام الطاقة المتجددة للمناطق الريفية","حلول طاقة نظيفة للمجتمعات المحلية","طاقة متجددة","استدامة","مجتمعات محلية"],en:["Renewable Energy for Rural Areas","Clean and affordable energy solutions for Syrian rural communities","Renewable Energy","Sustainability","Local Communities"]}
];
const state={lang:"ar",tab:"all",query:"",type:"all",status:"all",sort:"recent",view:"grid"};
const $=id=>document.getElementById(id);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const t=()=>copy[state.lang];
const navIcons=["⌂","▣","♧","▦","♙","♧","⬡","▦","▢","⚙"];
const workspaceIcons=["✚","♙","★","⬟"];
function renderNav(){
 $("navMain").innerHTML=t().nav.map((n,i)=>`<button class="nav-link ${i===1?"active":""}" data-nav="${i}"><span class="nav-icon">${navIcons[i]}</span>${esc(n)}</button>`).join("");
 $("navWorkspace").innerHTML=t().workspace.map((n,i)=>`<button class="nav-link" data-workspace="${i}"><span class="nav-icon">${workspaceIcons[i]}</span>${esc(n)}</button>`).join("");
}
function renderStats(){
 const nums=[12,5,4,2,28,86],icons=["⬡","▷","✓","Ⅱ","♙","★"];
 $("stats").innerHTML=nums.map((n,i)=>`<article class="stat"><span class="stat-icon">${icons[i]}</span><span><strong>${n}</strong><small>${esc(t().stats[i])}</small></span></article>`).join("");
}
const tabs=["all","active","completed","hold","draft"];
function renderFilters(){
 $("tabs").innerHTML=tabs.map((k,i)=>`<button class="tab ${state.tab===k?"active":""}" data-tab="${k}">${esc(t().tabs[i])} (${[12,5,4,2,1][i]})</button>`).join("");
 const options=(labels,values)=>labels.map((s,i)=>`<option value="${values[i]}">${esc(s)}</option>`).join("");
 $("sortSelect").innerHTML=options(t().sorts,["recent","old","progress","name"]);
 $("typeSelect").innerHTML=options(t().types,["all","1","2","3","4","5","6"]);
 $("statusSelect").innerHTML=options(t().statuses,tabs);
 $("sortSelect").value=state.sort;$("typeSelect").value=state.type;$("statusSelect").value=state.status;
 $("gridBtn").classList.toggle("active",state.view==="grid");$("listBtn").classList.toggle("active",state.view==="list");
}
function renderProjects(){
 const q=state.query.trim().toLocaleLowerCase();
 let list=projects.filter(p=>(state.tab==="all"||p.status===state.tab)&&(state.status==="all"||p.status===state.status)&&(state.type==="all"||String(p.type)===state.type)&&(!q||p[state.lang].join(" ").toLocaleLowerCase().includes(q)));
 list.sort((a,b)=>state.sort==="progress"?b.progress-a.progress:state.sort==="name"?a[state.lang][0].localeCompare(b[state.lang][0]):state.sort==="old"?a.date.localeCompare(b.date):b.date.localeCompare(a.date));
 $("projects").classList.toggle("list-mode",state.view==="list");
 $("projects").innerHTML=list.length?list.map(p=>{
 const d=p[state.lang],label={active:t().active,completed:t().completed,hold:t().hold,draft:t().draft}[p.status];
 const avatars=Array.from({length:3},(_,i)=>`<span class="member-avatar">${["👨🏻","👩🏻","👨🏽"][i]}</span>`).join("");
 return `<article class="project-card"><div class="project-image-col"><img class="project-image" src="./assets/${p.image}.webp" alt="${esc(d[0])}"><div class="members">${avatars}<span class="member-avatar member-extra">+${p.members-3}</span></div></div><div class="project-body"><div class="project-heading"><div><h3 class="project-title">${esc(d[0])}</h3><p class="project-desc">${esc(d[1])}</p></div><div><div class="project-status ${p.status}">${esc(label)} ${p.status==="completed"?"✓":p.status==="hold"?"Ⅱ":"✦"}</div><div class="project-updated">${esc(t().updated)} ${p.date}</div></div></div><div class="tags">${d.slice(2).map(tag=>`<span class="tag">${esc(tag)}</span>`).join("")}</div><div class="progress-line"><div class="progress-track"><div class="progress-fill" style="width:${p.progress}%"></div></div><b>${p.progress}%</b></div><div class="project-bottom"><div class="project-meta"><span>♧ ${p.tasks} ${esc(t().tasks)}</span><span>♙ ${p.members} ${esc(t().members)}</span></div><button class="detail-btn" data-project="${p.id}">${esc(t().details)}</button></div></div></article>`;
 }).join(""):`<div class="empty">${esc(t().noResults)}</div>`;
}
function translate(){
 const lang=state.lang,dir=lang==="ar"?"rtl":"ltr";document.documentElement.lang=lang;document.documentElement.dir=dir;
 document.title=`STR · ${t().title}`;$("localeText").textContent=lang.toUpperCase();
 document.querySelectorAll("[data-i18n]").forEach(el=>{const key=el.dataset.i18n;if(typeof t()[key]==="string")el.textContent=t()[key]});
 document.querySelectorAll("[data-placeholder]").forEach(el=>{el.placeholder=t()[el.dataset.placeholder]});
 renderNav();renderStats();renderFilters();renderProjects();
}
function showDialog(title,desc,meta=""){$("dialogTitle").textContent=title;$("dialogDescription").textContent=desc;$("dialogMeta").textContent=meta;$("projectDialog").showModal()}
function closeMenu(){document.body.classList.remove("menu-open")}
document.addEventListener("click",e=>{
 const tab=e.target.closest("[data-tab]");if(tab){state.tab=tab.dataset.tab;renderFilters();renderProjects()}
 const project=e.target.closest("[data-project]");if(project){const p=projects.find(x=>x.id===project.dataset.project);if(p)showDialog(p[state.lang][0],p[state.lang][1],`${t().progress}: ${p.progress}% · ${t().members}: ${p.members} · ${t().sample}`)}
 if(e.target.closest("[data-nav],[data-workspace]")){closeMenu();const el=e.target.closest("[data-nav],[data-workspace]");if(el.dataset.nav==="1")return;showDialog(el.textContent.trim(),t().sample)}
});
$("localeBtn").onclick=()=>{state.lang=state.lang==="ar"?"en":"ar";translate();closeMenu()};
$("themeBtn").onclick=()=>document.body.classList.toggle("soft-mode");
$("menuBtn").onclick=()=>document.body.classList.toggle("menu-open");
$("scrim").onclick=closeMenu;
$("createBtn").onclick=()=>showDialog(t().newTitle,t().newText);
$("exploreBtn").onclick=()=>showDialog(t().opportunityTitle,t().opportunityText);
$("joinBtn").onclick=()=>showDialog(t().joinTitle,t().joinText);
$("projectSearch").oninput=e=>{state.query=e.target.value;renderProjects()};
$("globalSearch").oninput=e=>{$("projectSearch").value=e.target.value;state.query=e.target.value;renderProjects()};
$("sortSelect").onchange=e=>{state.sort=e.target.value;renderProjects()};
$("typeSelect").onchange=e=>{state.type=e.target.value;renderProjects()};
$("statusSelect").onchange=e=>{state.status=e.target.value;renderProjects()};
$("resetBtn").onclick=()=>{state.tab="all";state.query="";state.type="all";state.status="all";state.sort="recent";$("projectSearch").value="";$("globalSearch").value="";renderFilters();renderProjects()};
$("gridBtn").onclick=()=>{state.view="grid";renderFilters();renderProjects()};
$("listBtn").onclick=()=>{state.view="list";renderFilters();renderProjects()};
document.addEventListener("keydown",e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="k"){e.preventDefault();$("globalSearch").focus()}if(e.key==="Escape")closeMenu()});
translate();
