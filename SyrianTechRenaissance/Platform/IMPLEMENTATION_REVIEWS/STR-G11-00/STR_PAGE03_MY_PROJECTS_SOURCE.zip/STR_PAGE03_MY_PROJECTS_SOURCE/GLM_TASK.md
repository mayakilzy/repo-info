# STR-UI-03 — My Projects — Implementation Mission

**Approved by owner:** Arabic and English Page 03 visual designs in `assets/APPROVED_REFERENCE_AR.png` and `assets/APPROVED_REFERENCE_EN.png`.

Implement `/[locale]/my-projects` or the existing canonical My Projects route using the current project architecture. First inspect existing routes/services; do not create duplicate routes or APIs.

**Non-negotiables**
- Exact bilingual visual direction and shell placement: AR sidebar right, EN sidebar left.
- English hero castle far right; no flag. No whole-image flipping.
- Preserve all approved page regions: header, hero, 6 stats, tabs/search/filters, 6 rich illustrative project cards, team avatars, progress, statuses, CTA and workspace navigation.
- Production project list must come from authenticated APIs; treat sample data as placeholders, not actual records.
- Reuse AppShell and next-intl; real React/TypeScript components, no full screenshot background.
- Wire filters, sorting, create/detail navigation to real existing capabilities; honest empty/error states where unavailable.
- Check access control and project membership visibility; no unauthorized data exposure.
- Verify AR/EN desktop, tablet and mobile with screenshot comparisons to both approved references.
- Report typecheck, lint, actual test execution, known gaps, exact Git SHA, PR URLs, evidence screenshot URLs.
- Do not merge or deploy without explicit owner permission.

**Delivery state:** READY FOR OWNER VISUAL REVIEW or PARTIAL — BLOCKERS REMAIN. Do not self-approve.
