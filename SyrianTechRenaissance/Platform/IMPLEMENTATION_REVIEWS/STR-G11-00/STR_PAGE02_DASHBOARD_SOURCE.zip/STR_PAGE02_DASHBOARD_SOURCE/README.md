# STR — PAGE 02 DASHBOARD · Approved Visual Source Package

## Purpose
A **real-element HTML/CSS/JavaScript implementation reference** of the Arabic Dashboard mockup approved by the project owner on 2026-10-22. This is a visual handoff, **not** a production-ready connected Next.js dashboard.

## Files
- `index.html`: semantic layout and sample dashboard content.
- `styles.css`: dark navy / cyan / blue / purple design tokens, responsive layouts and RTL/LTR sidebar behavior.
- `script.js`: bilingual AR/EN example, mobile menu, visual-demo interactions.
- `assets/`: decorative crops from the approved illustration; **no full-page screenshot used as an interface background**.
- `approved-dashboard-reference.png`: immutable approved full visual reference; **not loaded as a UI background**.

## Explicit rules (non-negotiable)
1. **Arabic (`lang=ar`, `dir=rtl`): sidebar is on the RIGHT.**
2. **English (`lang=en`, `dir=ltr`): sidebar is on the LEFT.**
3. Layout is controlled by logical CSS properties: `.sidebar { inset-inline-start: 0 }`, `.main-wrap { margin-inline-start: var(--sidebar) }`. DO NOT use hardcoded `right:0` in both locales, flip the entire interface, or mirror typography.
4. Arabic font **Cairo**; English font **IBM Plex Sans**.
5. The approved castle scene should have **NO FLAG**. The hero decorative crop starts below the flag; do not restore, invent, or substitute a flag.
6. Preserve panel order, all sections, five statistics, learning progress, three opportunities, three projects, featured projects, engineers, recent activity, and workspace shortcuts.
7. All displayed numbers, names, projects, opportunities and events in this static package are **illustrative mock data**. Replace with actual backend data and proper authorization checks. Never imply these are verified live values.
8. Do not implement by using the full screenshot as a single background or giant image.

## Important visual fidelity limitation
This is a hand-coded, responsive approximation of the approved generated mockup, with cropped decorative imagery from that mockup. It is **not guaranteed pixel-identical**. The approved PNG remains the authority for final appearance. Some original decorative illustrations, particularly the hero city, cannot be perfectly separated from a rasterized composite. The castle flag is excluded from the hero crop.

## How to preview
Open `index.html` in a modern browser with network access for Cairo, IBM Plex Sans, and Lucide icon library. No npm installation is needed. Toggle the language button to verify sidebar position in both languages. On mobile use the menu icon.

## Next.js integration handoff
- Implement `AppShell` using `next-intl` locale and `next/font/google` Cairo/IBM Plex Sans.
- Bind `dir` to locale at document root and keep CSS logical properties.
- Reuse existing project APIs, routes, permissions and schemas; do not invent endpoints or functionality.
- Use real components and semantic markup, preserve mobile/tablet layout, keyboard focus and reduced-motion needs.
- Compare screenshots at 1536×1024 Arabic and English, tablet 768×1024, mobile 375×667. Explicitly inspect the sidebar's physical side in each language.
- Do not merge/deploy without owner's approval. Keep Page 01 reference decisions unchanged.

## QA acceptance
- [ ] Desktop Arabic sidebar on **RIGHT**.
- [ ] Desktop English sidebar on **LEFT**.
- [ ] Tablet/mobile sidebar slides from the **correct side**.
- [ ] No castle flag.
- [ ] No full mockup image as a UI background.
- [ ] No overflow, broken icons, duplicated labels or console errors.
- [ ] All mock data replaced or explicitly marked as demo.
