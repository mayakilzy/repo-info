# STR UI-01 — Home Reference v1.1 Change Log

**Base:** v1.0 (SHA-256 `0717bdd7127535bcfdec78a5c935913ae7284a002a170d9afdb491a9dd9526d6`)
**Target:** v1.1
**Status:** GATE_B_REVIEW_PENDING

## R1 — Arabic Typography

- **Before:** `body{font:14px/1.5 system-ui,'Segoe UI',Tahoma,Arial,sans-serif}` — system fonts only.
- **After:**
  - Added `<link>` to Google Fonts: `Tajawal:wght@400;500;700;800` + `IBM Plex Sans:wght@400;500;600;700` in `index.html` `<head>`.
  - Added `<link rel="preconnect">` for `fonts.googleapis.com` and `fonts.gstatic.com`.
  - Added `--font-ar` and `--font-en` CSS variables in `:root`.
  - `body` font-family set to `var(--font-ar)` (Tajawal-first stack).
  - `html[dir="ltr"] body` font-family set to `var(--font-en)` (IBM Plex Sans-first stack).
  - `--font-mono` added (`IBM Plex Mono`).
  - `text-rendering:optimizeLegibility` + `-webkit-font-smoothing:antialiased` for sharp glyph rendering.
- **Rationale:** VLM analysis of `assets/approved-reference.png` identified Tajawal as the closest visual match (95% confidence on hero headline, 90% on sidebar nav). Tajawal is geometric sans-serif Arabic with open ع, flat-toothed س, tall straight ل — matches the approved image exactly. Both fonts are SIL OFL 1.1 (freely redistributable).

## R2 — Hero Visual Refinement

- **Before:** `.hero` overlay: `linear-gradient(90deg,#04162de8 0%,#07142cb0 40%,#06172b77 78%,#041327e0)` — alpha 0.91/0.69/0.47/0.88. Very dark.
- **After:** `linear-gradient(90deg,rgba(4,22,45,0.55) 0%,rgba(6,20,43,0.35) 45%,rgba(4,19,39,0.25) 78%,rgba(4,19,39,0.55) 100%)` — alpha 0.55/0.35/0.25/0.55. Significantly lighter to reveal hero-scene.webp.
- **Before:** `box-shadow:inset 0 -60px 60px #04101f` (rgba 1.0)
- **After:** `box-shadow:inset 0 -60px 60px rgba(4,16,31,0.65)` (alpha 0.65)
- **Hero h1 text-shadow:** kept `0 4px 14px rgba(3,16,37,0.85)` for readability.
- **Hologram opacity:** preserved at 0.96 (unchanged).
- **Result:** City + engineer + sunset visible in hero-scene.webp; headline still readable.

## R3 — Spacing and Proportions

| Element | v1.0 | v1.1 |
|---|---|---|
| `.topbar` height | 78px | 76px |
| `.hero` height | 290px | 286px |
| `.hero h1` font-size clamp | `clamp(29px,3.2vw,52px)` | `clamp(28px,3.2vw,50px)` |
| `.stats .stat` min-height | 72px | 68px |
| `.stat i` width/height | 44px | 42px |
| `.feature-heading` min-height | 85px | 80px |
| `.glow-icon` width/height | 66px | 62px |
| `.lesson-thumb` width/height | 76×48 | 70×46 |
| `.person-avatar` width/height | 46px | 44px |
| `.act-icon` width/height | 35×35 | 34×34 |
| `body` line-height | 1.5 | 1.55 |
| `.feature-heading p` line-height | 1.6 | 1.55 |
| `navLinks` gap (topbar) | 28px | 20px |

Tightened overall rhythm while preserving proportions. Side-by-side comparison shows improved balance.

## R4 — Icon System

- **Before:** Unicode glyphs and emojis (`✦ ⌂ ▱ ♧ ♙ ▣ ✺ ▦ ▤ ◇ ✧ ◈ ▥ ➜ ➤ ⬡ ϟ ↗ ⌕ ⌘`).
- **After:** Inline SVG icons in every position. Each SVG:
  - 24px viewBox (`viewBox="0 0 24 24"`)
  - 20px display size (`.ico` class) or 16px (`.ico-sm`)
  - `fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"`
  - Lucide-compatible paths (same stroke style as lucide-react used in production app)
- **Icon list (30+):** brand star, search, bell, home, projects (stack), community (people), engineers (pencil), opportunities (clipboard), learning (mortarboard), AI (sparkles), events (calendar), messages (chat), arrow-right, people (community button), star (section heading), chevron-right (lessons, persons, section view-all links), plus (workspace add), activity feed icons, stat icons, category icons.
- **Result:** No platform-dependent glyph rendering. Consistent stroke weight across all icons.

## R5 — Mobile EN-LTR Horizontal Overflow

**Root cause analysis (from STR-UI-00B diagnosis):**
1. `.header-tools` was pushed to L=405/R=437 (overflow 62px) because `.search` had `flex: 1` but no `min-width:0`, so when EN brand text was wider, the search couldn't shrink and pushed header-tools beyond viewport.
2. `.main-nav` in mobile strip was 420px wide (9 items × min-width:44px + gaps), exceeding 375px viewport.

**Fixes applied:**
1. `.app-shell { min-width: 0; overflow: hidden; }` — top-level overflow guard
2. `.app-shell @media(max-width:640px) { max-width: 100vw; overflow-x: hidden; }` — hard viewport cap at mobile
3. `.topbar { min-width: 0; }` — flex parent allows children to shrink
4. `.search { flex: 1 1 0; min-width: 0; max-width: 570px; }` — flex child can shrink
5. `.search > span { flex: 1 1 0; min-width: 0; }` — text inside search can ellipsis
6. `.sidebar @media(max-width:640px) { overflow-x: auto; overflow-y: hidden; scrollbar-width: none; }` — sidebar becomes horizontal scroll strip with hidden scrollbar
7. `.main-nav @media(max-width:640px) { flex-direction: row; width: max-content; }` — content can be wider than viewport but contained inside the scrollable sidebar
8. `.main-nav a @media(max-width:640px) { min-width: 42px; flex: none; }` — each nav item is fixed-width, allows horizontal scroll inside sidebar
9. `.profile { display: none; }` and `.notification { display: none; }` at mobile — reclaim space
10. `.brand-text { display: none; }` at mobile — only the logo mark + STR strong text remain

**NOT done:** Indiscriminate `overflow-x: hidden` on body/html (would mask legitimate layout issues elsewhere).

## R6 — Complete Static Localization

- **Before:** Only ~15 strings had `data-ar`/`data-en` attributes (hero h1/p, nav labels, search placeholder, feature panel h2s, document.title).
- **After:** All ~55 visible strings have `data-ar`/`data-en` attributes. Added:
  - demo banner text
  - brand subtitle (نهضة سوريا التقنية ↔ Syria's Tech Renaissance)
  - header profile name + subtitle
  - sidebar-title (مساحات العمل ↔ Workspaces)
  - work-nav labels (منصتي الشخصية, مشاريعي المنضم إليها, المشاريع المقترحة, المفضلة)
  - heritage-card h3 + cta
  - hero eyebrow (kept English in both)
  - hero actions (استكشف المشاريع ↔ Explore projects, انضم إلى المجتمع ↔ Join the community)
  - hologram labels (أفكار, حلول, أثر ↔ Ideas, Solutions, Impact)
  - holo-label (ابنِ, تعاون, تعلّم, انمَ ↔ Build, Collaborate, Learn, Grow)
  - hero quote (full translation)
  - all 5 stats labels
  - AI input placeholder + chips (6 strings)
  - all 6 category labels
  - explore panel cta (عرض جميع المشاريع ↔ View all projects)
  - learning levels (مبتدئ, متوسط, متقدم ↔ Beginner, Intermediate, Advanced)
  - both lesson titles + descriptions
  - all 3 project card titles + descriptions + status badges
  - all 3 engineer profile names + descriptions
  - all 4 activity feed items + demo disclaimers
  - section headings (المشاريع المميزة, المهندسون المميزون, النشاط الأخير ↔ Featured projects, Featured engineers, Recent activity)
  - view-all link text (عرض الكل ↔ View all)
  - footer text (full translation)
  - document.title (data-ar/data-en)
- **Mechanism:** `script.js` `applyLocale(loc)` swaps `innerHTML` for every `[data-ar][data-en]` element on toggle. No ad-hoc substitutions — single dictionary-driven mechanism.
- **No backend-generated content claim:** This is standalone reference only. Real Next.js integration will use next-intl with the same key set.

## R7 — Demo Data Integrity

- Demo banner visible in both locales with translated text.
- Demo data labels preserved verbatim from v1.0:
  - "بيانات عرض" / "عرض" / "demo data" / "Demo"
  - "نشاط توضيحي · ليس حياً" / "Demo activity · not live"
  - "حساب تجريبي" / "واجهة عرض" / "Demo account" / "Demo UI"
  - "ملف مهندس تجريبي" / "Demo engineer profile" etc.
- Footer updated to reference "v1.1" and "not a live product" in both locales.
- No fictional counts represented as actual platform statistics.

## R8 — Nonfunctional Controls

- **Removed:** `themeBtn` button (was in v1.0 header-tools with no behavior except setting a tooltip). Removed from `index.html` and `script.js`.
- **Marked `disabled`:** AI input button (`<button type="button" aria-label="Demo only" disabled>`) — visual-only, no click handler.
- **Preserved:** Language toggle (`#toggleLang` + `#langBtn`) — functional, switches ar↔en, rtl↔ltr.
- **No backend functionality built** — this remains a standalone visual reference.

## Files changed

| File | v1.0 bytes | v1.1 bytes | Status |
|---|---|---|---|
| `index.html` | 10,792 | (larger due to SVG icons + data attributes) | rewritten |
| `styles.css` | 14,448 | (larger due to R1/R2/R3/R5 additions) | rewritten |
| `script.js` | 1,282 | (larger due to R6 applyLocale) | rewritten |
| `README.md` | 2,289 | (rewritten for v1.1) | rewritten |
| `REFERENCE_MANIFEST.json` | 1,787 | (extended for v1.1) | rewritten |
| `CHANGELOG.md` | (new) | new file | added |
| `assets/*` | 7 files | unchanged (SHA-256 verified) | preserved |

---

# v1.2 — STR-UI-00D Regression Recovery

**Date:** 2026-10-22
**Base:** v1.1 (SHA-256 `659f463f99731b2ca546e71e1ac1f4fbe9b06f0b28458fc1f1fa7a20eb2447b2`)
**Status:** GATE_B_REVIEW_PENDING
**Trigger:** MASTER rejected v1.1 Gate B due to visible regression (skills panel empty, lower sections cut off, oversized blue arrow SVG, unbalanced feature cards).

## Root cause

A single missing CSS rule. In v1.1, inline SVGs in `.lesson > svg` and `.person > svg` (chevron-right arrows) had no width/height constraint and no `.ico`/`.ico-sm` class. Chromium let them fill the flex parent's line-height, producing:

- `.lesson > svg`: 368×368px (verified via Playwright DOM inspection)
- `.person > svg`: 274×274px

This caused cascading visual regression:

1. Each `.lesson` element grew to 387px (v1.0 was 46px).
2. `.learning-panel` grew to 931px (v1.0 was 280px) — appeared mostly empty.
3. `.feature-grid` is a CSS grid — all three panels stretched to 931px (tallest panel).
4. `.lower-grid` was pushed to `offsetTop=1418px`, outside the 1024px desktop viewport, hiding the featured projects, featured engineers, and recent activity panels from view.

## Fixes applied (minimal, surgical)

### Fix 1 — explicit SVG size constraints

```css
/* STR-UI-00D FIX — D2: SVGs inside .lesson, .person, .activity-item, .section-heading
 * must have explicit dimensions. They are inline chevrons/arrows.
 */
.lesson>svg,.person>svg,.activity-item .act-icon svg,.section-heading h2 svg,.section-heading a svg{
  width:18px;height:18px;flex:none;
  fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;
}
.lesson-thumb svg,.btn svg{width:20px;height:20px;flex:none}
```

### Fix 2 — defensive global SVG stroke style

```css
/* keep stroke style on every SVG path/rect/circle/line globally so any future
   inline SVG without .ico still inherits the Lucide-compatible stroke style */
svg:not([width]):not([height]) path,
svg:not([width]):not([height]) rect,
svg:not([width]):not([height]) circle,
svg:not([width]):not([height]) line{
  fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;
}
```

## Verification (Playwright + DOM regression tests)

| Metric | v1.0 | v1.1 (broken) | v1.2 (fixed) |
|---|---|---|---|
| SVGs >30px | 0 | 5 (368×368, 274×274) | 0 ✅ |
| `.lesson` height | 46px | 387px | 65px ✅ |
| `.learning-panel` height | 280px | 931px | 287px ✅ |
| `.feature-grid` height | 280px | 931px | 287px ✅ |
| `lower-grid` offsetTop | 580px | 1418px (outside 1024) | 774px (inside 1024) ✅ |
| `doc scrollHeight` | 1139px | 2433px | 1139px ✅ |
| Console errors | 0 | 0 | 0 ✅ |
| Page errors | 0 | 0 | 0 ✅ |
| Horizontal scroll | 0 | 0 (R5 still OK) | 0 ✅ |

All 6 viewports × 2 locales pass. DOM regression tests confirm: `lessons=2`, `featured=True (h=303)`, `engineers=True (h=303)`, `activity=True (h=303)`, `big_svgs=0`.

## Visual comparison (VLM via z-ai vision)

Triple comparison (approved | v1.1 | v1.2):

1. Skills panel lessons: **RECOVERED** — populated lessons list visible in v1.2
2. Lower sections visibility: **RECOVERED** — featured projects + engineers + activity all visible at desktop
3. Oversized SVG: **GONE**
4. Feature card balance: **BALANCED** — uniform heights
5. Tajawal font: **PRESERVED**
6. Hero image visibility: **PRESERVED & IMPROVED** (R2 kept)

**Overall VLM verdict: 9/10 — "successful fix of the v1.1 breakdown"**

## What was NOT done

- No redesign — same layout, same sections, same hierarchy
- No elements hidden to pass tests
- No `overflow:hidden` used to mask missing content
- No full page rewrite — only a single CSS rule addition + one defensive fallback
- No modification to v1.0 or v1.1 ZIPs (both preserved unchanged)
- No Next.js / React implementation

## Files changed

| File | Change |
|---|---|
| `styles.css` | Added ~16 lines: explicit SVG size rules + defensive global stroke fallback. No existing rules modified. |
| `REFERENCE_MANIFEST.json` | Updated version → 1.2-draft, added STR_UI_00D_REGRESSION_RECOVERY section, documented v1.0 + v1.1 preservation. |
| `CHANGELOG.md` | Added this v1.2 entry. |
| `index.html`, `script.js`, `README.md` | Unchanged from v1.1 |
| `assets/*` | Unchanged (SHA-256 preserved) |
