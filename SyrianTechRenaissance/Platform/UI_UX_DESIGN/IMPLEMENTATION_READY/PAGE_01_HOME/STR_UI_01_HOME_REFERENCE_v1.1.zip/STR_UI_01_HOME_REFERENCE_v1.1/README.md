# STR UI-01 — Home Dashboard Standalone Visual Reference v1.1

**Status: GATE_B_REVIEW_PENDING.** Refined over v1.0 per STR-UI-00C mission. Owner browser acceptance still pending.

## What changed from v1.0

See `CHANGELOG.md` for the full delta. Summary:

| Refinement | What |
|---|---|
| R1 — Arabic typography | Tajawal (best visual match to `assets/approved-reference.png`, VLM confidence 95%) loaded via Google Fonts. IBM Plex Sans for Latin runs. |
| R2 — Hero visual | Dark overlays reduced (0.55/0.35/0.25 from 0xb0/0xe8), hero-scene more visible, bottom inset shadow softened. |
| R3 — Spacing & proportions | Header tightened to 76px, hero to 286px, line-height 1.55, rhythm preserved. |
| R4 — Icon system | All Unicode glyphs/emoji replaced with inline SVG icons (24px viewBox, stroke-2, currentColor, Lucide-compatible paths). |
| R5 — Mobile EN-LTR overflow | Root cause: flex shrink + sidebar mobile strip width. Fixes: `min-width:0` on flex children, `.app-shell` `overflow:hidden`, sidebar `overflow-x:auto` as internal strip. |
| R6 — Complete static localization | All ~55 visible strings now carry `data-ar`/`data-en` attributes; `script.js` applies locale via `applyLocale()` which swaps `innerHTML` for every `[data-ar][data-en]` element. |
| R7 — Demo data integrity | Demo banner translated in both locales; demo data labels preserved; footer text references v1.1 and "not a live product" in both languages. |
| R8 — Nonfunctional controls | Theme button removed (was no-op in v1.0); AI input button marked `disabled` with `aria-label="Demo only"`. |

## Source of truth

- **Approved visual concept:** `assets/approved-reference.png` (1536 × 1024, SHA-256 `1066016010130adccf1338a7bac46ef5754891901f3ef88d80e3979355b1a276`)
- **Original reference package (v1.0):** `SyrianTechRenaissance/Platform/IMPLEMENTATION_REVIEWS/STR-G11-00/STR_UI_01_HOME_REFERENCE_v1.zip` — preserved unchanged
- **v1.1 location:** `SyrianTechRenaissance/Platform/UI_UX_DESIGN/IMPLEMENTATION_READY/PAGE_01_HOME/`

## Open

Open `index.html` directly in a browser (no build, backend, or network required — fonts load from Google Fonts CDN). Alternatively run `python -m http.server 8080` from this directory and open `http://localhost:8080`.

## Important limitations (carried from v1.0 + v1.1 additions)

- Visual fidelity is **not yet verified by owner**; do not call this Gate B PASS.
- All stats, names, projects, lessons, AI controls and feed are **fictional placeholders**. No live API is connected. Demo banner labels this in both locales.
- This file is a standalone reference, not Next.js/React production code.
- `themeBtn` removed in v1.1 (was no-op in v1.0; dark theme is the reference).
- Font and glyph selection uses web fonts (Tajawal + IBM Plex Sans, both SIL OFL 1.1) loaded from Google Fonts. Requires network access to fonts.googleapis.com.
- Accessibility and responsive layouts verified via Playwright — see `STR_UI_00C_REFINEMENT_REPORT.md`.

## Handoff sequence

1. v1.1 published to `repo-info/SyrianTechRenaissance/Platform/UI_UX_DESIGN/IMPLEMENTATION_READY/PAGE_01_HOME/`
2. Render at 1536 × 1024, 1440 × 900, 768 × 1024, and 390 × 844; capture Arabic and English (6 cases verified — see evidence).
3. Compare screenshot against the approved original at equivalent viewport. Record gaps and decide on further iteration.
4. Obtain explicit owner approval (Gate B). Only then task GLM to integrate into the Next.js app (Gate C).
5. Do not publish this as complete or merge without authorization.

## v1.0 preservation

The v1.0 package is **untouched**. It remains at `SyrianTechRenaissance/Platform/IMPLEMENTATION_REVIEWS/STR-G11-00/STR_UI_01_HOME_REFERENCE_v1.zip` with its original SHA-256:
`0717bdd7127535bcfdec78a5c935913ae7284a002a170d9afdb491a9dd9526d6`

The historical STR-UI-00B validation report (PR #3) remains as the v1.0 evidence record.
