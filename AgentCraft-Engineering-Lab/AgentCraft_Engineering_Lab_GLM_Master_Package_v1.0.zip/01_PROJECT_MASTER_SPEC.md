# AgentCraft Engineering Lab — Master Product Specification v1.0 (FROZEN)

## 1 Purpose and audience
Open-source, publicly hosted, hands-on learning laboratory for software engineers learning graph intelligence and observability. User explores real working examples, verifies results, records runs, and asks a context-aware textual tutor to diagnose failures. It is not a production OSINT tool, monitoring surveillance system, or general purpose app factory.

## 2 V1 functional scope
- Landing/home with Graph Lab, Observability Lab, Experiment Gallery, experiment history, Mentor panel.
- Working graph creator/editor through restricted structured input (nodes, edges, types, safe attributes), with interactive Cytoscape.js pan/zoom/select/filter/layout and clear directed edges.
- PostgreSQL relational graph baseline; NetworkX algorithms (shortest path, centralities and component analysis); Neo4j Cypher queries; GDS community algorithm when licensed/available, otherwise explicit unavailable status and local NetworkX equivalent as learning fallback, never label fallback as GDS execution.
- Observability example calls instrumented by OpenTelemetry for traces; metrics in Prometheus, trace store Tempo, Grafana dashboard including request rate/latency/errors; request failure simulations safely scoped to an experiment, no infrastructure destruction.
- Ten canonical guided/challenge experiment templates, progressively ordered; step instructions, seeded datasets, input forms, reproducible runs, expected outputs, deterministic validators, reset and export report, run comparison.
- Engineering Mentor: text-only read-only context-aware assistant; static friendly robot illustration with subtle typing-state animation. If AI provider configured, contextual answers in selected language; otherwise deterministic help diagnostics, clear provider-unavailable notice. Mentor sees sanitized inputs, results, validator output and bounded trace excerpts; must distinguish verified vs hypothesis vs insufficient evidence; no shell commands/action execution.
- English first, Arabic locale with RTL; technical symbols not translated; both languages cover navigation, lessons, guidance, errors, reports and mentor scaffolding. Guest demo sessions are unique and ephemeral; admin view/private secrets not shared.
- Modular manifests permit adding further learning modules in future without building plugin marketplace or runtime code upload in V1.

## 3 Explicit exclusions (scope guard)
No voice, avatar lip sync, humanoid avatar, marketplace, lesson auto-generation, agent swarm, login/social accounts, certificates, payments, arbitrary user code/SQL/Cypher, web crawlers, scraping or social profiling, community social features, advanced AI autonomy, multi-tenant enterprise control panel, cloud provisioning, Kubernetes, elaborate front-end animation, real OSINT datasets. Any proposal beyond these is V2 backlog only, not implemented.

## 4 Audience journey
Open demo → isolated guest session → choose gallery template → read goal/prereqs → guided steps or challenge mode → execute predefined operation with bounded parameters → inspect graph, trace or Grafana panels → validator records expected vs actual → ask mentor with attached execution context → remediate and rerun → compare runs → export Markdown/JSON report. Ten exercises seeded with synthetic engineering dataset, no personal data.

## 5 UI/UX
Calm professional responsive React design; tabs/navigation Home, Graph Lab, Observability Lab, Experiments, History. Experiment cards show difficulty, tools, approximate time, goal, expected result, start action. Stepper for guided mode; challenge shows objective and input area rather than answers. Compact persistent mentor sidebar and animated typing indication; optional simple robot SVG asset original and license-clear. Explicit statuses: not started/running/passed/failed/blocked. Data source indicator and provenance for findings. Color not sole status signal. Keyboard accessible.

## 6 Tech and architectural choices
Frontend React + TypeScript + Vite + Tailwind + i18next + Cytoscape.js. Backend Python + FastAPI + Pydantic + SQLAlchemy + Alembic + PostgreSQL + pgvector NOT needed for V1. Analysis NetworkX, Neo4j Python driver and compatible GDS community algorithm subject to license. Observability OpenTelemetry SDK/Collector + Prometheus + Tempo + Grafana; simple structured logs. Docker Compose for local/public server. No extra queue unless demonstrably required. No Qdrant or LLM embedding dependency. Adapter interface for optional model provider; no paid API needed for core curriculum.

## 7 Success criteria
All ten templates executable; pass validation on seeded correct runs; at least one deliberate failure with diagnosis and recovery; SQL/Cypher equivalent graph results; Graph rendering and query analysis; telemetry across request path; English/Arabic E2E; isolated concurrent demo sessions; bounded resources; deployable via documented Compose; reproducible CI test and release evidence. No claim of success without actual test evidence.

## 8 Governance
The scope freeze is binding. The developer may choose patch-level implementation details after checking current compatibility and recording ADR, but not introduce products/features. Correctness, tests, public safety, small code footprint, progressive value. Group gating is mandatory.
