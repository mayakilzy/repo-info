# Canonical Experiment Catalog — EXACTLY TEN V1

All fixtures synthetic and deterministic. Each card offers Guided Mode (step-by-step) and Challenge Mode (objective + inputs, no solution reveal), Reset, Rerun, Compare, Export, Ask Mentor. Exact prerequisites/service availability displayed; no mocked PASS. English primary, Arabic translations for full lesson content. Expected results are assertions, not just prose. Time estimates only indicative.

## E01 — Build Your First Graph / أنشئ أول شبكة علاقات
- Level: beginner; Technology: NetworkX + PostgreSQL; dataset: `starter-five-v1`
- Goal: Load five nodes; create directed edges; inspect Cytoscape
- Steps (implement as individually localized stepper actions): load fixture; inspect nodes; add prescribed edges; run validator; inspect visualization
- Expected output: 5 nodes and 4 typed valid links; no dangling edges
- Validator: node/edge exact count, valid endpoints and direction
- Failure mode to demonstrate: wrong/missing input or unavailable service leads FAILED/BLOCKED with a specific reason and mentor evidence.
- Acceptance: guided and challenge paths execute, validator positive/negative assertions tested, run records archived and comparable.

## E02 — Shortest Path / أقصر مسار
- Level: beginner; Technology: NetworkX; dataset: `directed-path-v1`
- Goal: Select application A and dependency T3; find shortest directed path
- Steps (implement as individually localized stepper actions): load fixture; choose endpoints; execute shortest_path; highlight; test disconnected pair
- Expected output: Known ordered path from fixture; no false path across disconnected components
- Validator: exact path length and node order; unreachable handled
- Failure mode to demonstrate: wrong/missing input or unavailable service leads FAILED/BLOCKED with a specific reason and mentor evidence.
- Acceptance: guided and challenge paths execute, validator positive/negative assertions tested, run records archived and comparable.

## E03 — Interactive Graph Explorer / استكشاف الرسم تفاعلياً
- Level: beginner; Technology: Cytoscape.js; dataset: `mixed-kind-v1`
- Goal: Change layout, filter by kind and inspect node/edge details
- Steps (implement as individually localized stepper actions): load mixed-kind graph; switch layout; filter skills; select edge; reset view
- Expected output: Correct filtered visual subgraph, original data unaffected
- Validator: rendered IDs correspond to filtered seeded IDs
- Failure mode to demonstrate: wrong/missing input or unavailable service leads FAILED/BLOCKED with a specific reason and mentor evidence.
- Acceptance: guided and challenge paths execute, validator positive/negative assertions tested, run records archived and comparable.

## E04 — SQL versus Cypher / SQL مقابل Cypher
- Level: intermediate; Technology: PostgreSQL + Neo4j; dataset: `parity-v1`
- Goal: Answer identical dependency query from two engines
- Steps (implement as individually localized stepper actions): seed both stores; run allowlisted SQL handler; run allowlisted Cypher handler; compare; inspect plan
- Expected output: Canonical same entity sets and directions, timing context displayed
- Validator: unordered canonical equality; missing backend BLOCKED
- Failure mode to demonstrate: wrong/missing input or unavailable service leads FAILED/BLOCKED with a specific reason and mentor evidence.
- Acceptance: guided and challenge paths execute, validator positive/negative assertions tested, run records archived and comparable.

## E05 — Critical Dependencies / الاعتماديات الحرجة
- Level: intermediate; Technology: NetworkX; dataset: `dependency-impact-v1`
- Goal: Detect high-impact provider via reachability and compare with centrality
- Steps (implement as individually localized stepper actions): load dependency fixture; score degree; score reachable dependents; remove provider in simulation; compare
- Expected output: Correct upstream dependency impact ranking with directed semantics
- Validator: known affected set, directed edge convention
- Failure mode to demonstrate: wrong/missing input or unavailable service leads FAILED/BLOCKED with a specific reason and mentor evidence.
- Acceptance: guided and challenge paths execute, validator positive/negative assertions tested, run records archived and comparable.

## E06 — Discover Communities / اكتشاف التجمعات
- Level: intermediate; Technology: Neo4j GDS or NetworkX fallback; dataset: `communities-v1`
- Goal: Apply community detection to synthetic clustered graph
- Steps (implement as individually localized stepper actions): probe GDS capabilities; project graph if available; run supported algorithm; show groups; explain limitations
- Expected output: Cluster memberships computed and provenance names GDS or fallback
- Validator: stable fixture cluster membership up to label permutation; provenance mandatory
- Failure mode to demonstrate: wrong/missing input or unavailable service leads FAILED/BLOCKED with a specific reason and mentor evidence.
- Acceptance: guided and challenge paths execute, validator positive/negative assertions tested, run records archived and comparable.

## E07 — Trace One Request / تتبع طلب واحد
- Level: intermediate; Technology: OpenTelemetry + Tempo; dataset: `trace-demo-v1`
- Goal: Follow request → processing → DB spans
- Steps (implement as individually localized stepper actions): start demo; capture trace id; inspect trace spans; identify slowest; report
- Expected output: Trace contains run id and ≥3 spans with duration and status
- Validator: correlated trace IDs; spans and timing positive
- Failure mode to demonstrate: wrong/missing input or unavailable service leads FAILED/BLOCKED with a specific reason and mentor evidence.
- Acceptance: guided and challenge paths execute, validator positive/negative assertions tested, run records archived and comparable.

## E08 — Build Monitoring Dashboard / لوحة المراقبة
- Level: intermediate; Technology: Prometheus + Grafana; dataset: `metrics-demo-v1`
- Goal: Observe request rate, error rate, latency over workload
- Steps (implement as individually localized stepper actions): run controlled workload; open metrics summary; inspect Prometheus/Grafana; interpret
- Expected output: Real observed metrics with time window and measurement units
- Validator: nonzero request count and bounded latency with error rate
- Failure mode to demonstrate: wrong/missing input or unavailable service leads FAILED/BLOCKED with a specific reason and mentor evidence.
- Acceptance: guided and challenge paths execute, validator positive/negative assertions tested, run records archived and comparable.

## E09 — Diagnose a Hidden Failure / تشخيص عطل خفي
- Level: advanced; Technology: OpenTelemetry + Grafana + Mentor; dataset: `failure-demo-v1`
- Goal: Use trace to find deliberately failing processing stage and rerun corrected case
- Steps (implement as individually localized stepper actions): inject allowed fail_step; inspect trace and logs; ask mentor; disable injection; rerun
- Expected output: Failed run pinpoints configured stage; corrected run passes
- Validator: diagnosis evidence matches actual stage; rerun pass
- Failure mode to demonstrate: wrong/missing input or unavailable service leads FAILED/BLOCKED with a specific reason and mentor evidence.
- Acceptance: guided and challenge paths execute, validator positive/negative assertions tested, run records archived and comparable.

## E10 — Graph and Observability Challenge / تحدي الرسم والمراقبة
- Level: advanced; Technology: Full lab stack; dataset: `integrated-challenge-v1`
- Goal: Identify faulty dependency and its operational symptom using graph plus trace
- Steps (implement as individually localized stepper actions): load integrated dependency graph; inspect paths; execute scenario; view trace; identify failure; fix and compare
- Expected output: Correct critical edge, failing step, final verified rerun
- Validator: both graph and telemetry assertions pass; report exported
- Failure mode to demonstrate: wrong/missing input or unavailable service leads FAILED/BLOCKED with a specific reason and mentor evidence.
- Acceptance: guided and challenge paths execute, validator positive/negative assertions tested, run records archived and comparable.
