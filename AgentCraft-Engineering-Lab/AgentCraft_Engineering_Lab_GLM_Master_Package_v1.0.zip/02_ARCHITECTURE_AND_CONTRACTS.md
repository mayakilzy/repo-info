# Architecture & Interface Contracts v1.0

## 1 Single-repository modular monolith
`frontend/` (React/Vite); `backend/app/` (FastAPI organized by routes/services/models); `lab-modules/graph` and `lab-modules/observability` manifest+fixtures; `infrastructure/` (Compose, OTEL Collector, Prometheus, Tempo, Grafana provisioning); `tests/`; `docs/`; `reports/` generated ignored. A single FastAPI process can run predeclared jobs synchronously for small datasets; avoid Celery and worker fleet. Backend is sole access path to databases, model provider, and telemetry. No direct secrets in client.

## 2 Canonical storage
Tables (minimum): `guest_sessions(id,created_at,expires_at)`, `experiments(id,module_id,version,manifest_digest)`, `runs(id,session_id,experiment_id,mode,status,inputs_json,outputs_json,verification_json,started_at,ended_at,trace_id,error_code)`, `run_events(id,run_id,step,status,record_json,timestamp)`. Graph sample relational: `graph_nodes(id,session_id,dataset_id,kind,label,attributes_json)`, `graph_edges(id,session_id,dataset_id,source_id,target_id,kind,attributes_json)`; unique scoped constraints, indexes on session/dataset/runs. Database migration discipline. JSON bounded, sanitize PII and secrets. All session read/writes scoped server-side, no client-provided session_id accepted as authority; IDs UUIDs. Runs immutable once terminal; rerun creates new run; reset creates clean dataset snapshot without erasing reports.

## 3 Lab module contract
Manifest schema: `id` lower snake/kebab stable; `version` semver; `title.{en,ar}`, `description.{en,ar}`, `technology[]`, `difficulty`, `estimated_minutes`, `prerequisites[]`, `dataset_key`, `steps[]` each `id`, `title.{en,ar}`, `instruction.{en,ar}`, `operation_key`, `input_schema_ref`, `expected_result`, `validator_key`; `capabilities[]`, `public_demo_enabled`, `required_services[]`. Validate on app boot against schema and duplicated IDs; fail closed on unknown operation/validator. Only allowlisted operation handlers implemented in Python, no dynamic Python import from user submissions. Manifests bundled as trusted repository files. Runtime profile and service availability surfaced to UI.

## 4 API contract (JSON, REST, stable v1)
- `GET /api/v1/health/live` and `/health/ready`: readiness includes required DB, optional services reported as degraded not masked.
- `POST /api/v1/sessions/guest` issues HttpOnly Secure SameSite=Lax cookie, CSRF defense for state changes; expiry/refresh bounded; returns public session metadata not secret.
- `GET /api/v1/modules`, `GET /api/v1/experiments`, `GET /api/v1/experiments/{id}` localized content via `?lang=en|ar` (default en).
- `POST /api/v1/experiments/{id}/runs` body `{mode: guided|challenge, inputs: validated dictionary}`; returns `{run_id,status,trace_id}` or documented validation error; no arbitrary commands.
- `GET /api/v1/runs/{id}` returns bounded run state/output/verification, scoped to cookie session.
- `GET /api/v1/runs?experiment_id=&limit=` paginated/scope-limited history.
- `POST /api/v1/runs/{id}/reset` recreates clean fixture for new run and produces auditable reset record; does not mutate existing terminal run.
- `GET /api/v1/runs/{id}/export?format=md|json` report including provenance, expected/actual, metric definitions.
- `POST /api/v1/runs/compare` two scoped run IDs; neutral relative comparisons with runtime/context warnings.
- `POST /api/v1/mentor/explain` body `{run_id,question,lang}`; only sanitised derived evidence server-generated, reply `{answer,diagnosis_state: confirmed|likely|insufficient_evidence, evidence_refs:[],next_checks:[],provider_mode}`. Enforce input lengths, quotas, no unsupported causal assertion.
- `GET /api/v1/graph/{dataset_id}` session-scoped Cytoscape nodes/edges; optional filters with bounded allowlist.
- `GET /api/v1/observability/links/{run_id}` returns safe configured dashboards or internal status, never privileged URL credentials.

All endpoints typed Pydantic contracts; standard errors `{code,message,details?,request_id}`; 400 malformed, 401 guest missing, 403 cross-session, 404 unknown, 409 invalid state, 422 validation, 429 quota, 503 unavailable service. Max request size and timeouts set; restrict CORS trusted origins. Avoid storing raw full prompts/traces containing secrets.

## 5 Execution state machine
`CREATED → RUNNING → PASSED|FAILED|BLOCKED`; terminal states immutable. Workload time budget ≤30s for small lab steps; expensive graph operations bounded by nodes/edges; dataset seed deterministic by version. On abort/timeouts produce explicit FAILED/BLOCKED with cause code; no pretending success. Each operation emits OpenTelemetry span with run_id (non-PII), experiment_id, step and outcome; never attach prompts or guest cookies to spans.

## 6 Graph semantics
Nodes: `{id,label,kind,attributes}`. Directed edges `{id,source,target,relation,attributes}` with invariant source/target existing and scoped. Example `APP_USES_TOOL` direction app → tool; `TOOL_DEPENDS_ON_TOOL` consumer → provider. Shortest path specifies directed/undirected, weight behavior; centrality metrics named unambiguously. SQL and Cypher parity use exactly same synthetic snapshot; compare canonical sets, not ordering. Do not confuse 'most central' with operational criticality. Neo4j import uses session-scoped dataset and cleanup, with reserved namespace; no arbitrary Cypher input. GDS requires supported edition/plugins and provisioning, detection by capability probe; fallback separate NetworkX computation labelled.

## 7 Observability signal pipeline
FastAPI instrumented by OTEL SDK, propagates trace context within sample operations and storage calls. OTLP → Collector → Tempo for traces, Prometheus for metrics (Collector/Prometheus metrics scrape as configured), Grafana preprovisioned datasources/dashboard. Structured JSON app logs correlate via trace_id and run_id, with least-privilege access. Failure injection only predefined parameterized simulation e.g. `sleep_ms ≤ 1500`, `fail_step=fetch|transform|persist`, inside synthetic operation; never kill real DB/containers. Dashboard indicators rate/errors/duration and service availability. Trace completeness tested across run and step spans. Separate collector exporter compatibility/ports validated in Compose; never claim Grafana stores all signals by itself.

## 8 Mentor grounding and isolation
Read-only Mentor Context Builder includes template ID/step, bounded sanitized inputs/outputs, validator status, traces/diagnostics accessible to current session, current language. Deterministic rule-based diagnostic mode available offline. Optional external LLM configurable server side; provider failure yields deterministic fallback with honest label. Prompt-injection resistance: user inputs as untrusted evidence, no secrets, no tool invocation, no elevated access. Never expose other sessions, tokens, internal URLs or host traces. Store bounded ephemeral chat by session with TTL (if storing); disabled by default if not essential.

## 9 Public safety and resource bounds
Opaque random cookie, CSRF for mutations, session TTL ≤24h, per-IP+session rate limit, API budget/LLM spend cap, data size caps (default graph ≤200 nodes/500 edges per guest dataset; output ≤256KB; question ≤2000 chars), strict origin policy, separate nonpublic admin, allowlisted modules, network restrictions, no public Neo4j/Prometheus/Tempo admin ports, no run of arbitrary Python/SQL/Cypher, cleanup expired sessions and Neo4j guest data. Guest isolation verified across API endpoints and Graph DB. Public demo should be free of privileged dashboards; embed only safely sanitized visualization, otherwise link to limited internal summaries.

## 10 Dataset fixture
Synthetic AgentCraft-style sample, NOT scraped real repos/accounts: Apps A/B/C, tools T1.., skills S1.., dependency cycle example and disconnected components. Explicit edges and precomputed expected results committed to fixture; checksum/version. Seed reproducibly, avoid implicit random graph affecting validators.
