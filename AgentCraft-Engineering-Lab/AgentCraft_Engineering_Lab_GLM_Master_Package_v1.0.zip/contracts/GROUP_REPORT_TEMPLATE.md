# GXX Implementation Report
Date (UTC):
Group / status: PASS | PASS_WITH_LIMITATION | BLOCKED | FAIL
Repository / branch / HEAD before / HEAD after / clean tracked tree:
Tasks executed (IDs) and outputs:
Changed files (count, major paths):
Test evidence: exact commands, pass/fail counts, relevant logs or links:
Acceptance gate IDs and evidence:
Screenshots or API output references (when useful):
Security and isolation evidence:
Optional integrations unavailable, honestly labelled:
Unresolved defects with severity:
Scope-change violations: NONE / details:
Next group (DO NOT START):
Reviewer decision required: APPROVE / HOLD
