# Sequential Mission Groups (8 groups / 32 tasks)

| Group | Focus | Tasks | Required gate |
|---|---|---|---|
| G01 | repo, backend/frontend and DB foundations | T01–T04 | A01 |
| G02 | relational graph, NetworkX, Cytoscape | T05–T08 | A03,A06 |
| G03 | Neo4j + Cypher + GDS conditional | T09–T12 | A04,A05 |
| G04 | instrumentation + collector + dashboards | T13–T16 | A07 |
| G05 | manifests, gallery, ten deterministic experiments | T17–T20 | A02,A09,A10 |
| G06 | i18n, tutor, run exports/history | T21–T24 | A11,A12,A13 |
| G07 | public session isolation and deployment | T25–T28 | A08,A14,A15 |
| G08 | full E2E qualification, docs and release | T29–T32 | A16 plus all |

Each group: do tasks in order, test and commit, submit `reports/GXX_report.md`, STOP for review. A prior group must pass before starting subsequent group. Design must leave hooks for upcoming groups but not implement them prematurely.
