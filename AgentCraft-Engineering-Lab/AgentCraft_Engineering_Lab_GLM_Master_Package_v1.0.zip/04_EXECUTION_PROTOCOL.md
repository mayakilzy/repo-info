# Developer Protocol, Handoffs, Scope Lock

## Group discipline
Start each group by recording HEAD, branch, git status, previous group's status, current dependencies. Work sequentially through tasks. Commit after cohesive tasks, keep working tree clean, run relevant tests. Conclude with one report `reports/GXX_report.md` and a short user-facing summary, STOP. No starting next group until reviewer sends approval. Reports are review artifacts, NOT grounds to add features.

## Constraints
Prefer smallest implementations with real outputs. Before introducing another library/service, show why existing chosen stack cannot do it; freeze additions unless required for scope correctness/security. Do not hardcode credentials, commit .env, replace production env files, or run untrusted scripts. Explicitly mark blocked environment dependencies and supply reproducible command/output. Compatible dependencies must be pinned after verification (do not fabricate versions). Treat native GDS as optional where license prevents it, keep learning outcome via labelled NetworkX fallback.

## Quality
Use Python type checking/lint and pytest, frontend TS/ESLint/Vitest, E2E Playwright, basic SAST/dependency vulnerability checks. Test every endpoint including negative cases. UI accessibility keyboard + AR RTL. Keep module boundaries small; avoid proliferation of wrappers/classes or duplicate data models. Minimum logs with request_id/trace_id. Always distinguish tested vs assumed.

## Handoff/report format
Use `contracts/GROUP_REPORT_TEMPLATE.md` including commits, file counts, exact test commands/results, acceptance gate IDs, known risks/blocks, screenshot links (if available), next group identifier. No claims 'complete' without runnable artifacts.

## GLM self-correction
If tests fail, investigate locally; retry limited 2 attempts per root cause, log fix. If architecture decision conflicts with frozen requirements, prefer spec and document ambiguity in report, do not ask end user to design. If infrastructural blocker irrecoverable, stop and report minimal unblock steps. Do not silently skip or substitute features.

## Group acceptance status
PASS: gate proofs and clean commits. PASS_WITH_LIMITATION: optional GDS/provider component unavailable, fallback disclosed and core gates satisfied. BLOCKED: essential working feature unavailable. FAIL: incorrect output/security regression. Reviewer independently decides go/no-go.
