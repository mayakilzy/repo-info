# AgentCraft Engineering Lab — GLM Execution Package

Frozen V1.0 specification and sequential implementation missions. Developer must read `00_START_HERE_GLM.md` first. This ZIP contains project planning/mission documents, NOT application source code.

**Source repository:** https://github.com/mayakilzy/AgentCraft-Engineering-Lab

- `01_PROJECT_MASTER_SPEC.md`: product scope, UX and non-goals
- `02_ARCHITECTURE_AND_CONTRACTS.md`: architecture, data/API/session/telemetry contracts
- `03_ACCEPTANCE_TEST_MATRIX.md`: objective quality gates
- `04_EXECUTION_PROTOCOL.md`: group reporting, anti-scope-creep
- `05_DEPLOYMENT_AND_OPERATIONS.md`: server, safety, maintenance
- `templates/`: ten concrete experiments
- `missions/`: index and G01–G08 (32 ordered tasks)
- `contracts/`: report template and manifest example

Delivery rule: one group at a time, group report, stop for reviewer. No silent advance. No invented test results. Permissions to push must be checked by GLM.
