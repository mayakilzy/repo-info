# Acceptance Test Matrix — release gates

All tests must run or report BLOCKED with truthful reasons. No screenshots-only proof. Unit (pytest), integration (test DB/Neo4j/collector), frontend (Vitest), E2E (Playwright), Compose smoke.

| ID | Gate | Deterministic proof |
|---|---|---|
| A01 | Repo boot | clean checkout, documented startup, health passes |
| A02 | Manifest schema | 10 unique manifests validate; malformed and unsafe operations rejected |
| A03 | Graph | seed has exact expected nodes/edges, directed paths and algorithm outputs match fixtures |
| A04 | SQL/Cypher | canonical results equal; latency comparisons label cold/warm/sample/iterations |
| A05 | GDS | capability probe and real GDS test if available; if not, BLOCKED_GDS and correctly labelled fallback, not fake PASS |
| A06 | Visualizer | filters/layout/node/edge detail responsive and accessible |
| A07 | Telemetry | traces contain API + operation spans; metrics request/error/duration visible; test controlled failure |
| A08 | Demo | two sessions cannot read/update each other's runs, datasets, export, mentor contexts; expiry enforced |
| A09 | Gallery | exactly ten ordered templates, full EN/AR objective/prereqs/steps/expectations, guided and challenge modes |
| A10 | Validation | seeded success passes; changed bad input fails; diagnostic evidence points to actual issue |
| A11 | Mentor | grounded answer includes evidence and uncertainty; offline fallback tested; no cross-session leak |
| A12 | Localization | EN default, AR full RTL, language switch persisted per session, technical labels intact |
| A13 | Report | export md/json and comparison include run ids, inputs redacted, expected/actual, timestamps, trace |
| A14 | Security | invalid input, rate limit, cookie security, CORS/CSRF, no arbitrary eval, no exposed services, dependency scan |
| A15 | Deployment | compose up clean; restart/persistence; health, resource limits, cleanup; docs and no secrets |
| A16 | Full walkthrough | 10 experiments run; failure/retry scenario demonstrates diagnostics and fixed result |

Definition of DONE: feature implemented + tests PASS + evidence reported, no known critical/security issues, documentation updated. If GDS licensing unavailable, it may be explicitly marked NOT_AVAILABLE with NetworkX lesson alternative; do not certify native GDS behavior. Measure performance, do not invent numbers.
