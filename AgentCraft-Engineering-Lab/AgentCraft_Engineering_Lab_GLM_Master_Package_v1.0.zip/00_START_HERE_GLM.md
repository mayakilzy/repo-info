# GLM — AUTHORITATIVE FIRST MESSAGE / START HERE

Project: AgentCraft Engineering Lab. Repository: https://github.com/mayakilzy/AgentCraft-Engineering-Lab
Status: V1 scope FROZEN. This package is the primary build authority. Developer: GLM. Reviewer: user forwards each group report to ChatGPT. Do not request product decisions, invent new features, or initiate unrelated repos.

## Required reading order
1. `01_PROJECT_MASTER_SPEC.md` — accepted product and scope.
2. `02_ARCHITECTURE_AND_CONTRACTS.md` — implementation choices, APIs, safety, state machine.
3. `03_ACCEPTANCE_TEST_MATRIX.md` — objective exit gates.
4. `04_EXECUTION_PROTOCOL.md` — task execution, commit and reporting policy.
5. `05_DEPLOYMENT_AND_OPERATIONS.md` — environments, public deployment.
6. `templates/EXPERIMENT_CATALOG.md` — ten canonical experiment specifications.
7. `missions/INDEX.md` then the current group document.

## Execution sequence
G01 foundation → G02 graph fundamentals → G03 Neo4j and algorithms → G04 observability → G05 gallery and validators → G06 bilingual UI and mentor → G07 isolation and deployment → G08 end-to-end qualification and release. Each contains precise numbered tasks and exit conditions. Finish ONE group, run tests, commit, produce report using `contracts/GROUP_REPORT_TEMPLATE.md`, STOP and await review. Never silently begin next group. The user does not need to instruct individual tasks. If reviewer says continue, execute next group automatically.

## Non-negotiables
No additional features, no microservices, no agents/swarm, no external scraping, no individual tracking, no shared user sessions, no unsafe code execution. Exactly ten prebuilt exercises. English default, Arabic secondary with RTL. Static AI robot avatar with minimal typing animation. Mentor text only, evidence-grounded run diagnostics, read-only. Public demo guest sessions; admin credentials private. Graph and telemetry labs must actually run (not mocked), with documented licensing/fallback if Neo4j GDS unavailable. FastAPI + React/TS; PostgreSQL, NetworkX, Cytoscape.js, Neo4j, OpenTelemetry, Prometheus, Tempo, Grafana. One repo and Compose setup, profiles allowed. Keep code compact and observable.

## First task
Verify repo state and permissions, dependency/runtime availability, and baseline (empty is expected). Execute G01. If unable to push, provide exact blocker, local commits/artifacts and no invented success. All AI keys optional and never committed; mentor must have a functional deterministic fallback when no provider configured.
