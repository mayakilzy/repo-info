# Backup & Restore Report

**J-FIX-03**

## 1. PostgreSQL backup

### Implementation (deploy.sh `backup` command)

```bash
PG_USER=$(grep -E "^POSTGRES_USER=" "$ENV_FILE" | cut -d= -f2 | tr -d '[:space:]')
PG_DB=$(grep -E "^POSTGRES_DB=" "$ENV_FILE" | cut -d= -f2 | tr -d '[:space:]')
PG_DUMP_FILE="$BACKUP_DIR/postgres-$TIMESTAMP.sql"

if $COMPOSE exec -T postgres pg_dump -U "$PG_USER" "$PG_DB" > "$PG_DUMP_FILE"; then
    if [ -s "$PG_DUMP_FILE" ] && head -1 "$PG_DUMP_FILE" | grep -q "PostgreSQL database dump"; then
        echo "  ✓ PostgreSQL backup: $PG_DUMP_FILE"
    else
        echo "  ✗ PostgreSQL backup FAILED: dump file is empty or invalid"
        rm -f "$PG_DUMP_FILE"
        exit 1
    fi
else
    echo "  ✗ PostgreSQL backup FAILED: pg_dump exited with code $?"
    rm -f "$PG_DUMP_FILE"
    exit 1
fi
```

### Correctness checks
- ✅ Uses `POSTGRES_USER` and `POSTGRES_DB` from .env (not hardcoded)
- ✅ Verifies dump is non-empty (`-s` check)
- ✅ Verifies dump starts with expected header (`grep "PostgreSQL database dump"`)
- ✅ Exits non-zero on failure (no false success)
- ✅ Removes invalid dump file on failure

### Restore procedure (documented in DEPLOY.md)
```bash
cat backups/postgres-<timestamp>.sql | docker compose exec -T postgres psql -U agentcraft agentcraft
```

## 2. Neo4j backup

### Implementation

```bash
NEO4J_CONTAINER=$($COMPOSE ps -q neo4j 2>/dev/null || echo "")
if [ -n "$NEO4J_CONTAINER" ]; then
    if $COMPOSE exec -T neo4j neo4j-admin database dump neo4j \
            --to-path=/data/dumps --overwrite-destination=true 2>/dev/null; then
        mkdir -p "$BACKUP_DIR/neo4j-$TIMESTAMP"
        docker cp "$NEO4J_CONTAINER:/data/dumps/neo4j.dump" \
            "$BACKUP_DIR/neo4j-$TIMESTAMP/neo4j-$TIMESTAMP.dump"
    fi
fi
```

### Correctness checks
- ✅ Uses `neo4j-admin database dump` (Neo4j 5.x syntax, NOT file copy)
- ✅ Writes dump to `/data/dumps` inside container (volume path)
- ✅ Copies dump out via `docker cp`
- ✅ Skips gracefully if Neo4j service not running
- ✅ Does NOT copy live database files (which would be inconsistent)

### Restore procedure (documented in DEPLOY.md)
```bash
docker compose stop neo4j
docker cp backups/neo4j-<timestamp>/neo4j-<timestamp>.dump \
    $(docker compose ps -q neo4j):/data/dumps/neo4j.dump
docker compose exec -T neo4j neo4j-admin database load neo4j \
    --from-path=/data/dumps --overwrite-destination=true
docker compose start neo4j
```

## 3. Verification levels

| Check | Status |
|---|---|
| Backup script implemented | ✅ PASS |
| PostgreSQL backup uses env vars (not hardcoded) | ✅ PASS |
| PostgreSQL backup detects failure | ✅ PASS (exit 1 + remove file) |
| Neo4j uses neo4j-admin (not file copy) | ✅ PASS |
| Neo4j skips gracefully if not running | ✅ PASS |
| Restore procedure documented | ✅ PASS (DEPLOY.md) |
| **Backup command verified (runtime)** | ❌ NOT VERIFIED (no Docker) |
| **Restore command verified (runtime)** | ❌ NOT VERIFIED (no Docker) |
| **Restore integrity tested** | ❌ NOT VERIFIED (no Docker) |

## 4. What the operator must do on the server

1. Start services: `./deploy.sh up`
2. Wait for health: `./deploy.sh status`
3. Run backup: `./deploy.sh backup`
4. Verify backup files exist in `./backups/`
5. Test restore on a non-production instance first

## 5. Verdict

- **Backup script implemented: PASS**
- **Backup command verified: NOT VERIFIED** (no Docker daemon)
- **Restore command verified: NOT VERIFIED** (no Docker daemon)
- **Restore integrity tested: NOT VERIFIED** (no Docker daemon)

The script logic is correct and uses the right tools (pg_dump, neo4j-admin database dump), but actual execution requires a running Docker environment.
