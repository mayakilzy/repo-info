# Clean Install Verification

**J-FIX-01 + J-FIX-05**

## Test environment
- Python 3.12.15
- Fresh `python3 -m venv` (no pre-installed packages)
- `pip install --upgrade pip` before each test
- SQLite (no PostgreSQL)

## Test 1: Clean editable install

```bash
cd backend
python3 -m venv /tmp/jfix_venv
source /tmp/jfix_venv/bin/activate
pip install --upgrade pip
pip install -e ".[dev]"
```

**Result: PASS**

```
Successfully installed ... agentcraft-backend-0.1.0 ...
```

All 52 packages installed from pyproject.toml:
- fastapi, uvicorn, pydantic, pydantic-settings>=2.15.0
- SQLAlchemy, alembic, psycopg2-binary, asyncpg, httpx
- PyYAML, networkx, neo4j, prometheus_client
- opentelemetry-api, opentelemetry-sdk, opentelemetry-instrumentation-fastapi, opentelemetry-instrumentation-sqlalchemy, opentelemetry-exporter-otlp-proto-http
- pytest, pytest-asyncio (dev)

## Test 2: Clean runtime install (no dev)

```bash
pip install -e .
```

**Result: PASS** (same as above minus pytest)

## Test 3: Backend import

```python
from app.main import app
from app.config import get_settings
from app.core.telemetry import trace_diagnostic
print("✓ Import OK")
```

**Result: PASS**

## Test 4: Backend tests

```bash
export DATABASE_URL="sqlite:///./test.db"
python -m pytest app/tests/ --tb=no -q
```

**Result: PASS — 363 passed in 28.13s**

## Test 5: Fresh DB init (no workaround)

```python
from app.db.session import get_engine
from app.models.base import Base
# ... import all models ...
Base.metadata.create_all(bind=get_engine())
```

**Result: PASS** — no duplicate index error

```
Indexes on guest_sessions: ['ix_guest_sessions_cookie_token', 'ix_guest_sessions_expires_at', 'sqlite_autoindex_guest_sessions_1']
```

Single `ix_guest_sessions_expires_at` (no duplicate).

## Test 6: Alembic migrations on fresh DB

```bash
alembic upgrade head
```

**Result: PASS**

```
Running upgrade  -> 0001_initial
Running upgrade 0001_initial -> 0002_purge_tasks
Tables: ['alembic_version', 'experiments', 'graph_edges', 'graph_nodes', 'guest_sessions', 'purge_tasks', 'run_events', 'runs']
```

## Test 7: Production fail-closed

```python
APP_ENV=production CORS_ORIGINS=http://localhost:5173
```

**Result: PASS** — boot aborts:
```
SESSION_COOKIE_SECURE must be true in production
CORS_ORIGINS must not contain localhost in production
POSTGRES_PASSWORD must be set to a non-default value
GRAFANA_ADMIN_PASSWORD must be set to a non-default value
```

## Test 8: CORS CSV form

```bash
CORS_ORIGINS="http://a.com,http://b.com"
```

**Result: PASS** — `['http://a.com', 'http://b.com']`

## Test 9: CORS JSON form

```bash
CORS_ORIGINS='["https://x.com","https://y.com"]'
```

**Result: PASS** — `['https://x.com', 'https://y.com']`

## Test 10: Patch on clean clone

```bash
git clone https://github.com/mayakilzy/AgentCraft-Engineering-Lab.git
cd AgentCraft-Engineering-Lab
git checkout -b test-jfix
git am --whitespace=fix agentcraft_jfix_full.patch
```

**Result: PASS** — 3 commits applied, no conflicts

Post-patch verification:
- `pip install -e ".[dev]"`: PASS
- Backend 363/363: PASS
- Frontend 17/17: PASS
- Frontend build: PASS

## Summary

| Check | Result |
|---|---|
| Clean editable install | ✅ PASS |
| Clean runtime install | ✅ PASS |
| Dependency resolution | ✅ PASS (52 packages from pyproject.toml) |
| Backend import | ✅ PASS |
| Backend tests | ✅ 363/363 PASS |
| Fresh DB init | ✅ PASS (no workaround) |
| Alembic migrations | ✅ PASS |
| Production fail-closed | ✅ PASS |
| CORS CSV | ✅ PASS |
| CORS JSON | ✅ PASS |
| Patch on clean clone | ✅ PASS |
