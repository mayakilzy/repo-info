# Issues Resolution Matrix

| ID | Issue | Root Cause | Fix | Verification |
|---|---|---|---|---|
| J-FIX-01 | `pip install -e .[dev]` fails | No `[tool.setuptools.packages.find]` in pyproject.toml; setuptools auto-discovers `app` + `alembic` and refuses | Added explicit package discovery: `include=["app*"]`, `exclude=["app.tests*"]` | Clean install in fresh venv: PASS |
| J-FIX-02 | Compose profiles in deploy.sh | `--profile "core neo4j"` is invalid; must be separate `--profile` flags | Build `PROFILE_FLAGS` array with one `--profile` per entry | `bash -n` syntax: PASS; help command: PASS |
| J-FIX-03a | PostgreSQL backup hardcoded user/db | `pg_dump -U agentcraft agentcraft` ignored env vars | Read `POSTGRES_USER`/`POSTGRES_DB` from .env; verify dump header | Script logic verified (not runtime-tested) |
| J-FIX-03b | Neo4j backup method | File copy ≠ consistent backup; must use `neo4j-admin database dump` | Use Neo4j 5.x `neo4j-admin database dump` to /data/dumps, then `docker cp` out | Script logic verified (not runtime-tested) |
| J-FIX-04a | `web` published ports to host | `ports: 8080:80` exposed frontend publicly | Switched to `expose: 80` + external `proxy-net` network for NPM | YAML validated; test updated |
| J-FIX-04b | No NPM network | Compose had only `agentcraft-net` (internal) | Added external `proxy-net` network (configurable via `NPM_NETWORK`) | YAML validated |
| J-FIX-04c | nginx missing WebSocket/SSE | No upgrade headers, no buffering control | Added WebSocket headers, `proxy_buffering off`, static caching, gzip | Config directives verified |
| Mission I-01 | CORS CSV format mismatch | pydantic-settings parsed List[str] as JSON, broke CSV | `Annotated[List[str], NoDecode]` + field_validator for CSV+JSON | CSV: PASS, JSON: PASS |
| Mission I-02 | Duplicate DB index | `index=True` on column + `Index()` in `__table_args__` | Removed `index=True`, kept explicit `Index()` | Fresh DB init: PASS, no duplicates |
| Mission I-03 | trace_id never populated | OTEL SDK not in pyproject.toml; instrument_app silently skipped | Added OTEL deps; refactored instrument_app to always install SDK | Import trace_diagnostic: PASS |
| Mission I-04 | Mentor/History no session bootstrap | Only GraphLabPage called createGuestSession | New `useGuestSession` hook; ExperimentCard calls `ensureGuestSession` | Frontend tests: 17/17 PASS |
| Mission I-05 | Kind filter hardcoded | `KINDS = ['app','tool','skill']` regardless of data | Derive `availableKinds` from loaded elements | Typecheck: PASS |
| Mission I-06 | Verdict badge no testid | Playwright selector `.status-green` didn't match | Added `data-testid="verdict-{id}"` + `run-result-{id}"` | Typecheck: PASS |
