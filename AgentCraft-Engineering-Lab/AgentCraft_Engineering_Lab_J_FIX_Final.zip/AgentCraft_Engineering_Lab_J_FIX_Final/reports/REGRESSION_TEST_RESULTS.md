# Regression Test Results

**J-FIX-05**

## 1. Backend tests

```bash
cd backend
source /tmp/jfix_venv/bin/activate
export DATABASE_URL="sqlite:///./test.db"
python -m pytest app/tests/ --tb=no -q
```

**Result: 363 passed in 28.13s**

### Test breakdown
- `test_g01_*.py` — health endpoints, modules registry
- `test_g02_*.py` — graph API
- `test_g03_*.py` — Neo4j integration (skipped when Neo4j absent)
- `test_g04_*.py` — observability wiring
- `test_g05_*.py` — experiments + runs (E01-E10)
- `test_g06_*.py` — mentor + trace_id
- `test_g07_*.py` — security + compose validation
- `test_g08_*.py` — qualification

### Previously failing tests (now PASS after Mission I fixes)
- `test_E01_full_run_via_api_passes` — trace_id now populated ✅
- `test_E07_full_run_via_api_passes` — trace_id now populated ✅
- `test_E09_full_run_via_api_diagnoses_failure` — trace_id now populated ✅
- `test_run_record_has_populated_trace_id` — trace_id now populated ✅
- `test_compose_admin_ports_not_exposed` — updated for Mission J-FIX-04 ✅

## 2. Frontend tests

```bash
cd frontend
npm run typecheck
npm test
npm run build
```

**Results:**
- TypeScript typecheck: ✅ clean (no output)
- Vitest: ✅ 17/17 PASS
  - `tests/app.test.tsx` (6 tests)
  - `tests/graph_lab.test.tsx` (6 tests)
  - `tests/experiments_page.test.tsx` (5 tests)
- Production build: ✅ clean (built in 3.00s)

## 3. Database lifecycle

### Fresh DB init (no workaround)
```python
Base.metadata.create_all(bind=engine)
```
**Result: PASS** — no duplicate index error

### Alembic migrations
```bash
alembic upgrade head
```
**Result: PASS** — 7 tables created (experiments, graph_nodes, graph_edges, guest_sessions, purge_tasks, run_events, runs + alembic_version)

## 4. Configuration validation

### Production fail-closed
```bash
APP_ENV=production CORS_ORIGINS=http://localhost:5173
```
**Result: PASS** — boot aborts with all 4 security violations listed

### CORS CSV
**Result: PASS** — `['http://a.com', 'http://b.com']`

### CORS JSON
**Result: PASS** — `['https://x.com', 'https://y.com']`

## 5. Patch on clean clone

```bash
git clone https://github.com/mayakilzy/AgentCraft-Engineering-Lab.git
cd AgentCraft-Engineering-Lab
git checkout -b test-jfix
git am --whitespace=fix agentcraft_jfix_full.patch
```

**Result: PASS** — 3 commits applied, no conflicts

### Post-patch verification
- `pip install -e ".[dev]"`: ✅ PASS
- Backend 363/363: ✅ PASS
- Frontend 17/17: ✅ PASS
- Frontend build: ✅ PASS

## 6. What was NOT tested

| Capability | Status |
|---|---|
| Docker image build | NOT VERIFIED |
| Compose service startup | NOT VERIFIED |
| E01-E10 with real backend + Docker | NOT VERIFIED |
| Playwright UI regression | NOT VERIFIED (frontend tests cover the same paths) |
| Session isolation with real cookies | NOT VERIFIED (unit tests cover the logic) |
| Observability with real OTEL/Prometheus/Tempo | NOT VERIFIED |
| Neo4j + GDS plugin | NOT VERIFIED |
| NPM HTTPS proxy | NOT VERIFIED |

## 7. Summary

| Suite | Result |
|---|---|
| Backend pytest | 363/363 PASS |
| Frontend vitest | 17/17 PASS |
| Frontend typecheck | PASS |
| Frontend build | PASS |
| Fresh DB init | PASS |
| Alembic migrations | PASS |
| Production fail-closed | PASS |
| CORS CSV + JSON | PASS |
| Patch on clean clone | PASS |
| Docker runtime | NOT VERIFIED |
