# NPM Network Verification

**J-FIX-04**

## 1. Network configuration

### docker-compose.yml networks section

```yaml
networks:
  agentcraft-net:
    driver: bridge
  proxy-net:
    external: true
    name: ${NPM_NETWORK:-agentcraft-proxy}
```

### web service networks

```yaml
  web:
    # ...
    expose:
      - "80"
    networks:
      - agentcraft-net        # internal: web → api
      - ${NPM_NETWORK:-agentcraft-proxy}  # external: NPM → web
```

## 2. Correctness checks

| Check | Status |
|---|---|
| External network name configurable via `NPM_NETWORK` | ✅ PASS |
| Default network name: `agentcraft-proxy` | ✅ PASS |
| `web` on both `agentcraft-net` (internal) and `proxy-net` (NPM) | ✅ PASS |
| `web` uses `expose: 80` (not `ports: 8080:80`) | ✅ PASS |
| `api` only on `agentcraft-net` (NOT on proxy-net) | ✅ PASS |
| `postgres` only on `agentcraft-net` | ✅ PASS |
| `neo4j` only on `agentcraft-net` | ✅ PASS |
| Only `grafana:3000` publicly exposed (admin auth) | ✅ PASS |

## 3. NPM setup procedure (documented in DEPLOY.md)

### Step 1: Create external network (one-time)
```bash
docker network create agentcraft-proxy
```

### Step 2: Attach NPM to the network
Add to NPM's docker-compose.yml:
```yaml
networks:
  agentcraft-proxy:
    external: true
services:
  app:
    networks:
      - default
      - agentcraft-proxy
```

### Step 3: Create Proxy Host in NPM UI
- Domain: `your-domain.example.com`
- Scheme: `http`
- Forward Hostname: `web` (Docker service name)
- Forward Port: `80`
- Websockets: ✓
- SSL: Let's Encrypt + Force SSL + HTTP/2

## 4. nginx config (inside web container)

```nginx
# SPA routing
location / {
    try_files $uri $uri/ /index.html;
}

# /api proxy to backend
location /api/ {
    proxy_pass http://api:8000;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_buffering off;
}

# Block /metrics
location /metrics {
    deny all;
    return 403;
}
```

## 5. Forwarded headers chain

```
Client → NPM (TLS termination) → web:80 (nginx) → api:8000 (FastAPI)
         sets X-Forwarded-*      passes through    reads X-Forwarded-Proto
```

- NPM terminates TLS, sets `X-Forwarded-Proto=https`
- web's nginx passes `X-Forwarded-Proto $scheme` to api
- FastAPI sees `X-Forwarded-Proto=https` → `SESSION_COOKIE_SECURE=true` works

## 6. Verification levels

| Check | Status |
|---|---|
| Network configuration | ✅ PASS (YAML validated) |
| Proxy routing configuration | ✅ PASS (nginx directives verified) |
| Environment consistency | ✅ PASS (NPM_NETWORK configurable) |
| HTTPS/cookie configuration review | ✅ PASS (Secure cookies behind proxy) |
| **Real HTTPS proxy test** | ❌ NOT VERIFIED (no NPM + no domain) |

## 7. What the operator must verify on the server

1. `docker network create agentcraft-proxy`
2. `./deploy.sh up`
3. `docker network inspect agentcraft-proxy` — verify both NPM and web are attached
4. In NPM UI: create proxy host → `web:80`
5. `curl -I https://your-domain.example.com` — expect HTTP/2 200
6. `curl https://your-domain.example.com/api/v1/health/live` — expect `{"status":"ok"}`

## 8. Verdict

- **Network configuration: PASS** (YAML + external network + dual-network web)
- **Proxy routing configuration: PASS** (nginx /api proxy + SPA fallback + /metrics block)
- **Environment consistency: PASS** (NPM_NETWORK env var)
- **HTTPS/cookie configuration review: PASS** (Forwarded headers + Secure cookies)
- **Real HTTPS proxy test: NOT VERIFIED** (requires NPM + domain + server)
