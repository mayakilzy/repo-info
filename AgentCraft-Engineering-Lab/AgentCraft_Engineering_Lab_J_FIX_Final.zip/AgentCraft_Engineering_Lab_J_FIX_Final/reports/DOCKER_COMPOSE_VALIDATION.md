# Docker Compose Validation

**J-FIX-02**

## 1. YAML validity

```python
import yaml
compose = yaml.safe_load(open('docker-compose.yml'))
```

**Result: PASS** — valid YAML

## 2. Services + profiles

| Service | Profile | Purpose |
|---|---|---|
| postgres | core | PostgreSQL database |
| api | core | FastAPI backend |
| web | core | Nginx + Vite build (frontend) |
| purge-cron | core | Scheduled cleanup |
| neo4j | neo4j | Neo4j + GDS plugin |
| otel-collector | observability | OTEL collector |
| prometheus | observability | Metrics |
| tempo | observability | Traces |
| grafana | observability | Dashboards |
| test-runner | test | CI smoke tests |

## 3. deploy.sh validation

### Shell syntax
```bash
bash -n deploy.sh
```
**Result: PASS**

### Command paths tested
| Command | .env required | Result |
|---|---|---|
| `help` | No | ✅ Prints usage, exit 0 |
| `--help` | No | ✅ Same as help |
| `-h` | No | ✅ Same as help |
| (no arg) | No | ✅ Prints usage, exit 0 |
| `badcmd` | No | ✅ "Unknown command", exit 1 |
| `up` | Yes | ✅ "ERROR: .env not found" if missing |
| `down` | Yes | ✅ Same |
| `status` | Yes | ✅ Same |
| `logs` | Yes | ✅ Same |
| `backup` | Yes | ✅ Same |
| `update` | Yes | ✅ Same |
| `migrate` | Yes | ✅ Same |
| `test-runner` | Yes | ✅ Same |

### Profile flags construction
```bash
PROFILES="core neo4j observability"
PROFILE_FLAGS=()
for p in $PROFILES; do
  PROFILE_FLAGS+=("--profile" "$p")
done
# Result: --profile core --profile neo4j --profile observability
```

**Correct syntax** — Docker Compose requires separate `--profile` flags, not a single space-joined argument.

### Backup logic (J-FIX-03)

**PostgreSQL:**
- Reads `POSTGRES_USER` and `POSTGRES_DB` from .env (not hardcoded)
- Runs `pg_dump -U $PG_USER $PG_DB`
- Verifies dump is non-empty AND starts with "PostgreSQL database dump"
- Exits non-zero on failure
- Removes invalid dump file

**Neo4j:**
- Checks if neo4j container is running (`docker compose ps -q neo4j`)
- Uses `neo4j-admin database dump neo4j --to-path=/data/dumps` (Neo4j 5.x syntax)
- Copies dump out via `docker cp`
- Skips gracefully if service not running

## 4. What was NOT runtime-tested

| Capability | Status |
|---|---|
| `docker compose up` actual execution | NOT VERIFIED (no Docker) |
| `docker compose build` | NOT VERIFIED |
| `docker compose exec` | NOT VERIFIED |
| `pg_dump` actual execution | NOT VERIFIED |
| `neo4j-admin database dump` | NOT VERIFIED |
| `docker cp` | NOT VERIFIED |
| Health checks | NOT VERIFIED |
| Volume persistence | NOT VERIFIED |

## 5. Verdict

- **Shell syntax: PASS**
- **Compose configuration consistency: PASS** (YAML valid, profiles correct)
- **Profiles invocation: PASS** (separate --profile flags)
- **Script command validation: PASS** (all paths tested)
- **Actual Docker execution: NOT VERIFIED** (no Docker daemon in env)
