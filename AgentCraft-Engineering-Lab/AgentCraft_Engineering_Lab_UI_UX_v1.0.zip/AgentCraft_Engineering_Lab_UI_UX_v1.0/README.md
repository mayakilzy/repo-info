# AgentCraft Engineering Lab — UI/UX Reference v1.0

A **standalone, inspectable frontend design reference**, based on the approved mockup and the supplied Engineering Lab README. It is **not a drop-in replacement** for the existing app until integrated with its real API, existing i18next resources, Cytoscape.js and backend sessions.

## Run the visual reference

```bash
npm install
npm run dev
npm run build
```

All sample data is explicitly marked **PREVIEW DATA**. The reference does not execute real experiments, create accounts, impersonate the AI mentor, or fabricate telemetry. It includes ten experiment definitions matching E01–E10, EN/AR, RTL/LTR, light/dark, responsive layout and ten navigable UI views.

**Important:** This reference uses lightweight SVG to illustrate the graph visual style. The production application must **retain and integrate its real Cytoscape.js component** rather than substitute SVG for graph exploration.

See `docs/INTEGRATION_HANDOFF.md`, `docs/DESIGN_SPEC.md`, `docs/GLM_5_2_ONLINE_MISSION.md`, and `docs/ACCEPTANCE_MATRIX.md`.
