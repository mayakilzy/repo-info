export type Experiment={id:string;title:string;ar:string;level:string;minutes:number;kind:string;desc:string};
export const experiments:Experiment[]=[
{id:'E01',title:'Build Your First Graph',ar:'أنشئ أول رسم بياني',level:'Beginner',minutes:20,kind:'graph',desc:'Graph modeling and directed-edge integrity'},
{id:'E02',title:'Shortest Path',ar:'أقصر مسار',level:'Beginner',minutes:20,kind:'graph',desc:'Directed shortest path and unreachable nodes'},
{id:'E03',title:'Interactive Graph Explorer',ar:'مستكشف الرسوم البيانية',level:'Beginner',minutes:25,kind:'graph',desc:'Layouts, filters and node inspection'},
{id:'E04',title:'SQL versus Cypher',ar:'مقارنة SQL و Cypher',level:'Intermediate',minutes:25,kind:'database',desc:'Canonical query parity and timing context'},
{id:'E05',title:'Critical Dependencies',ar:'الاعتماديات الحرجة',level:'Intermediate',minutes:25,kind:'graph',desc:'Reachability impact versus centrality'},
{id:'E06',title:'Discover Communities',ar:'اكتشاف المجتمعات',level:'Intermediate',minutes:25,kind:'graph',desc:'Louvain or clearly identified NetworkX fallback'},
{id:'E07',title:'Trace One Request',ar:'تتبع طلب',level:'Intermediate',minutes:25,kind:'trace',desc:'Distributed tracing and span correlation'},
{id:'E08',title:'Build Monitoring Dashboard',ar:'بناء لوحة مراقبة',level:'Intermediate',minutes:25,kind:'metrics',desc:'Rates, latency and P50/P95'},
{id:'E09',title:'Diagnose a Hidden Failure',ar:'تشخيص عطل خفي',level:'Advanced',minutes:30,kind:'trace',desc:'Bounded failure injection and recovery'},
{id:'E10',title:'Graph and Observability Challenge',ar:'تحدي الرسوم والمراقبة',level:'Advanced',minutes:40,kind:'challenge',desc:'Integrated graph and telemetry investigation'}];
export const nav=[['home','Home','الرئيسية'],['experiments','Experiments','التجارب'],['experiment','Experiment Workbench','مختبر التجربة'],['graph','Graph Explorer','مستكشف الرسم'],['observability','Observability','المراقبة'],['mentor','AI Mentor','المرشد الذكي'],['results','Results & Timeline','النتائج والسجل'],['environment','Lab Environment','بيئة المختبر'],['notes','Notes','الملاحظات'],['settings','Settings','الإعدادات']] as const;
