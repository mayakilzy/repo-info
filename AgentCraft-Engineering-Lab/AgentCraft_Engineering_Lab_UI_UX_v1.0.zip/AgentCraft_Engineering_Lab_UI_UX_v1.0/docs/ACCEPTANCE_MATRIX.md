# Acceptance matrix

| Area | Acceptance evidence |
|---|---|
| Manifest gallery | All E01–E10 loaded from real backend; correct bilingual titles |
| Guided / Challenge | Both modes behave per backend; Challenge does not leak solution |
| Run execution | Run state and step verdicts match server records; BLOCKED preserved |
| Graph | Cytoscape four layouts, kind filter, node/edge inspect, keyboard |
| Mentor | Evidence refs + confidence + no unsupported causal claims |
| Results | Session-scoped history, rerun, compare, md/json export |
| Observability | Trace IDs link to actual Tempo/Grafana, metrics real or unavailable |
| Security | HttpOnly guest cookies, cross-session 404, rate limits, redaction |
| Localization | English + Arabic RTL, technical keys untranslated |
| Browser | Chromium DOM interaction, no console errors or overflow at 1440×900 and 390×844 |
| Production | Existing Docker/Nginx routing, CI, security validation preserved |
| Delivery | Branch + SHA + GitHub push confirmation, screenshot ZIP, truthful report |

No acceptance row may be marked PASS without observed evidence.
