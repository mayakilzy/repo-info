# Integration contract — preserve existing architecture

1. Inspect the actual repository and identify `frontend/` React 18, TypeScript, Vite, Tailwind, i18next, Cytoscape, API client, routing and backend FastAPI endpoints. Do not overwrite files blindly.
2. Map each new view to existing routes/components. Preserve manifest-driven experiment discovery, guided/challenge, session-scoped runs, comparison/export, grounded mentor, graph viewer, OTEL/Grafana links.
3. Replace sample `experiments` array with the actual bilingual YAML-manifest-derived API data. Keep operation and validator keys untranslated.
4. Replace `demoRuns` and preview-only labels with real session-scoped API responses; keep truthful empty/error/blocked states. Never infer `PASSED` from a successful HTTP request alone.
5. Reuse existing Cytoscape.js (four layouts, kind filtering, selection panels, keyboard accessibility). The sample SVG is a visual placeholder ONLY.
6. Reuse i18next locale files and guest HttpOnly SameSite session handling. No login/signup/account flows. No client-side session_id trust.
7. Do not claim Grafana, Tempo, Neo4j, GDS or Prometheus is healthy without a real probe. Label NetworkX fallback as fallback.
8. Maintain security invariants, rate limits, production config checks, input redaction and export provenance.
9. Use existing API contracts; never guess endpoint URLs. If an adapter is essential, add minimal typed client glue.
10. Validate against baseline 363 backend + 17 frontend tests from supplied README; actual current counts may differ.

## Page-to-capability map

- Home: manifests + session-scoped recent runs and counts.
- Experiments: ten real manifests, levels, localization, metadata.
- Experiment Workbench: guided/challenge, step inputs, validators, run lifecycle, evidence.
- Graph Explorer: existing Cytoscape and graph API.
- Observability: real metrics/traces/Grafana links; absent services BLOCKED/UNAVAILABLE.
- AI Mentor: deterministic read-only run-evidence Q&A, confidence confirmed/likely/insufficient_evidence.
- Results: run history, compare, reset/rerun, md/json exports.
- Lab Environment: real health/dependency status where supported.
- Notes: local-only optional UI affordance; do not imply server persistence.
- Settings: language, theme, guest-session preferences only.

## Online GLM 5.2 caveat

The GLM chat environment may have no local filesystem, shell, Chromium, public ports, or persistent preview URL. Verify tool availability BEFORE claiming live preview. When unavailable, use the GitHub repository via supported connector/clone and a real accessible preview deployment only with explicit authorized setup. Otherwise provide code commits, screenshots if tooling exists, and reproducible local commands; never claim a localhost link works on the user's machine.
