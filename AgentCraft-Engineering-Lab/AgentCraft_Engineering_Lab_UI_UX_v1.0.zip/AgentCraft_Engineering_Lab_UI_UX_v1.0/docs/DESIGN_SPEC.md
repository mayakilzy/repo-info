# Approved visual system

Reference image: `references/approved_visual_reference.png`. The picture is an aesthetic reference, not a specification of real capabilities or metrics.

- Sidebar: deep navy `#0e2746` → `#162f54`, 252 px desktop.
- Primary action: `#1764e9`; background `#f4f7fc`; white card surfaces; 13 px card radius; soft borders.
- Typography: Inter for English, Cairo for Arabic; maintain readable code/IDs LTR.
- Layout: top navigation, experiment gallery, card-based dashboard, split workbench, evidence-grounded mentor, run timeline.
- Screen states: initial, loading, empty, running, passed, failed, blocked, unavailable, permission/session expired, network disconnected.
- Responsive reference widths: 1440×900 and 390×844, plus 768px tablet.
- Accessibility: keyboard focus, semantic labels, non-color verdict cues, reduced-motion preference, RTL and mixed-script handling.

## Corrections to the visual collage

The mockup's login/password screen is NOT part of v1.0: guest HttpOnly cookie sessions are authoritative. The collage contains invented experiment titles and sample statistics: production must use the real ten canonical manifests and real run evidence. The mockup's apparent LLM mentor is NOT a claim that a generative LLM is implemented; current mentor is deterministic and evidence-grounded. Do not expose unsafe reset-all or server management actions absent backend support.
