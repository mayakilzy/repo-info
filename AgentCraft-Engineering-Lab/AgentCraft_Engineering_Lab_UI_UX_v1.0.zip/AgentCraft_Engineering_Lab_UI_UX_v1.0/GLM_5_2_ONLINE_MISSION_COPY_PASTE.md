# GLM 5.2 ONLINE — AgentCraft Engineering Lab UI Replacement

## Role and objective
You are the implementation engineer. Replace the existing Engineering Lab frontend's outdated appearance with the approved design package while retaining all current product behavior. Do not deliver a disconnected demo as production. Repository: https://github.com/mayakilzy/AgentCraft-Engineering-Lab . User will attach or make available `AgentCraft_Engineering_Lab_UI_UX_v1.0.zip` in this GLM chat; read it fully first.

## Phase 0: establish actual access (MANDATORY)
1. Check whether this GLM 5.2 online chat has access to GitHub repository contents, file editing, git push, terminal/shell, browser/Chromium, Playwright, and a shareable preview URL. Do not assume online chat equals local ZCode.
2. Inspect current repository tree, frontend routes/components, API schemas, i18next files, Cytoscape implementation, tests and Docker/Nginx deployment. Record branch and starting SHA.
3. Extract/read ZIP. The package is a design reference, not an already-integrated production app. Inspect and test it; adapt rather than overwrite architecture.
4. If repo write access, executable tools, or preview hosting are absent, report the exact missing capability; prepare precise patch files and integration instructions rather than claiming execution or remote changes. Do not invent tool results, URLs or screenshots.

## Phase 1: UI shell and fidelity
Implement shared deep-navy sidebar, top bar, Inter/Cairo typography, tokens, responsive cards, mobile navigation, EN/AR RTL, light/dark theme. Preserve existing router/i18next. Use approved PNG as design reference, not as a screenshot pasted into the app. No fake login: v1 uses guest HttpOnly cookies.

## Phase 2: complete functional pages
Implement Home, Experiment Gallery, Guided/Challenge Workbench, Graph Explorer, Observability, AI Mentor, Results/Timeline, Lab Environment, Notes (only if appropriate), Settings. Map pages to existing routes; avoid duplicate backends. All ten canonical E01–E10 manifests must remain authoritative. Do not replace Cytoscape with reference SVG. Preserve four graph layouts, filters, node/edge inspection, keyboard access.

## Phase 3: backend integration and evidence integrity
Reuse real FastAPI endpoints and typed clients, guest cookie session, run validators and run history. Keep PASSED/FAILED/BLOCKED distinct, confidence confirmed/likely/insufficient_evidence, evidence refs, trace_id, Grafana deep links, comparison/export, provenance, GDS versus NetworkX fallback labels. If telemetry services are unavailable, show unavailable; do not invent metrics. Do not create user accounts or new auth. No secret exposure or client-supplied session_id. Keep production fail-closed configuration and 60/min run rate limit.

## Phase 4: continuous LIVE UI PREVIEW — integrated into every page
1. Inspect whether a browser/Chromium + Playwright tool is genuinely available. Start the existing Vite dev server and backend as available; do not replace frameworks.
2. First prove the preview workflow on one real page: open Chromium, capture 1440×900 desktop and 390×844 mobile screenshots, inspect DOM, click navigation and core actions, check JS console/network and horizontal overflow. Record evidence.
3. After EVERY completed page or meaningful visual change repeat screenshots + DOM interaction + error inspection + correction. Also verify 768px tablet and Arabic RTL at major milestones.
4. Optionally add `/dev/ui-preview` as a development-only component/state gallery, excluded from production bundles/routes. It may use deterministic, conspicuously labeled SAMPLE/PREVIEW data; never fake production runs, mentor answers or traces.
5. Save evidence under `reports/ui-preview/<page>/<viewport>/` and produce a review ZIP after each logical group. Exclude secrets and bulky transient browser caches from git.
6. Test whether a public/shareable Live Preview link is truly accessible from the user's browser. A `localhost` URL inside GLM is NOT user-accessible. Do not promise external access if no supported preview host exists. If remote preview requires hosting, permissions, credentials, or exposure of a dev server, ask for approval first. Keep demo mode isolated from production.
7. Do not turn preview tooling into an infrastructure project. Prefer the simplest existing browser/preview facilities.

## Phase 5: tests and release
Run actual frontend TypeScript/Vite build, Vitest, backend pytest, relevant Docker/CI smoke tests, and browser E2E as tools permit. Supplied README historically lists 363 backend + 17 frontend tests (380); inspect current counts. Ensure session isolation, blocked state, Neo4j/GDS fallback, real telemetry behavior, rate limits, production security checks and no broken `/api` proxy. Perform visual comparison against reference and fix material divergence. Remove obsolete old UI only after parity. Commit logical changes and push to GitHub if authorized and possible; report branch, full SHA and actual remote verification. Do not claim PASS for unrun tests.

## Grouped deliverables and status reporting
Groups: A inventory & capability/access audit; B design shell + preview proof; C experiment gallery/workbench; D graph/observability/mentor; E results/environment/settings; F integration/regression/visual review; G GitHub and deployment. After each group give a compact status with changed files, live screenshot references, tested interactions, blockers, and next work. Continue autonomously through repairable issues without artificial retry or time ceilings. Final files: `reports/UI_REBUILD_INTEGRATION_MAP.md`, `reports/UI_REBUILD_VISUAL_REVIEW.md`, `reports/UI_REBUILD_TEST_REPORT.md`, `reports/UI_REBUILD_DEPLOYMENT.md`. Final status must explicitly state build, real backend integration, browser preview, screenshots, Arabic RTL, mobile, GitHub push, remote SHA, and any NOT RUN/BLOCKED items.

## Non-negotiable principles
The approved design is the visual authority; the real repository and manifests are functional authority; actual browser behavior is acceptance authority. No invented credentials, results, status, trace data, or links. Preserve the architecture and security. Begin Phase 0 now.
