# GROUP_XX_REPORT — required template

- Group / task IDs / execution date / operator:
- Repository / branch / base SHA / final SHA / clean status:
- STATUS: PASS | PASS_WITH_LIMITATIONS | FAIL | BLOCKED
- Summary of delivered behavior (not only files):
- Task-by-task matrix: task ID, delivered artifact, tests, status, evidence path:
- Commands and exact exit codes: install, lint, typecheck (if configured), unit, integration, contract, migrations, build, security checks:
- Test counts: collected/passed/failed/skipped; explain skips:
- Evidence: OpenAPI/schema diff, fixtures, logs, representative output (redacted):
- API endpoints added/changed and backwards-compatibility review:
- DB migrations and rollback check:
- Source code file count before/after, lines added, dependencies added, disk impact:
- Toolkit reused and verified / unavailable components:
- Security, data-provenance, cost and policy checks:
- Known limitations, risk severity, unresolved decisions:
- Suggested corrective tasks **inside current group** (if any):
- Explicit STOP statement: waiting for user authorization for next group.
