# Minimum cross-group contracts v1.0 — binding semantics

## Domain records (schema may evolve through reviewed migrations)
- `Source`: id, canonical_uri, source_type, publisher, author, license/usage policy if known, discovered_at, status.
- `Acquisition`: id, source_id, provider, provider_version, acquired_at, content_hash, content_type, artifact_ref, completeness (`full|partial|failed`), status, error_code, duration_ms, cost_estimate.
- `EvidenceFragment`: id, acquisition_id, document_version, locator (`section/page/line/span`), exact_excerpt_or_hash, extraction_method, timestamp. Never lose original source linkage.
- `Entity`: id, kind, canonical_name, aliases, attributes, created_at, updated_at; supported kinds include tool, technology, technique, capability, project, constraint, paper, repository, model, dataset, experiment, scenario.
- `Claim`: id, proposition, subject/object refs as applicable, evidence refs, epistemic_state (`supported|inferred|hypothesized|disputed|rejected`), confidence metadata, validity_conditions, version.
- `Relationship`: id, from_entity_id, to_entity_id, type, direction, origin (`explicit|derived|hypothesized`), verification_state, evidence_refs, confidence metadata, conditions, valid_from/to, created_at, updated_at. Derived/hypothesized never auto-promoted to verified.
- `Capability`: id, name, inputs, outputs, prerequisites, constraints, provider mappings.
- `Hypothesis`: id, description, premise_relationship_ids, assumptions, missing_evidence, status, proposed_experiment_ids.
- `Experiment`: id, hypothesis_id, protocol, baseline, metrics, safety/cost limits, execution_mode, result, artifact_refs.
- `EvidenceDelta`: id, hypothesis_id, experiment_id, prior_state, observation, update_method, updated_state, applicable_conditions, timestamp, reviewer.
- `Scenario`: id, current_evidence_refs, capabilities, assumptions, missing_dependencies, horizon_class (`F0..F4`), critique, prototype_plan, status.
- `Job`: id, kind, requester, status (`queued|running|succeeded|failed|cancelled`), progress, input_ref, output_ref, created_at, updated_at, idempotency_key.

## Invariants
- Every verified claim and explicit relationship has at least one inspectable evidence fragment; otherwise reject verification transition.
- Every derived/hypothesized relationship retains derivation trace and remains marked unverified until reviewed/tested.
- Source/discovery/acquisition/extraction/verification are separate statuses; partial fetch is never represented as full.
- Repeated ingest of same canonical URL + content hash does not duplicate immutable source version; changes create new version.
- Experiment result never mutates prior belief in place without a corresponding immutable EvidenceDelta audit record.
- Deletion/retention follows authorization and data-policy decisions; no silent destruction of evidence used by retained claims.

## API behavior (external UI and internal UI share these endpoints)
- Base: `/api/v1`; `GET /health/live`, `GET /health/ready`; OpenAPI exposed in non-production or appropriately controlled environments.
- `POST /sources/discover`, `POST /sources/ingest`, `GET /sources`, `GET /sources/{id}`, `GET /sources/{id}/acquisitions`.
- `GET /entities`, `GET /entities/{id}`, `GET /relationships`, `GET /relationships/{id}`, `GET /claims/{id}/evidence`.
- `POST /knowledge/search`, `POST /reasoning/queries`, `POST /innovations/generate`, `POST /innovations/{id}/critique`.
- `POST /experiments`, `POST /experiments/{id}/execute` (requires explicit execution authorization), `GET /experiments/{id}`, `GET /hypotheses/{id}/evidence-deltas`.
- `POST /future/scenarios`, `GET /future/scenarios/{id}`, `POST /future/scenarios/{id}/prototype-plan`.
- `GET /jobs/{id}`, `POST /jobs/{id}/cancel`, `GET /capabilities`, `GET /providers`, `GET /system/activity-mode`, `PUT /system/activity-mode` (privileged).
- Exact routes can be refined in G01 OpenAPI draft before coding; afterward changes require compatibility review. Unsupported future routes must return a documented 501/feature-disabled response rather than fabricated success.

## Shared HTTP contract
- JSON response: `data`, `meta` (`request_id`, `api_version`, optional `job_id`, pagination), `error` (null on success).
- Errors: `error.code`, `error.message`, `error.details`, `error.retryable`; mapped to standard HTTP codes (400 invalid, 401 unauthenticated, 403 forbidden, 404 missing, 409 conflict, 422 semantic validation, 429 rate limit, 500 internal, 503 unavailable).
- Long-running actions: `202 Accepted` with job ID and status URL; GET job polling, optional later SSE. Never hold HTTP request until deep research finishes.
- Security: authentication adapter, RBAC/scopes, tenant isolation if enabled, input and URL validation, SSRF protections, bounded fetch sizes/timeouts, audit events, redaction of secrets.
- API must support CORS allowlist configuration for an external browser-based UI; deny wildcard-with-credentials. Service-to-service clients use tokens and documented scopes.
- Pagination deterministic; timestamps UTC ISO8601; request/response schema tests; backward-compatible additive changes in v1.
