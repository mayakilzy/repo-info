# Decisions, reversible defaults and unresolved questions

## Binding
- Synapse is a relationship-aware knowledge/hypothesis/innovation system, not a generic RAG chatbot.
- Knowledge, inference, hypothesis, innovation proposal and future scenario are distinct states.
- Graph thinking from day one; graph database only if justified by measured workload.
- API layer is mandatory and independent of any UI. Internal and external clients must not bypass application services.
- Provider abstraction, evidence lineage, controlled autonomy, cost escalation and vertical proof are mandatory.

## Reversible engineering defaults — validate in G01
- Python 3.12 backend; FastAPI + Pydantic v2; PostgreSQL + pgvector if available; Alembic migrations; pytest; Ruff; HTTPX; OpenAPI 3.x. Use existing repo conventions if materially better and explain.
- Modular monolith with package boundaries `api`, `domain`, `application`, `providers`, `storage`, `workers`, `observability` (do not create unused empty packages).
- Local filesystem or object storage adapter for immutable source artifacts; Postgres for metadata/relations; optional vector extension.
- A simple database-backed job runner is sufficient initially; no Redis/Kafka/NATS/Temporal by default.
- Versioned `/api/v1`; JSON UTF-8; opaque stable IDs; UTC timestamps; cursor pagination; idempotency keys for mutation/job submission.

## Decisions requiring evidence or approval
- External auth identity provider, exact authorization policy for multi-tenancy, deployment target, public hosting, paid search/X provider, monthly budgets and data-retention periods.
- If missing, implement local development auth adapter and fail-closed production settings, never anonymous public production access.
- Never claim a specific accuracy/confidence score is calibrated without evaluation.
- Never assume an X scraper is permitted, stable or reliable; provide compliant alternative/disabled connector.
