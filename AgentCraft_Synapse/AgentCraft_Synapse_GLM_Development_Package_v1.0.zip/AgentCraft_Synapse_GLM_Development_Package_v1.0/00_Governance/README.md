# AgentCraft Synapse — GLM implementation handoff

Contents:
- `01_Master_Specification/`: authoritative Master Architecture v2.0 (DOCX)
- `00_Governance/START_HERE_GLM.md`: mandatory execution and stopping rules
- `00_Governance/DECISIONS_AND_ASSUMPTIONS.md`: binding versus reversible decisions
- `03_Contracts/DOMAIN_AND_API_CONTRACTS.md`: initial domain, evidence and API semantics
- `02_Task_Groups/GROUP_01.md` through `GROUP_06.md`: **30 gated tasks**, five per group
- `04_Reports/`: report and JSON evidence templates

**First instruction to GLM:** Read the whole package, inspect repository read-only, execute GROUP_01 only, produce its closure report and stop. The user will decide whether to approve GROUP_02 or request repairs.

**Scope warning:** The Master Spec is architecture, not proof that any toolkit adapter works. The attached package does not contain the full toolkit. All external providers and cost assumptions require verification. API-first architecture is mandatory even if no internal UI is built.
