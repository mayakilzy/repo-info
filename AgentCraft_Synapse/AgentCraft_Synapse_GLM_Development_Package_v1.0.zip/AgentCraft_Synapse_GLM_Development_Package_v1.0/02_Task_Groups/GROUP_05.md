# GROUP_05 — Innovation, Critic, Experiments & Evidence Delta

**Execution authorization:** Only after explicit user approval of this group. **Goal:** Prove non-trivial hypothesis generation from graph structure and measurable belief updates.

**Preconditions:** G01: repository access and Master Spec. Later groups: previous group PASS + user authorization. Stop if violated.

**Mandatory sequence:** inspect → plan smallest change → implement → test → report → STOP. Keep previous API/schema behavior compatible; document any approved exception.

## G05-T01 — Structural opportunity generator

**Required work:** Generate combinations from capability gaps, complements, constraints, path patterns and contradictory edges, not only LLM brainstorming. Rank with transparent rationale.

**Deliverables:** Candidate generator, traceable premise IDs, dedup and ranking.

**Acceptance evidence:** Fixture creates cross-source non-trivial candidate; rationale references source relationships.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G05-T02 — Hypothesis model and innovation API

**Required work:** Store assumptions, novelty uncertainty, dependencies, missing evidence, risk and proposed experiment.

**Deliverables:** Hypothesis lifecycle and generation endpoint.

**Acceptance evidence:** Generated hypothesis marked unverified; identical candidate not duplicated; inspectable provenance.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G05-T03 — Reality critic

**Required work:** Search for contradictory evidence, impossible dependencies, competing products, cost/security constraints; output critique separate from hypothesis.

**Deliverables:** Critic workflow and API; explicit accept/revise/reject states.

**Acceptance evidence:** Adversarial fixture causes revision/rejection; critic cannot silently promote evidence.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G05-T04 — Safe experiment design and execution

**Required work:** Design measurable protocol with baseline, metrics, limits and human authorization; sandbox or simulation for approved harmless tests. No autonomous production writes.

**Deliverables:** Experiment model, execution policy, run artifacts and jobs.

**Acceptance evidence:** Unauthorized execution 403; budget/timeout enforced; reproducible simulation returns observations.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G05-T05 — Evidence Delta learning

**Required work:** Record prior belief, observations, conditions, update method, revised belief and new hypotheses; preserve immutable history.

**Deliverables:** EvidenceDelta service/API, before-after diff and audit.

**Acceptance evidence:** Successful and failed trials update conditions; history replayable; confidence change not arbitrary or unexplained.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## Group-wide exit gate

1. Run clean install, lint, unit and integration tests, contract/OpenAPI tests, migrations and rollback (where relevant), and security regression tests; report command and exit code. No external service dependency in mandatory CI.
2. Update decisions log and architecture docs only where implementation choices require it. Explicitly list deviations from the Master Specification and obtain approval for material deviations.
3. Include representative machine-readable evidence, real repository SHA, changed-file list, before/after file counts, new dependency list, known limitations, API compatibility status and reproducible demonstration steps.
4. Write `reports/GROUP_XX_REPORT.md` and `reports/GROUP_XX_EVIDENCE.json` using the templates. STOP and await user review. Never start the next group automatically.
