# GROUP_03 — Knowledge Store, Relationships & Verification

**Execution authorization:** Only after explicit user approval of this group. **Goal:** Transform evidence into structured, traceable knowledge and verified relationship objects.

**Preconditions:** G01: repository access and Master Spec. Later groups: previous group PASS + user authorization. Stop if violated.

**Mandatory sequence:** inspect → plan smallest change → implement → test → report → STOP. Keep previous API/schema behavior compatible; document any approved exception.

## G03-T01 — Entity/claim extraction contracts

**Required work:** Extract atomic knowledge from 10 mixed-source fixtures, preserving quote/locator and uncertainty; do not treat generated text as evidence.

**Deliverables:** Extraction schema, deterministic/LLM mock path, validation rules.

**Acceptance evidence:** Every supported claim references fragment; unsupported model assertions rejected or labeled hypothesis.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G03-T02 — Canonicalization and versioning

**Required work:** Normalize aliases, versions, repository identity, entity types; handle conflicting values without destructive overwrite.

**Deliverables:** Canonical entity registry, merge/review policy, provenance-preserving updates.

**Acceptance evidence:** Reingest identical data is idempotent; changed version retained; ambiguous alias not silently merged.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G03-T03 — RelationshipService

**Required work:** Implement first-class directed, typed, conditional and temporal relationships with explicit/derived/hypothesized origin; path lookup and missing capability queries.

**Deliverables:** RelationshipService, indexed relational tables and migrations.

**Acceptance evidence:** Multi-hop paths correct; cyclic graph safe; inferred links remain unverified; evidence lookup succeeds.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G03-T04 — Verification and contradiction engine

**Required work:** Assign epistemic states from evidence rules, independent-source tracking, contradictory claims and validity conditions; never equate model confidence with empirical probability.

**Deliverables:** Verification policies, contradiction records, audit trail.

**Acceptance evidence:** Contradictions coexist; verification requires source; changes recorded and reversible.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G03-T05 — Knowledge API and vertical data demo

**Required work:** Expose entities, claims/evidence, relationships, source histories via versioned endpoints and scoped access.

**Deliverables:** OpenAPI updates, 10-source demo dataset and report.

**Acceptance evidence:** API contract and auth tests; inspect 10-source lineage source→fragment→claim→relationship.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## Group-wide exit gate

1. Run clean install, lint, unit and integration tests, contract/OpenAPI tests, migrations and rollback (where relevant), and security regression tests; report command and exit code. No external service dependency in mandatory CI.
2. Update decisions log and architecture docs only where implementation choices require it. Explicitly list deviations from the Master Specification and obtain approval for material deviations.
3. Include representative machine-readable evidence, real repository SHA, changed-file list, before/after file counts, new dependency list, known limitations, API compatibility status and reproducible demonstration steps.
4. Write `reports/GROUP_XX_REPORT.md` and `reports/GROUP_XX_EVIDENCE.json` using the templates. STOP and await user review. Never start the next group automatically.
