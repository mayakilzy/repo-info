# GROUP_04 — Hybrid Retrieval & Evidence-Grounded Reasoning

**Execution authorization:** Only after explicit user approval of this group. **Goal:** Answer capability/relationship questions with inspectable evidence, not raw-document summaries.

**Preconditions:** G01: repository access and Master Spec. Later groups: previous group PASS + user authorization. Stop if violated.

**Mandatory sequence:** inspect → plan smallest change → implement → test → report → STOP. Keep previous API/schema behavior compatible; document any approved exception.

## G04-T01 — Hybrid retrieval

**Required work:** Implement lexical + metadata + relationship retrieval; add vector retrieval only when available and measured; rerank under budget.

**Deliverables:** Search service, query trace, indexes and fixture evaluation.

**Acceptance evidence:** Golden queries recover expected claims and constraints; stable pagination; empty results truthful.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G04-T02 — Capability Registry

**Required work:** Map tools→capabilities, projects→required capabilities, constraints, prerequisites, available provider alternatives.

**Deliverables:** Registry model/service, CRUD/read API and test data.

**Acceptance evidence:** Find alternative tool by capability; identify missing project capability with evidence.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G04-T03 — Grounded reasoning

**Required work:** Compose answers from claims, paths, conflicts and conditions; cite exact evidence IDs; isolate prompt injection in untrusted source text.

**Deliverables:** Reasoning service, model provider abstraction, query endpoint with job pattern.

**Acceptance evidence:** Missing evidence leads to uncertainty; no fabricated citations; injection fixture cannot alter system actions.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G04-T04 — Evaluation and cost routing

**Required work:** Compare lexical-only vs hybrid; record latency, tokens/cost, trace and failure; apply cheap-first model selection.

**Deliverables:** Reproducible eval harness and baseline report.

**Acceptance evidence:** Fixed query set metrics reported; hard budgets enforced; provider timeout yields structured failure.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G04-T05 — External client compatibility

**Required work:** Publish sample external-client calls for search, reasoning, job polling and auth; verify UI-agnostic API and CORS.

**Deliverables:** OpenAPI/client examples and contract tests.

**Acceptance evidence:** Second independent client uses only API, not internal DB or private Python modules.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## Group-wide exit gate

1. Run clean install, lint, unit and integration tests, contract/OpenAPI tests, migrations and rollback (where relevant), and security regression tests; report command and exit code. No external service dependency in mandatory CI.
2. Update decisions log and architecture docs only where implementation choices require it. Explicitly list deviations from the Master Specification and obtain approval for material deviations.
3. Include representative machine-readable evidence, real repository SHA, changed-file list, before/after file counts, new dependency list, known limitations, API compatibility status and reproducible demonstration steps.
4. Write `reports/GROUP_XX_REPORT.md` and `reports/GROUP_XX_EVIDENCE.json` using the templates. STOP and await user review. Never start the next group automatically.
