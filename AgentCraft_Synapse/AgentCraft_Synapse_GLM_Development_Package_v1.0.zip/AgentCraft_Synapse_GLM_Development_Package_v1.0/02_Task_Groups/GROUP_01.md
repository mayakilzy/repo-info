# GROUP_01 — Foundation, Relationship Model & API Contracts

**Execution authorization:** Only after explicit user approval of this group. **Goal:** Freeze minimal architecture and establish testable backbone, not feature breadth.

**Preconditions:** G01: repository access and Master Spec. Later groups: previous group PASS + user authorization. Stop if violated.

**Mandatory sequence:** inspect → plan smallest change → implement → test → report → STOP. Keep previous API/schema behavior compatible; document any approved exception.

## G01-T01 — Repository reconnaissance and architectural baseline

**Required work:** Inspect existing repository, toolkit location, existing code/tests, licenses and constraints; create `docs/baseline.md` with tree metrics and dependencies. Never overwrite existing work.

**Deliverables:** Baseline report, risks, verified toolkit location; reproducible commands.

**Acceptance evidence:** Re-run baseline commands; no source mutation during inspection.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G01-T02 — Domain and epistemic contracts

**Required work:** Define schemas for Source, Acquisition, EvidenceFragment, Entity, Claim, Relationship, Capability, Hypothesis, Experiment, EvidenceDelta, Scenario and Job. Enforce explicit/derived/hypothesized and state-transition invariants.

**Deliverables:** Versioned typed domain models, schema documentation, migration plan.

**Acceptance evidence:** Tests reject verified claim without evidence, invalid transitions, missing provenance, duplicate entity IDs.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G01-T03 — Modular monolith skeleton and persistence

**Required work:** Create minimal backend bootstrapping, configuration profiles, Postgres connection/migrations and test DB isolation. No graph database or message bus.

**Deliverables:** Runnable service, migration up/down, container/local run instructions, sample env without secrets.

**Acceptance evidence:** Cold-start and clean-db migration tests pass; startup fails safely without required prod secrets.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G01-T04 — API-first contract and security baseline

**Required work:** Publish OpenAPI for `/api/v1`, auth/scopes, response/error envelope, 202 job pattern, idempotency, pagination, CORS allowlist, SSRF safety boundaries. Implement health, capabilities and provider listing minimally.

**Deliverables:** API schema, auth adapter, error middleware, request IDs, endpoint smoke tests.

**Acceptance evidence:** 401/403/422/429 tests, forbidden CORS origin, secret redaction, OpenAPI schema validation.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G01-T05 — Quality and group reporting gate

**Required work:** Set lint/test/CI, deterministic fixtures, logging and coverage reporting. Establish decision log and report generation.

**Deliverables:** CI config, tests, developer README, group report.

**Acceptance evidence:** Fresh install + lint + tests + migration smoke + OpenAPI check all exit 0; report exact results.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## Group-wide exit gate

1. Run clean install, lint, unit and integration tests, contract/OpenAPI tests, migrations and rollback (where relevant), and security regression tests; report command and exit code. No external service dependency in mandatory CI.
2. Update decisions log and architecture docs only where implementation choices require it. Explicitly list deviations from the Master Specification and obtain approval for material deviations.
3. Include representative machine-readable evidence, real repository SHA, changed-file list, before/after file counts, new dependency list, known limitations, API compatibility status and reproducible demonstration steps.
4. Write `reports/GROUP_XX_REPORT.md` and `reports/GROUP_XX_EVIDENCE.json` using the templates. STOP and await user review. Never start the next group automatically.
