# GROUP_06 — Future Intelligence, Operations & Release Gate

**Execution authorization:** Only after explicit user approval of this group. **Goal:** Close full vertical loop and ship API-first, extensible production candidate without feature bloat.

**Preconditions:** G01: repository access and Master Spec. Later groups: previous group PASS + user authorization. Stop if violated.

**Mandatory sequence:** inspect → plan smallest change → implement → test → report → STOP. Keep previous API/schema behavior compatible; document any approved exception.

## G06-T01 — Future scenarios and Dreaming

**Required work:** Explore structured combinations with F0–F4 horizons, evidence/assumptions, critic, missing capabilities and prototype plan. No fictional certainty.

**Deliverables:** Scenario service and API, bounded generation mode.

**Acceptance evidence:** Scenario marked speculative; missing capability trace and critic report inspectable.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G06-T02 — Graduated autonomy

**Required work:** Implement Modes 0–3 as policy-controlled, default 0; schedule/discovery mode, opportunity triggers and autonomous innovation disabled unless explicitly enabled and budgeted.

**Deliverables:** Activity mode policy, scheduler limits, privileged API and audit.

**Acceptance evidence:** Default passive; no surprise spend; unauthorized mode change rejected; emergency disable works.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G06-T03 — End-to-end vertical proof

**Required work:** Run 10 representative technical sources through acquisition→evidence→knowledge→relationships→retrieval→hypothesis→critic→experiment→EvidenceDelta→updated knowledge.

**Deliverables:** Recorded deterministic demo, provenance graph, API-only invocation script.

**Acceptance evidence:** Every transition traceable; no manual invisible edits; one non-trivial hypothesis and one measurable delta.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G06-T04 — Security, performance and resilience

**Required work:** Threat-model ingestion/API; test SSRF, auth, tenant boundaries, CORS, idempotency, queue recovery, backpressure, logging/redaction, restore and migration rollback.

**Deliverables:** Security checklist, performance baselines, recovery drill, runbook.

**Acceptance evidence:** Critical security checks pass; limits measured; restart recovers jobs safely; backup restore validated.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G06-T05 — Release candidate and handoff

**Required work:** Finalize versioned OpenAPI, external integration guide, deployment configuration, changelog, evidence package, known limitations and no-go decisions.

**Deliverables:** Release checklist, tagged candidate only with approval, complete final report.

**Acceptance evidence:** Fresh environment install passes; all group gates accounted; no unresolved critical issue; user decides release.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## Group-wide exit gate

1. Run clean install, lint, unit and integration tests, contract/OpenAPI tests, migrations and rollback (where relevant), and security regression tests; report command and exit code. No external service dependency in mandatory CI.
2. Update decisions log and architecture docs only where implementation choices require it. Explicitly list deviations from the Master Specification and obtain approval for material deviations.
3. Include representative machine-readable evidence, real repository SHA, changed-file list, before/after file counts, new dependency list, known limitations, API compatibility status and reproducible demonstration steps.
4. Write `reports/GROUP_XX_REPORT.md` and `reports/GROUP_XX_EVIDENCE.json` using the templates. STOP and await user review. Never start the next group automatically.
