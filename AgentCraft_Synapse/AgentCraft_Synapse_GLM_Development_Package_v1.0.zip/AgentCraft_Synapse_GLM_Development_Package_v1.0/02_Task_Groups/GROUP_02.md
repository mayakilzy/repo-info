# GROUP_02 — Discovery, Acquisition & Source Intelligence

**Execution authorization:** Only after explicit user approval of this group. **Goal:** Deliver a bounded real-source acquisition-to-evidence pipeline using toolkit-first adapters.

**Preconditions:** G01: repository access and Master Spec. Later groups: previous group PASS + user authorization. Stop if violated.

**Mandatory sequence:** inspect → plan smallest change → implement → test → report → STOP. Keep previous API/schema behavior compatible; document any approved exception.

## G02-T01 — ToolKit capability audit

**Required work:** Inspect actual implementations/docs/dependencies/licenses for search, GitHub, arXiv, RSS, Crawl4AI, Trafilatura, Playwright, PDF, X; measure 1-2 safe fixtures each. Mark present/partial/missing/blocked.

**Deliverables:** `docs/layer1_capability_matrix.md` with capability, source, tool, quality, metadata retention, policy, speed, cost, fallback, gap.

**Acceptance evidence:** No tool marked production-ready without a runnable test; unavailable toolkit flagged BLOCKED or adapter substituted transparently.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G02-T02 — Discovery providers and scheduler

**Required work:** Implement provider interfaces and at least two permitted discovery paths (e.g. RSS + GitHub/public web); scheduled mode uses bounded runs, checkpoints, dedup and explicit budgets.

**Deliverables:** Discovery API, provider adapters, candidate records, scheduled task and mock providers.

**Acceptance evidence:** Duplicate results collapse; provider outage isolated; limits respected; offline CI fixtures pass.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G02-T03 — Acquisition escalation router

**Required work:** HTTP first, lightweight extraction, crawler, browser fallback only if necessary; enforce host policy, timeouts, size limits, SSRF/IP/DNS checks, robots/ToS constraints and backoff.

**Deliverables:** Acquisition provider contract, route decisions, failure taxonomy, source version store.

**Acceptance evidence:** Test HTTP success avoids browser; JS fixture escalates; blocked/partial recorded accurately; private IP blocked.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G02-T04 — Extraction and provenance

**Required work:** Preserve headings, code, tables, links, authorship, dates, citations, versions and source spans; store raw artifact hash and normalized representation.

**Deliverables:** Extractor adapters, immutable acquisition record, evidence fragment locators.

**Acceptance evidence:** Golden HTML/PDF/repo fixtures preserve specified fields; evidence link resolves to source artifact.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## G02-T05 — Acquisition intelligence gate and API

**Required work:** Cheap duplicate/novelty/relevance/change/authority checks; decisions ignore/record/extract/deep analyze/opportunity; expose ingest/discover/jobs APIs and statuses.

**Deliverables:** Decision traces, ingestion endpoints, async jobs and budget metrics.

**Acceptance evidence:** 10-source fixture batch produces deterministic statuses and no fake verification; retry/idempotency and cancellation tested.

**Failure handling:** If the acceptance evidence cannot be demonstrated, mark this task FAIL/BLOCKED with exact reproduction and do not advance.

## Group-wide exit gate

1. Run clean install, lint, unit and integration tests, contract/OpenAPI tests, migrations and rollback (where relevant), and security regression tests; report command and exit code. No external service dependency in mandatory CI.
2. Update decisions log and architecture docs only where implementation choices require it. Explicitly list deviations from the Master Specification and obtain approval for material deviations.
3. Include representative machine-readable evidence, real repository SHA, changed-file list, before/after file counts, new dependency list, known limitations, API compatibility status and reproducible demonstration steps.
4. Write `reports/GROUP_XX_REPORT.md` and `reports/GROUP_XX_EVIDENCE.json` using the templates. STOP and await user review. Never start the next group automatically.
