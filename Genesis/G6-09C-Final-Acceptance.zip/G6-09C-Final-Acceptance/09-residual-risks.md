# 09 — Residual Risks

**G6-09C audit** | Integrated commit: `bff7b0a6f8b4e35880a9c7453d4e6de343e4e001`

## 1. Documented technical limitations

### Promise.race cleanup limitation

The G6-09B fix for G6-09-001 uses `Promise.race([rt.runtime.close(), setTimeout(perRuntimeDeadline)])`. When the timeout wins, the `rt.runtime.close()` Promise continues pending in the background.

**Impact:** The underlying cleanup operation is NOT actually cancelled. If `close()` eventually resolves, the structured `ShutdownResult` already reported the timeout (and the gateway has likely exited).

**Mitigation:** The structured `ShutdownResult` accurately reports `closed=false` and `closeError='timeout after Xms'`. The gateway's exit code reflects the unclean state (`process.exit(result.clean ? 0 : 1)` exits 1 when `clean=false`). The operator can detect orphaned workers via the nonzero exit code and investigate.

**Acceptance:** This is an honestly-disclosed limitation. The fix is truthful about not stopping the underlying operation. A complete fix would also attempt to SIGKILL the worker after the timeout, but that requires runtime-adapter-level changes (the runtime adapter would need to know the worker PID).

**Classification:** ACCEPTED_WITH_LIMITATION (defense-in-depth; primary defense is the structured result + exit code)

### Shutdown idempotency (G6-09C-001, P3, defense-in-depth)

`MissionService.shutdown()` is NOT idempotent at the runtime-close level. The `seenRuntimes` Set is LOCAL to each shutdown call. If `shutdown()` is called twice concurrently, both calls invoke `close()` on the same runtime.

**Impact:** The runtime adapter's `close()` MUST be idempotent to handle this. For production (`OpenBotRuntimeAdapter`), `close()` is idempotent (stops all remaining workers; no-op if none). For dev mode (`MemoryRuntime`), `close()` is absent (the optional `close?()` method is not implemented).

**Acceptance:** This is a defense-in-depth concern, NOT a behavior defect. The structured result is still correct (both calls report the same runtime state).

**Recommendation:** Add a runtime-level `closed` flag in `MissionService` to track already-closed runtimes across shutdown calls.

**Classification:** DEFENSE_IN_DEPTH (P3, does not block release)

### Trusted `extraEnv` behavior (G6-09C-002, P3, defense-in-depth)

The post-fix `startComputerProcess` applies `config.extraEnv` AFTER the explicit allowlist. This means `extraEnv` CAN technically inject sensitive key names (e.g., `GENESIS_API_KEYS`) IF the caller passes them.

**Trust boundary:** `config.extraEnv` is constructed by trusted gateway code (`buildRealRuntimeFactory` in `main.ts:150-222`). The HTTP API and A2A server do NOT accept `extraEnv` in mission submissions. Untrusted goal content goes through the orchestrator, not the runtime factory.

**Acceptance:** This is a TRUSTED test infrastructure override, NOT a security defect. But it IS a defense-in-depth concern: if a future code path allows untrusted input to reach `extraEnv`, the allowlist would be bypassed.

**Recommendation:** Add a runtime check in `startComputerProcess` that warns or rejects if `extraEnv` contains sensitive key names (`GENESIS_API_KEYS`, `OPENROUTER_API_KEY`, `ZAI_API_KEY`, etc.).

**Classification:** DEFENSE_IN_DEPTH (P3, does not block release)

### scrubSecrets() regex limitation

The G6-09C fix for C-053 uses regex-based scrubbing of 7 secret patterns. This is DEFENSE-IN-DEPTH, not complete protection.

**Limitations:**
- Regex-based — only catches known patterns (Bearer, ghp_, sk-or-v1-, sk-ant-, sk-, AWS_SECRET_ACCESS_KEY, api_key)
- Does NOT catch obfuscated or char-by-char-split secrets
- Does NOT decode base64/URL-encoded payloads
- Over-scrub risk: permissive patterns (e.g., `sk-[A-Za-z0-9_]{20,}`) may match non-secret text

**Acceptance:** The primary defense is preventing secrets from reaching error messages in the first place (the G6-09B env allowlist fix). `scrubSecrets()` is the backstop for when an upstream dependency echoes a secret in an error message.

**Classification:** DEFENSE_IN_DEPTH (P2, does not block release)

## 2. GLM-assisted Campaign K classification

All 8 Campaign K scenarios are classified as `GLM_ASSISTED_CONTROLLED_RUNTIME`:
- GLM provided the reasoning (via pre-generated responses injected through the existing `reasoningFactory` interface)
- The runtime is `MemoryComputer` (controlled stub, NOT real OpenBot)
- This is NOT autonomous model integration
- This is NOT live ZAI integration
- No external LLM API calls were made

**Honest disclosure:** GLM is not called programmatically in real-time; the responses are pre-generated and injected. Live ZAI reasoning and real OpenBot execution remain BLOCKED_BY_ENVIRONMENT.

## 3. Missing live ZAI/OpenBot evidence

| Capability | Status | Reason |
|---|---|---|
| Live ZAI reasoning | BLOCKED_BY_ENVIRONMENT | No `ZAI_API_KEY` in audit sandbox; OPENROUTER_API_KEY is Jev-only (per G6-09 mandate Section 2.1) |
| Live OpenBot execution | BLOCKED_BY_ENVIRONMENT | No OpenBot checkout in audit sandbox; `$GENESIS_OPENBOT_DIR` not set |
| Live OpenDots | BLOCKED_BY_ENVIRONMENT | No OpenDots checkout |
| Live OpenMuse | BLOCKED_BY_ENVIRONMENT | No OpenMuse checkout |
| Live MCP (third-party) | BLOCKED_BY_ENVIRONMENT | Only local reference server tested |
| Live AG-UI (third-party) | BLOCKED_BY_ENVIRONMENT | Only in-process consumer tested |

**Acceptance:** These are explicit conditions for acceptance. Operators MUST run bounded live acceptance tests with real ZAI + real OpenBot before production deployment.

## 4. Remaining operational acceptance conditions

Per the G6-09C mandate Section 9, the verdict is CONDITIONAL_ACCEPT (not automatically promoted to ACCEPT). The conditions for acceptance are:

1. **Operators MUST run bounded live acceptance tests with real ZAI credentials** before production deployment. The ZAIReasoningProvider code is correct by inspection, but no live ZAI call was made.

2. **Operators MUST run bounded live acceptance tests with real OpenBot infrastructure.** The OpenBotRuntimeAdapter code is correct by inspection (with the G6-09B env allowlist fix applied), but no live OpenBot execution was made.

3. **Operators MUST run Tasks A-H from Campaign K** with real LLM + real OpenBot before trusting the engine for real production work. The G6-09C Campaign K tests verified the pipeline with GLM-assisted reasoning + controlled runtime, NOT autonomous execution.

4. **Operators MUST NOT deploy without an external durability layer** (in-process state only, no restart recovery — documented as Unsupported in `engine-v1-known-limitations.md`).

5. **Operators MUST NOT expose the gateway to untrusted networks without additional transport security** (API-key auth only, no mTLS/OAuth/JWT — documented as Limited).

6. **Operators MUST tune `maxActiveMissionsGlobal`** per their workload (default 50, configurable).

These conditions are explicit, enforceable, and bounded — they meet the Section 9 criteria for CONDITIONAL_ACCEPT.

## 5. Open findings summary

| Finding ID | Severity | Status | Classification |
|---|---|---|---|
| G6-09-001 | P1 | RESOLVED | (G6-09B fix verified) |
| G6-09-S01 | P1 | RESOLVED | (G6-09B fix verified) |
| G6-09-002 | P2 | RESOLVED | (coverage gap closed by IT-08) |
| G6-09-005 | P2 | RESOLVED | (coverage gap closed by IT-11) |
| G6-09-003 | P3 | RESOLVED | (coverage gap closed by IT-10-regression) |
| G6-09-006 | P3 | PARTIALLY_RESOLVED | (SIGKILL escalation test deferred — requires FakeChildProcess) |
| G6-09-S02 | P3 | RESOLVED | (G6-09B fix verified) |
| G6-09-004 | informational | ACCEPTED_BY_DESIGN | (MemoryRuntime no close by design) |
| G6-09-S03 | informational | RESOLVED | (G6-09B fix verified) |
| G6-09C-001 | P3 | OPEN (defense-in-depth) | shutdown() not idempotent at runtime-close level |
| G6-09C-002 | P3 | OPEN (defense-in-depth) | trusted extraEnv can technically inject sensitive names |
| C-053 | P2 | RESOLVED | (G6-09C fix verified) |

**OPEN_P0 = 0**
**OPEN_P1 = 0**
**OPEN_P2 = 0**
**OPEN_P3 = 2** (G6-09C-001 shutdown idempotency, G6-09C-002 extraEnv defense-in-depth)

Both open P3 findings are defense-in-depth concerns, NOT behavior defects. They do not block release.
