# 05 — Claims Reconciliation

**G6-09C audit** | Integrated commit: `bff7b0a6f8b4e35880a9c7453d4e6de343e4e001`

## 1. The inconsistency discovered

The G6-09B remediation report (`01-executive-verdict.md` and `17-final-enterprise-acceptance-report.md`) claimed `CRITICAL_CLAIMS_CONTRADICTED = 0` — but the actual `02-claims-registry.json` had 3 CONTRADICTED claims. This was a material inconsistency the G6-09C mandate (Section 5) required to reconcile.

The 3 previously-CONTRADICTED claims:

| Claim ID | Original text | Source | G6-09A verdict |
|---|---|---|---|
| C-013 | "production missions return ZERO artifacts via GET /v1/mission/{id}/artifacts" | experiments/g6-07-audit/executive-summary.md:48-50 | CONTRADICTED |
| C-051 | "OpenBot worker child processes do NOT inherit gateway secrets via environment variables" | src/runtime/openbot/computer-process.ts:175-184 | CONTRADICTED |
| C-053 | "Mission failureMessage does not leak secret patterns (Bearer tokens, API keys, credentials)" | src/gateway/mission-service.ts:620 | CONTRADICTED |

## 2. Per-claim reconciliation

### C-013 — G6-07 RB-1 defect (zero artifacts)

**Original G6-09A evidence:** The G6-07 audit at `b6fc2fa` found that `GET /v1/missions/{id}/artifacts` returned ZERO artifacts due to a missing `ArtifactsProvider.listArtifacts()` implementation.

**Relevant correction:** The RB-1 fix was applied in G6-08 Phase 1 (commit `825888f`), BEFORE the G6-09 audit. The fix added `ArtifactsProvider` to `OpenBotRuntimeAdapter` and `MemoryRuntime`, and `MissionService.getArtifacts()` was wired to call `runtime.listArtifacts()`.

**Was the correction tested?** YES. `tests/g6-08/rb1-artifacts-retrieval.test.ts` (RB1-01..04, 4 tests) confirms `getArtifacts()` returns non-empty artifacts at both `825888f` and `bff7b0a` (the integrated commit).

**Current verdict:** `CONTRADICTED` (preserved as historical record).

**Justification:** The claim describes the G6-07 BASELINE state (which WAS contradicted by the audit). The defect no longer exists at the integrated commit, but the claim's text is about the historical state. Preserving the verdict as CONTRADICTED maintains the historical record without turning a historically-contradicted claim into an unqualified PROVEN claim (per the G6-09C mandate: "Do not turn a historically contradicted claim into an unqualified PROVEN claim.").

**verdictHistorical:** `CONTRADICTED` (G6-09A)
**verdict (current):** `CONTRADICTED` (preserved — the claim text describes a historical defect state)
**remediationCommit:** n/a (RB-1 was fixed before the G6-09 audit at `825888f`, not by G6-09B at `98adb8e`)
**retestEvidence:** `tests/g6-08/rb1-artifacts-retrieval.test.ts` (RB1-01..04, 4 tests) confirm `getArtifacts()` returns non-empty artifacts at `bff7b0a`.

### C-051 — OpenBot worker env inheritance

**Original G6-09A evidence:** The G6-09 audit at `825888f` found that `src/runtime/openbot/computer-process.ts:175-184` used `env: { ...process.env, ...workerSpecificVars }`, leaking every gateway secret (`GENESIS_API_KEYS`, `OPENROUTER_API_KEY`, `ZAI_API_KEY`) into every OpenBot worker process. This was independently reproduced by IT-S-09 (a stub worker could read the secrets).

**Relevant correction:** The G6-09B fix at `98adb8e` replaced `...process.env` with an explicit allowlist (`PORT, COMPUTER_TOKEN, WORKSPACE_DIR, PROFILES_DIR, EGRESS_POLICY_REQUIRED, PATH?, HOME?, USER?, SHELL?, LANG?, LC_ALL?, ...config.extraEnv`).

**Was the correction tested?** YES.
- `harness/post-fix-verification.test.ts` IT-S-09-FIX (3 tests PASS):
  - STRUCTURAL: source no longer uses `...process.env` spread
  - STRUCTURAL: source has explicit allowlist (PORT, COMPUTER_TOKEN, etc.)
  - BEHAVIORAL: a child spawned with the post-fix env pattern cannot read `GENESIS_API_KEYS`, `OPENROUTER_API_KEY`, or `ZAI_API_KEY`
- `harness/security-adversarial.test.ts` IT-S-09 mitigation variant (PASS)
- `harness/c09c-env-isolation.test.ts` (16 tests PASS) — all 7 sensitive env vars tested

**Current verdict:** `PROVEN_WITH_LIMITATIONS`.

**Justification:** The fix is verified structurally + behaviorally, but NOT via real OpenBot (BLOCKED_BY_ENVIRONMENT — no OpenBot checkout in the audit sandbox). The limitation is honestly disclosed.

**verdictHistorical:** `CONTRADICTED` (G6-09A)
**verdict (current):** `PROVEN_WITH_LIMITATIONS` (G6-09B fix verified)
**remediationCommit:** `98adb8e7131dc2e5a1acea7120b9abc664f5a830`
**retestEvidence:** `harness/post-fix-verification.test.ts` IT-S-09-FIX + `harness/c09c-env-isolation.test.ts` (16 tests) + `harness/security-adversarial.test.ts` IT-S-09 mitigation variant

### C-053 — Mission failureMessage secret leak

**Original G6-09A evidence:** The G6-09 audit at `825888f` found that `mission-service.ts:646` used `error.message.slice(0, 300)` without any pattern scrubbing. A malicious or careless upstream error message (e.g., `Authorization: Bearer ghp_...`) could leak into the public `failureMessage` field. The IT-S-08 test was INCONCLUSIVE.

**Relevant correction:** The G6-09B remediation report CLAIMED C-053 was resolved — but the claims-reconciliation subagent found the fix was NOT actually applied. `mission-service.ts:646` still used `error.message.slice(0, 300)` at `98adb8e`.

**G6-09C correction:** At commit `bff7b0a`, the `scrubSecrets()` function was added to `src/gateway/mission-service.ts:64-96`. It redacts 7 secret patterns (Bearer, ghp_, sk-or-v1-, sk-ant-, sk-, AWS_SECRET_ACCESS_KEY, api_key) from error messages. The function is applied at 3 call sites:
- Line 400: `cleanupError = scrubSecrets(...)`
- Line 459: `closeError = scrubSecrets(...)`
- Line 706: `missionRuntime.failureMessage = scrubSecrets(...)`

**Was the correction tested?** YES.
- `harness/c09c-c053-scrub.test.ts` (10 tests PASS):
  - 7 secret patterns scrubbed from closeError
  - Non-secret context preserved (regression check)
  - STRUCTURAL verification (scrubSecrets function + 3 call sites)
- `harness/c09c-phase2-security-review.test.ts` (12 tests PASS):
  - Multiline messages, JSON-embedded secrets, dependency fetch errors, truncation safety, empty messages, multiple secrets

**Current verdict:** `PROVEN_WITH_LIMITATIONS`.

**Justification:** The fix is verified, but the scrubbing is regex-based (defense-in-depth, not complete protection). Limitations:
- Does not catch obfuscated/split/encoded secrets
- Primary defense is the env allowlist (G6-09B fix)
- Over-scrub risk: permissive patterns may match non-secret text

**verdictHistorical:** `CONTRADICTED` (G6-09A)
**verdict (current):** `PROVEN_WITH_LIMITATIONS` (G6-09C fix at `bff7b0a` verified)
**remediationCommit:** `bff7b0a6f8b4e35880a9c7453d4e6de343e4e001`
**retestEvidence:** `harness/c09c-c053-scrub.test.ts` (10 tests) + `harness/c09c-phase2-security-review.test.ts` (12 tests)

## 3. Recalculated verdictDistribution (consistent across all reports)

```
PROVEN = 26
PROVEN_WITH_LIMITATIONS = 16  (+1 — C-053 upgraded after G6-09C fix)
CONTRADICTED = 1              (-1 — C-053 upgraded; C-013 preserved as historical)
UNVERIFIED = 0
REJECTED = 0
OUT_OF_SCOPE = 2
Total = 45
```

The 1 remaining CONTRADICTED claim (C-013) is a historical record — the defect no longer exists at the integrated commit, but the claim text describes the historical state. This is honest: we do NOT turn a historically-contradicted claim into an unqualified PROVEN claim.

## 4. Consistency check

| Report | Field | Value | Matches actual registry? |
|---|---|---|---|
| `claims-registry-updated.json` | `verdictDistribution` | `{PROVEN:26, PROVEN_WITH_LIMITATIONS:16, CONTRADICTED:1, OUT_OF_SCOPE:2}` | (source of truth) ✓ |
| `04-findings-register.json` | per-finding status | All P1/P2/P3 RESOLVED except G6-09-006 (deferred) | ✓ |
| `01-executive-verdict.md` (G6-09B) | `CRITICAL_CLAIMS_CONTRADICTED = 0` | INCORRECT — should be 1 | ✗ (corrected in G6-09C `10-final-acceptance-verdict.md`) |
| `17-final-enterprise-acceptance-report.md` (G6-09B) | `CRITICAL_CLAIMS_CONTRADICTED = 0` | INCORRECT — should be 1 | ✗ (corrected in G6-09C `10-final-acceptance-verdict.md`) |

The G6-09B reports are HISTORICAL and preserved unchanged. The G6-09C `10-final-acceptance-verdict.md` reports the corrected count.

## 5. Historical vs current verdicts (preserved separately)

Per the G6-09C mandate: "Maintain separate historical and current verdicts when appropriate."

The `claims-registry-updated.json` includes a `verdictHistorical` field for each of the 3 previously-CONTRADICTED claims:
- C-013: `verdictHistorical=CONTRADICTED`, `verdict=CONTRADICTED` (preserved)
- C-051: `verdictHistorical=CONTRADICTED`, `verdict=PROVEN_WITH_LIMITATIONS` (upgraded)
- C-053: `verdictHistorical=CONTRADICTED`, `verdict=PROVEN_WITH_LIMITATIONS` (upgraded)

This preserves the G6-09A rejection as historical evidence while accurately reflecting the current state at the integrated commit.
