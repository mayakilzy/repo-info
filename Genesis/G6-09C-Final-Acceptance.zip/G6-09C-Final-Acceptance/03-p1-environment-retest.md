# 03 — P1 Environment Isolation Re-Test

**G6-09C audit** | Integrated commit: `bff7b0a6f8b4e35880a9c7453d4e6de343e4e001`

## 1. Sensitive env vars tested (per G6-09C mandate Section 3)

All 7 sensitive env vars from the mandate are tested with harmless sentinel values (NEVER real credentials):

| Env var | Sentinel value | Propagated to worker? | Test |
|---|---|---|---|
| `GENESIS_API_KEYS` | `{"sentinel":{"callerId":"sentinel-caller"}}` | NO ✓ | IT-C-ENV-01 |
| `OPENROUTER_API_KEY` | `sk-or-v1-SENTINEL_VALUE_FOR_AUDIT_DEMO_ONLY` | NO ✓ | IT-C-ENV-02 |
| `ZAI_API_KEY` | `sentinel-zai-key` | NO ✓ | IT-C-ENV-03 |
| `ANTHROPIC_API_KEY` | `sk-ant-sentinel-value-for-audit-demo-only` | NO ✓ | IT-C-ENV-04 |
| `OPENAI_API_KEY` | `sk-sentinel-openai-key-for-audit` | NO ✓ | IT-C-ENV-05 |
| `AWS_SECRET_ACCESS_KEY` | `SENTINEL_AWS_SECRET_FOR_AUDIT_DEMO` | NO ✓ | IT-C-ENV-06 |
| `GITHUB_TOKEN` | `ghp_SENTINEL_VALUE_FOR_AUDIT_DEMO_ONLY` | NO ✓ | IT-C-ENV-07 |

**All-at-once test (IT-C-ENV-08):** All 7 sensitive vars NOT propagated simultaneously ✓

## 2. Worker-required vars ARE available (IT-C-ENV-09)

| Var | Available to worker? |
|---|---|
| `PORT` | YES ✓ |
| `COMPUTER_TOKEN` | YES ✓ |
| `WORKSPACE_DIR` | YES ✓ |
| `PROFILES_DIR` | YES ✓ |
| `EGRESS_POLICY_REQUIRED` | YES ✓ (`'0'`) |
| `PATH` | YES ✓ (conditional, only if defined in process.env) |
| `HOME` | YES ✓ (conditional) |

The env allowlist does NOT silently break legitimate OpenBot startup.

## 3. `extraEnv` trust boundary investigation (IT-C-ENV-10, IT-C-ENV-11, IT-C-ENV-12)

### Trace analysis

The flow from user input to `extraEnv`:

1. User submits a mission via HTTP POST `/v1/missions`
2. The mission body goes through `MissionSubmission` → `Goal` → orchestrator
3. The orchestrator calls `runtime.ensureWorker(genome)`
4. The runtime (OpenBotRuntimeAdapter) calls `startComputerProcess(config, botId)`
5. `config.extraEnv` is set by the adapter's constructor (from `buildRealRuntimeFactory`)

**The mission body NEVER touches `config.extraEnv`.** The orchestrator passes the genome (which includes identity, role, objective, etc.) to `ensureWorker`, but the genome does NOT include an `extraEnv` field.

### Who constructs `extraEnv`?

- `buildRealRuntimeFactory()` in `src/gateway/main.ts:150-222` constructs the `OpenBotRuntimeAdapter` with `opts: { checkoutDir, rootDir: missionRootDir }`.
- The adapter's constructor does NOT set `extraEnv` from user input.
- `extraEnv` defaults to `undefined` in the production path.

### Who can modify `extraEnv`?

- Only the operator (via env vars at gateway startup, or by modifying the gateway source).
- The HTTP API does NOT accept `extraEnv` in the mission submission body.
- The A2A server does NOT accept `extraEnv` in the SendMessage mapping.

### Can untrusted goal content influence `extraEnv`?

**NO.** The goal text goes through:
- `GoalCompiler.compile(goal)` → `GoalRequirements`
- `OrganizationPlanner.plan(requirements)` → `OrganizationPlan`
- `GenomeCompiler.compile(plan)` → `WorkerGenome[]`

None of these produce an `extraEnv` field. The genome's fields are: `identity, role, objective, model, skills, tools, computer, memory, budget, autonomy, operationalNeeds` (per `src/contracts/core.ts:297-316`).

### Can external callers inject `extraEnv` values?

**NO.** The HTTP API and A2A server both validate mission submissions against the `MissionSubmission` type (`src/gateway/types.ts:69-90`), which has fields: `outcome, context, constraints, budget, idempotencyKey, label`. No `extraEnv` field.

### Behavioral test (IT-C-ENV-11)

A test confirmed that `extraEnv` CAN technically inject `GENESIS_API_KEYS` IF the caller passes it:
```
const env = buildPostfixEnv({ GENESIS_API_KEYS: '{"injected-via-extraenv":...}' });
const leaked = await spawnStubWorker(env, stubPath);
expect(leaked.GENESIS_API_KEYS).toBe('{"injected-via-extraenv":...}'); // visible
```

This documents the trust boundary: `extraEnv` is trusted infrastructure, NOT untrusted user input.

### Trust boundary conclusion

`extraEnv` is a **TRUSTED test infrastructure override**:
- Constructed by: trusted gateway code (`buildRealRuntimeFactory`)
- Modifiable by: only the operator (via env vars at gateway startup)
- Untrusted goal content: CANNOT influence `extraEnv` (the goal goes through the orchestrator, not the runtime factory)
- External callers: CANNOT inject `extraEnv` values (the HTTP API doesn't accept `extraEnv`)

This is acceptable. But it IS a defense-in-depth concern: if a future code path allows untrusted input to reach `extraEnv`, the allowlist would be bypassed.

### Recommendation (G6-09C-002, P3, defense-in-depth)

Add a runtime check in `startComputerProcess` that warns or rejects if `extraEnv` contains sensitive key names (`GENESIS_API_KEYS`, `OPENROUTER_API_KEY`, `ZAI_API_KEY`, etc.). This would close the defense-in-depth gap.

## 4. Test results (16/16 PASS)

Test file: `harness/c09c-env-isolation.test.ts`

| Test ID | Scenario | Result |
|---|---|---|
| IT-C-ENV-01..07 | Each sensitive env var NOT propagated (7 tests) | PASS |
| IT-C-ENV-08 | All 7 sensitive vars NOT propagated simultaneously | PASS |
| IT-C-ENV-09 | Worker-required vars (PORT, COMPUTER_TOKEN, etc.) ARE available | PASS |
| IT-C-ENV-10 | extraEnv IS propagated (trusted test infrastructure) | PASS |
| IT-C-ENV-11 (structural) | Source applies extraEnv AFTER the allowlist (trust boundary documented) | PASS |
| IT-C-ENV-11 (behavioral) | extraEnv CAN technically inject GENESIS_API_KEYS (trust boundary documented) | PASS |
| IT-C-ENV-12 (structural) | WorkerGenome contract does NOT include extraEnv field | PASS |
| IT-C-ENV-12 (structural) | extraEnv is on ComputerProcessConfig (runtime-internal) | PASS |
| IT-C-ENV-12 (behavioral) | Malicious goal text does NOT cause extraEnv injection | PASS |
| (summary) | Trust boundary and defense-in-depth concern documented | PASS |

## 5. Acceptance

> "No untrusted caller, goal, skill, tool result or worker definition may inject gateway secrets into a worker environment."

**PASS.** No untrusted input path can reach `extraEnv`. The env allowlist correctly blocks all 7 sensitive env vars from being propagated via the `...process.env` spread (which is now removed).

> "The corrected environment policy must not silently break legitimate OpenBot startup."

**PASS.** Worker-required vars (PORT, COMPUTER_TOKEN, WORKSPACE_DIR, PROFILES_DIR, EGRESS_POLICY_REQUIRED, PATH, HOME) are all available.

## 6. P1-B verdict

**P1_ENVIRONMENT_ISOLATION = PASS** (with documented defense-in-depth concern G6-09C-002)

- All 7 sensitive env vars NOT propagated ✓
- Worker-required vars available ✓
- `extraEnv` trust boundary documented and tested ✓
- No untrusted input path to `extraEnv` ✓
- Recommendation: add a runtime check for sensitive names in `extraEnv` (defense-in-depth)
