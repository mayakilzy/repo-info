/**
 * G6-09C — P1-A Shutdown Re-Review Tests
 *
 * Per the G6-09C mandate Section 3 (P1-A — Shutdown Timeout):
 *
 *   "Promise.race() can stop waiting for a cleanup operation without
 *    actually stopping the underlying operation."
 *
 * This file tests the G6-09B remediation's actual behavior against the 10
 * scenarios mandated. The key insight: we don't just check the returned
 * ShutdownResult fields — we ALSO check:
 *   - Actual elapsed time (must be bounded by deadlineMs)
 *   - Actual liveness of orphaned operations (via tracking close() call counts)
 *   - Honest reporting (no false-success when cleanup is incomplete)
 *
 * Scenarios covered:
 *   IT-C-01 — One runtime hangs indefinitely (regression of IT-07-FIX)
 *   IT-C-02 — MULTIPLE runtimes hang — total time must NOT grow unboundedly
 *   IT-C-03 — Runtime cleanup rejects (throws an error)
 *   IT-C-04 — Runtime cleanup finishes JUST BEFORE the deadline (success path)
 *   IT-C-05 — Runtime cleanup finishes JUST AFTER the deadline (timeout path)
 *   IT-C-06 — SIGTERM arrives twice (idempotency — tested at the service level)
 *   IT-C-07 — An active mission completes during shutdown (race with natural completion)
 *
 * Scenarios NOT testable in this environment (require real process spawning):
 *   IT-C-08 — A detached worker survives its initial termination request
 *   IT-C-09 — A worker ignores SIGTERM (SIGKILL escalation)
 *   IT-C-10 — The gateway reaches its overall shutdown deadline (covered by IT-C-01)
 *
 * For IT-C-08/09, we document the gap and recommend subprocess-level testing
 * in a follow-up.
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { MissionService } from '../../../genesis-audit/worktree/genesis/src/gateway/mission-service.js';
import type { CallerIdentity } from '../../../genesis-audit/worktree/genesis/src/gateway/types.js';
import type { RuntimeHandle, WorkerGenome, ReasoningProvider, ReasoningInput, ReasoningOutput } from '../../../genesis-audit/worktree/genesis/src/contracts/core.js';
import type { ArtifactsProvider, ArtifactSnapshot, WorkerComputer, WorkerRuntime, WorkerSurfaces } from '../../../genesis-audit/worktree/genesis/src/runtime/computer.js';
import * as path from 'node:path';

const GENESIS_ROOT = '/home/z/my-project/genesis-audit/worktree/genesis';
const OWNERSHIP_PATH = path.join(GENESIS_ROOT, 'data/ownership.yaml');

// ---------------------------------------------------------------------------
// Stub runtime with full close-behavior control
// ---------------------------------------------------------------------------

class C09CStubComputer implements WorkerComputer {
  async exec(command: string) {
    return { command, exitCode: 0, stdout: '', stderr: '', timedOut: false, elapsedMs: 1 };
  }
  async writeFile(p: string, contents: string) {
    return { path: p, bytes: contents.length, appended: false };
  }
  async readFile(p: string) {
    return { path: p, text: '', bytes: 0, truncated: false };
  }
  async listFiles() {
    return [];
  }
}

/**
 * C09CStubRuntime — adversarial stub with full close() control.
 * Tracks: closeCalled, closeCallOrder, closeStartedAt, closeResolvedAt.
 */
class C09CStubRuntime implements WorkerRuntime, ArtifactsProvider {
  readonly name: string;
  readonly workers = new Map<string, { stopped: boolean; computer: C09CStubComputer }>();
  public closeCalled = false;
  public closeCallOrder = 0;  // increment on each close() call
  public closeStartedAt = 0;
  public closeResolvedAt: number | undefined;
  public closeBehavior: 'ok' | 'throw' | 'hang' | 'resolve-after' = 'ok';
  public closeResolveAfterMs = 0;
  public static closeCallCounter = 0;  // shared across instances for ordering

  constructor(name: string = 'c09c-stub') {
    this.name = name;
  }

  async ensureWorker(genome: WorkerGenome): Promise<RuntimeHandle> {
    if (!this.workers.has(genome.identity.id)) {
      this.workers.set(genome.identity.id, { stopped: false, computer: new C09CStubComputer() });
    }
    return { workerId: genome.identity.id, ref: `stub:${genome.identity.id}` };
  }

  computer(handle: RuntimeHandle): WorkerComputer {
    const w = this.workers.get(handle.workerId);
    if (!w) throw new Error(`no computer for ${handle.workerId}`);
    return w.computer;
  }

  surfaces(handle: RuntimeHandle): WorkerSurfaces {
    const w = this.workers.get(handle.workerId);
    return w === undefined ? {} : { computer: w.computer };
  }

  async stopWorker(handle: RuntimeHandle): Promise<void> {
    const w = this.workers.get(handle.workerId);
    if (!w) return;
    w.stopped = true;
  }

  async close(): Promise<void> {
    this.closeCalled = true;
    this.closeCallOrder = ++C09CStubRuntime.closeCallCounter;
    this.closeStartedAt = Date.now();

    if (this.closeBehavior === 'throw') {
      throw new Error('simulated close() failure (adversarial)');
    }
    if (this.closeBehavior === 'hang') {
      // Never resolves — simulates a stuck OpenBot process
      await new Promise<void>(() => { /* never resolves */ });
      return; // unreachable, but TypeScript needs it
    }
    if (this.closeBehavior === 'resolve-after') {
      await new Promise<void>((resolve) => setTimeout(resolve, this.closeResolveAfterMs));
      this.closeResolvedAt = Date.now();
      for (const [, w] of this.workers) w.stopped = true;
      return;
    }
    // ok
    this.closeResolvedAt = Date.now();
    for (const [, w] of this.workers) w.stopped = true;
  }

  async listArtifacts(): Promise<readonly ArtifactSnapshot[]> {
    return [];
  }
}

class C09CScriptedReasoning implements ReasoningProvider {
  readonly name = 'c09c-scripted';
  public calls = 0;
  constructor(public responses: string[] = ['ok']) {}
  async reason() {
    const text = this.responses[this.calls % this.responses.length];
    this.calls += 1;
    return { text };
  }
}

const CALLER_A: CallerIdentity = {
  callerId: 'caller-a',
  allowedOperations: ['mission:submit', 'mission:cancel', 'mission:get'],
  maxActiveMissions: 5,
  maxMissionTimeoutMs: 60_000,
};

function makeServiceOptions(rt: WorkerRuntime, reasoning: ReasoningProvider, overrides: Record<string, unknown> = {}) {
  return {
    defaultMissionTimeoutMs: 5_000,
    runtimeFactory: () => ({ runtime: rt }),
    reasoningFactory: () => reasoning,
    sweepIntervalMs: 0,
    ownershipPath: OWNERSHIP_PATH,
    ...overrides,
  };
}

// Reset the close-call counter before each test to avoid cross-test pollution
function resetCloseCounter() {
  C09CStubRuntime.closeCallCounter = 0;
}

// ===========================================================================
// IT-C-01 — One runtime hangs indefinitely (regression check)
// ===========================================================================

describe('G6-09C / IT-C-01 — one runtime hangs indefinitely', () => {
  beforeEach(() => resetCloseCounter());
  it('shutdown(500) with hanging close() completes within ~600ms and reports timeout', async () => {
    const rt = new C09CStubRuntime('hang-1');
    rt.closeBehavior = 'hang';
    const service = new MissionService(makeServiceOptions(rt, new C09CScriptedReasoning(['ok']), {
      defaultMissionTimeoutMs: 1_000,
    }));

    service.start({ outcome: 'simple goal' }, CALLER_A);
    await new Promise((r) => setTimeout(r, 50));

    const start = Date.now();
    const result = await service.shutdown(500);
    const elapsed = Date.now() - start;

    // HONEST reporting: shutdown completed within bounded time
    expect(elapsed).toBeLessThan(1_500);
    expect(elapsed).toBeGreaterThanOrEqual(400);

    // close() WAS called (the safety-net path was reached)
    expect(rt.closeCalled).toBe(true);
    expect(rt.closeCallOrder).toBe(1);

    // Structured result correctly reports the timeout
    expect(result.clean).toBe(false);
    expect(result.runtimeAdapterCloseErrors).toBe(1);
    expect(result.perRuntime[0].closeError).toContain('timeout after');
    expect(result.perRuntime[0].closed).toBe(false);

    service.close();
  }, 10_000);
});

// ===========================================================================
// IT-C-02 — MULTIPLE runtimes hang — total time must NOT grow unboundedly
// ===========================================================================

describe('G6-09C / IT-C-02 — multiple runtimes hang — total time bounded', () => {
  beforeEach(() => resetCloseCounter());

  it('shutdown with 5 hanging runtimes completes within deadline + overhead', async () => {
    // Construct 5 stub runtimes that ALL hang on close()
    const rts: C09CStubRuntime[] = [];
    for (let i = 0; i < 5; i++) {
      const rt = new C09CStubRuntime(`hang-${i}`);
      rt.closeBehavior = 'hang';
      rts.push(rt);
    }

    // Use a shared service — but each mission gets its own runtime via factory
    let rtIndex = 0;
    const service = new MissionService({
      defaultMissionTimeoutMs: 1_000,
      runtimeFactory: () => ({ runtime: rts[rtIndex++ % rts.length] }),
      reasoningFactory: () => new C09CScriptedReasoning(['ok']),
      sweepIntervalMs: 0,
      ownershipPath: OWNERSHIP_PATH,
    });

    // Submit 5 missions (each will get a different runtime)
    for (let i = 0; i < 5; i++) {
      service.start({ outcome: `goal ${i}` }, CALLER_A);
    }
    await new Promise((r) => setTimeout(r, 100));

    const start = Date.now();
    const deadline = 2_000;
    const result = await service.shutdown(deadline);
    const elapsed = Date.now() - start;

    // CRITICAL: total time must NOT grow unboundedly with N runtimes
    // With 5 runtimes each getting up to 2s, naive sequential would take 10s.
    // The fix uses per-runtime deadline = min(2000, deadlineMs - elapsedSoFar),
    // so the total is bounded by deadlineMs.
    expect(elapsed).toBeLessThan(deadline + 1_000); // bounded by deadline + small overhead
    expect(elapsed).toBeGreaterThanOrEqual(500); // at least one close attempt

    // All 5 runtimes had close() called
    expect(rts.every((rt) => rt.closeCalled)).toBe(true);

    // All 5 are reported as timed out (closed=false, closeError='timeout after')
    expect(result.runtimeAdapterCloseErrors).toBe(5);
    expect(result.runtimeAdaptersClosed).toBe(0);
    expect(result.clean).toBe(false);

    // The close-call order is sequential (1, 2, 3, 4, 5) — proving the close
    // pass is sequential but bounded
    const callOrders = rts.map((rt) => rt.closeCallOrder).sort((a, b) => a - b);
    expect(callOrders).toEqual([1, 2, 3, 4, 5]);

    service.close();
  }, 15_000);
});

// ===========================================================================
// IT-C-03 — Runtime cleanup rejects (throws an error)
// ===========================================================================

describe('G6-09C / IT-C-03 — runtime cleanup rejects', () => {
  beforeEach(() => resetCloseCounter());

  it('close() throwing is captured and does not propagate as unhandled rejection', async () => {
    const rt = new C09CStubRuntime('throwing-close');
    rt.closeBehavior = 'throw';
    const service = new MissionService(makeServiceOptions(rt, new C09CScriptedReasoning(['ok'])));

    service.start({ outcome: 'simple goal' }, CALLER_A);
    await new Promise((r) => setTimeout(r, 50));

    let unhandledRejection = false;
    const handler = () => { unhandledRejection = true; };
    process.on('unhandledRejection', handler);

    const result = await service.shutdown(2_000);

    // Give time for any async rejection to surface
    await new Promise((r) => setTimeout(r, 100));
    process.off('unhandledRejection', handler);

    // close() WAS called
    expect(rt.closeCalled).toBe(true);

    // Structured result captures the rejection
    expect(result.runtimeAdapterCloseErrors).toBe(1);
    expect(result.clean).toBe(false);
    expect(result.perRuntime[0].closeError).toContain('simulated close() failure');
    expect(result.perRuntime[0].closed).toBe(false);

    // No unhandled rejection (the try/catch around Promise.race captured it)
    expect(unhandledRejection).toBe(false);

    service.close();
  }, 10_000);
});

// ===========================================================================
// IT-C-04 — Runtime cleanup finishes JUST BEFORE the deadline (success path)
// ===========================================================================

describe('G6-09C / IT-C-04 — cleanup finishes just before deadline', () => {
  beforeEach(() => resetCloseCounter());

  it('close() resolving at deadline-100ms reports closed=true and clean=true', async () => {
    const rt = new C09CStubRuntime('slow-but-successful');
    rt.closeBehavior = 'resolve-after';
    rt.closeResolveAfterMs = 400; // resolves at 400ms
    const service = new MissionService(makeServiceOptions(rt, new C09CScriptedReasoning(['ok'])));

    service.start({ outcome: 'simple goal' }, CALLER_A);
    await new Promise((r) => setTimeout(r, 50));

    const start = Date.now();
    // perRuntimeDeadline = min(2000, 1000 - 50) = 1000ms (deadline is 1000ms)
    // close() resolves at 400ms < 1000ms deadline → closed=true
    const result = await service.shutdown(1_000);
    const elapsed = Date.now() - start;

    expect(rt.closeCalled).toBe(true);
    expect(rt.closeResolvedAt).toBeGreaterThan(rt.closeStartedAt); // actually resolved
    expect(result.perRuntime[0].closed).toBe(true);
    expect(result.perRuntime[0].closeError).toBeUndefined();
    // Note: result.clean depends on whether the mission drained too.
    // The runtime close path is clean.
    expect(result.runtimeAdapterCloseErrors).toBe(0);
    expect(result.runtimeAdaptersClosed).toBe(1);

    service.close();
  }, 10_000);
});

// ===========================================================================
// IT-C-05 — Runtime cleanup finishes JUST AFTER the deadline (timeout path)
// ===========================================================================

describe('G6-09C / IT-C-05 — cleanup finishes just after deadline', () => {
  beforeEach(() => resetCloseCounter());

  it('close() resolving at deadline+200ms reports timeout (closed=false)', async () => {
    const rt = new C09CStubRuntime('too-slow');
    rt.closeBehavior = 'resolve-after';
    rt.closeResolveAfterMs = 1_500; // resolves at 1500ms
    const service = new MissionService(makeServiceOptions(rt, new C09CScriptedReasoning(['ok'])));

    service.start({ outcome: 'simple goal' }, CALLER_A);
    await new Promise((r) => setTimeout(r, 50));

    const start = Date.now();
    // perRuntimeDeadline = min(2000, 500 - 50) = 500ms (deadline is 500ms)
    // close() resolves at 1500ms > 500ms deadline → timeout reported
    const result = await service.shutdown(500);
    const elapsed = Date.now() - start;

    // HONEST: shutdown completed within bounded time
    expect(elapsed).toBeLessThan(1_500);

    // close() WAS called
    expect(rt.closeCalled).toBe(true);

    // Structured result reports the timeout (closed=false, closeError='timeout after')
    expect(result.perRuntime[0].closed).toBe(false);
    expect(result.perRuntime[0].closeError).toContain('timeout after');
    expect(result.clean).toBe(false);
    expect(result.runtimeAdapterCloseErrors).toBe(1);

    // CRITICAL CONCERN: the underlying close() operation is STILL PENDING.
    // Promise.race stopped waiting, but close() will eventually resolve at 1500ms.
    // This is the G6-09C Section 3 concern: "Promise.race() can stop waiting
    // for a cleanup operation without actually stopping the underlying operation."
    //
    // Verify the close() eventually resolves (proving the underlying operation
    // continues — but the structured result accurately reported the timeout).
    await new Promise((r) => setTimeout(r, 2_000));
    expect(rt.closeResolvedAt).toBeDefined();
    expect(rt.closeResolvedAt! - rt.closeStartedAt).toBeGreaterThanOrEqual(1_400);

    service.close();
  }, 15_000);
});

// ===========================================================================
// IT-C-06 — SIGTERM arrives twice (idempotency at the service level)
// ===========================================================================

describe('G6-09C / IT-C-06 — repeated shutdown calls are idempotent at the service level', () => {
  beforeEach(() => resetCloseCounter());

  it('calling service.shutdown() twice — documents runtime-close idempotency requirement', async () => {
    const rt = new C09CStubRuntime('idempotent');
    rt.closeBehavior = 'ok';
    const service = new MissionService(makeServiceOptions(rt, new C09CScriptedReasoning(['ok'])));

    service.start({ outcome: 'simple goal' }, CALLER_A);
    await new Promise((r) => setTimeout(r, 50));

    // Call shutdown twice in quick succession
    const [result1, result2] = await Promise.all([
      service.shutdown(2_000),
      service.shutdown(2_000),
    ]);

    // FINDING (G6-09C-001, P3, defense-in-depth): MissionService.shutdown()
    // is NOT idempotent at the runtime-close level. The `seenRuntimes` Set is
    // LOCAL to each shutdown call, so both calls invoke close() on the same
    // runtime. The runtime adapter's close() MUST be idempotent to handle this.
    //
    // For production (OpenBotRuntimeAdapter), close() is idempotent (stops all
    // remaining workers; no-op if none). For dev mode (MemoryRuntime), close()
    // is absent (the optional `close?()` method is not implemented).
    //
    // This is a defense-in-depth concern, NOT a behavior defect. The structured
    // result is still correct (both calls report the same runtime state).
    expect(rt.closeCalled).toBe(true);
    // close() may be called once or twice — both are acceptable as long as
    // the runtime adapter's close() is idempotent.
    expect(rt.closeCallOrder).toBeGreaterThanOrEqual(1);
    expect(rt.closeCallOrder).toBeLessThanOrEqual(2);

    // Both shutdown calls return structured results
    expect(result1).toBeDefined();
    expect(result2).toBeDefined();

    service.close();
  }, 10_000);
});

// ===========================================================================
// IT-C-07 — An active mission completes during shutdown (race with natural completion)
// ===========================================================================

describe('G6-09C / IT-C-07 — active mission completes during shutdown', () => {
  beforeEach(() => resetCloseCounter());

  it('a mission that completes naturally during the drain pass is reported as drained', async () => {
    const rt = new C09CStubRuntime('natural-completion');
    rt.closeBehavior = 'ok';
    // Use a reasoning provider that responds quickly so the mission completes naturally
    const fastReasoning = new C09CScriptedReasoning(['ok']);
    const service = new MissionService(makeServiceOptions(rt, fastReasoning, {
      defaultMissionTimeoutMs: 5_000,
    }));

    const start = service.start({ outcome: 'simple goal' }, CALLER_A);
    // Wait briefly so the orchestrator starts and the mission can complete
    await new Promise((r) => setTimeout(r, 1_500)); // give it time to complete naturally

    // At this point the mission should be terminal
    const snapshot = service.get(start.missionId, CALLER_A);
    const statusBeforeShutdown = snapshot.status;

    // Now call shutdown — the mission is already terminal
    const result = await service.shutdown(2_000);

    // The mission was NOT in activeSnapshots (it was terminal)
    // So it doesn't appear in perMission
    expect(result.perMission.length).toBe(0);

    // The runtime close() still ran (safety net)
    expect(rt.closeCalled).toBe(true);

    service.close();
  }, 10_000);
});

// ===========================================================================
// IT-C-08 / IT-C-09 / IT-C-10 — Documented as deferred (require real process)
// ===========================================================================

describe('G6-09C / deferred scenarios — require real process spawning', () => {
  it('IT-C-08 (detached worker survives initial termination) — DEFERRED', () => {
    // This scenario requires spawning a real child process with `detached: true`,
    // sending SIGTERM, and verifying the process is still alive after the
    // shutdown handler returns. It cannot be tested with in-process stubs.
    // Documented as a coverage gap.
    expect(true).toBe(true); // placeholder
  });

  it('IT-C-09 (worker ignores SIGTERM, SIGKILL escalation) — DEFERRED', () => {
    // This requires a real child process that ignores SIGTERM and asserts
    // SIGKILL fires after the 2s grace period (computer-process.ts:265-275).
    // The 2s SIGKILL escalation code path is correct by inspection but
    // untested at the subprocess level.
    expect(true).toBe(true); // placeholder
  });

  it('IT-C-10 (gateway reaches overall shutdown deadline) — covered by IT-C-01/IT-C-02', () => {
    // The overall shutdown deadline behavior is verified by IT-C-01 (single
    // hanging runtime completes within 1.5s) and IT-C-02 (5 hanging runtimes
    // complete within deadline + overhead).
    expect(true).toBe(true); // placeholder
  });
});

// ===========================================================================
// Summary: the Promise.race limitation (per G6-09C mandate Section 3)
// ===========================================================================

describe('G6-09C / Promise.race limitation — honest reporting', () => {
  /**
   * The G6-09C mandate explicitly calls out:
   *   "Promise.race() can stop waiting for a cleanup operation without
   *    actually stopping the underlying operation."
   *
   * This is TRUE for the G6-09B remediation. The fix:
   *   - Wraps close() in Promise.race with a per-runtime deadline ✓
   *   - Reports the timeout honestly (closeError='timeout after Xms') ✓
   *   - Sets closed=false (no false success) ✓
   *   - Structured ShutdownResult.clean reflects unclean state ✓
   *   - main.ts:407 exits 1 when clean=false ✓
   *
   * What it does NOT do:
   *   - Actually cancel the underlying close() operation (Promise.race doesn't cancel)
   *   - SIGKILL any orphaned worker process (the runtime adapter would need to know the PID)
   *
   * Acceptance: the honest reporting + non-zero exit code lets the operator
   * detect and investigate orphaned workers. A complete fix would also
   * attempt to SIGKILL the worker after the timeout, but that requires
   * runtime-adapter-level changes (not just MissionService changes).
   *
   * This is acceptable for CONDITIONAL_ACCEPT — the structured result is
   * truthful, the exit code is truthful, and the operator can investigate.
   */

  it('IT-C-05 confirms: the underlying close() continues after the timeout (documented limitation)', async () => {
    // This is a documentation test — the actual behavior is verified in IT-C-05.
    // The key point: Promise.race doesn't cancel the underlying operation.
    // The fix is HONEST about this (reports timeout, doesn't claim success).
    expect(true).toBe(true);
  });
});
