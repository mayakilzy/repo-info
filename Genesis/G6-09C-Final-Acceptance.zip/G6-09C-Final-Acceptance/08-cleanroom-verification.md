# 08 — Cleanroom Verification

**G6-09C audit** | Integrated commit: `bff7b0a6f8b4e35880a9c7453d4e6de343e4e001`

## 1. Cleanroom reproduction commands

Per the G6-09C mandate Section 8, the following commands were run on the integrated commit `bff7b0a`:

```bash
npm ci
npm run typecheck
npm run lint
npx eslint .
npm test
```

## 2. Per-command results

### npm ci

```
added 218 packages in 3s
NPM_CI_EXIT=0
```

218 packages, 0 vulnerabilities reported. Clean install from `package-lock.json`.

### npm run typecheck

```
> tsc --noEmit
TYPECHECK_EXIT=0
```

No TypeScript errors. Production source compiles cleanly.

### npm run lint

```
> eslint .
LINT_EXIT=0
```

`npm run lint` returns exit 0.

### npx eslint . (direct, bypassing npm)

```
ESLINT_DIRECT_EXIT=0
```

Direct eslint invocation confirms clean lint. No production source errors.

### npm test

```
Test Files  69 passed (69)
Tests       590 passed | 9 skipped (599)
Duration    27.49s (tests 83%, import 11%, transform 4%, worker 1%)
TEST_EXIT=0
```

Matches the G6-08-R1 baseline (590/9) exactly. No regression introduced by the G6-09B + G6-09C remediation.

## 3. Independent harness verification

### G6-09 independent tests (9 files, 98 tests)

```
Test Files  9 passed (9)
Tests       98 passed (98)
Duration    ~30s
INDEPENDENT_EXIT=0
```

#### Breakdown by file

| Test file | Tests | Status |
|---|---|---|
| `c09c-campaign-k.test.ts` | 9 | PASS (Campaign K — GLM-assisted) |
| `c09c-shutdown-retest.test.ts` | 11 | PASS (P1-A retest) |
| `independent-adversarial.test.ts` | 12 | PASS (G6-09A original defect-demonstration) |
| `tier2-regression.test.ts` | 18 | PASS (G6-09B Tier 2 regression) |
| `security-adversarial.test.ts` | 4 | PASS (G6-09A security) |
| `post-fix-verification.test.ts` | 6 | PASS (G6-09B fix verification) |
| `c09c-phase2-security-review.test.ts` | 12 | PASS (G6-09C Phase 2 adversarial) |
| `c09c-c053-scrub.test.ts` | 10 | PASS (G6-09C C-053 scrub) |
| `c09c-env-isolation.test.ts` | 16 | PASS (G6-09C env isolation) |
| **Total** | **98** | **98 PASS** |

## 4. Skipped tests (9)

The 9 skipped tests are environment-gated (per `engine-v1-known-limitations.md`):
- Live OpenBot integration tests (require `$GENESIS_OPENBOT_DIR` env var)
- Live ZAI reasoning tests (require `ZAI_API_KEY` or `ZAI_SDK_PATH`)
- Live OpenDots / OpenMuse tests (require upstream service checkouts)

These are NOT regression — they are environment-blocked and remain BLOCKED_BY_ENVIRONMENT.

## 5. GitHub Actions CI verification

| Check | Value |
|---|---|
| Commit | `bff7b0a6f8b4e35880a9c7453d4e6de343e4e001` |
| Check run name | `test` |
| Status | `completed` |
| Conclusion | `success` ✓ |

**REMOTE_CI = success** (verified against the actual integrated commit, NOT the historical remediation commit)

## 6. Cleanroom verdict

| Check | Result |
|---|---|
| npm ci | PASS (218 packages, exit 0) |
| typecheck | PASS (exit 0) |
| lint | PASS (exit 0) |
| eslint direct | PASS (exit 0) |
| npm test | PASS (590/9, exit 0) |
| Independent harness | PASS (98/98) |
| GitHub Actions CI | PASS (conclusion=success) |

**CLEANROOM_VERIFICATION = PASS**

The integrated commit `bff7b0a` is reproducible: same baseline (590/9), same typecheck/lint/eslint PASS, same CI success. No regression introduced by the G6-09B + G6-09C remediation.
