# 01 — Patch Review

**G6-09C audit** | Integrated commit: `bff7b0a6f8b4e35880a9c7453d4e6de343e4e001`

## 1. Patch overview

The G6-09C integrated patch is the union of two remediation commits applied on top of the G6-08-R1 baseline (`825888f`):

| Commit | SHA | Description |
|---|---|---|
| G6-09B | `98adb8e7131dc2e5a1acea7120b9abc664f5a830` | Remediate two P1 defects + Tier 2 defense-in-depth |
| G6-09C | `bff7b0a6f8b4e35880a9c7453d4e6de343e4e001` | Fix C-053 — scrub secrets from failureMessage/cleanupError/closeError |

**Files changed (cumulative):** 4 files, +158 insertions, -15 deletions

| File | G6-09B change | G6-09C change | Total lines |
|---|---|---|---|
| `src/runtime/openbot/computer-process.ts` | +25 -2 (env allowlist) | (unchanged) | +25 -2 |
| `src/gateway/mission-service.ts` | +43 -9 (per-runtime timeout) | +63 -3 (scrubSecrets) | +106 -12 |
| `src/gateway/a2a-server.ts` | +14 -8 (A2A fallback) | (unchanged) | +14 -8 |
| `src/worker/worker-agent.ts` | +37 -1 (command policy) | (unchanged) | +37 -1 |

The full diff is at `harness/g6-09c-integrated.patch` (13,167 bytes, 178 lines of diff).

## 2. Patch base and target verification

- **Patch base:** `825888f` (G6-08-R1 baseline)
- **Patch target:** `bff7b0a` (G6-09C integrated)
- **Ancestry verified:** `bff7b0a` parent is `98adb8e`, whose parent is `825888f` ✓
- **Fast-forward possible:** YES (no divergence between baseline and remediation branch)
- **Conflicts encountered:** NONE (clean fast-forward merge)

## 3. Per-commit review

### G6-09B (commit 98adb8e) — Remediate two P1 defects + Tier 2

**P1-A — Shutdown timeout (G6-09-001):**
- File: `src/gateway/mission-service.ts:359-411`
- Change: Wrapped each `await rt.runtime.close()` in `Promise.race([close(), setTimeout(perRuntimeDeadline)])` with per-runtime deadline = `min(2000, deadlineMs - elapsedSoFar)`.
- Honest reporting: if timeout wins, `closeError='timeout after Xms'`, `closed=false`, structured `ShutdownResult.clean=false`, gateway exits 1.
- Residual concern: `Promise.race` does NOT cancel the underlying operation (documented in `02-p1-shutdown-retest.md`).

**P1-B — Worker env isolation (G6-09-S01):**
- File: `src/runtime/openbot/computer-process.ts:175-200`
- Change: Replaced `env: { ...process.env, ...workerSpecificVars }` with explicit allowlist: `PORT, COMPUTER_TOKEN, WORKSPACE_DIR, PROFILES_DIR, EGRESS_POLICY_REQUIRED, PATH?, HOME?, USER?, SHELL?, LANG?, LC_ALL?, ...config.extraEnv`.
- Trust boundary: `config.extraEnv` is trusted test infrastructure (constructed by gateway code, NOT reachable from untrusted input). Documented in `03-p1-environment-retest.md`.

**P2/P3 — Tier 2 defense-in-depth:**
- `src/worker/worker-agent.ts:303-333`: Extended `checkCommandPolicy` with 5 adversarial patterns (nc -e, python -c, find / -delete, > /etc/, chmod 777 /etc).
- `src/gateway/a2a-server.ts:514-535`: A2A User fallback now returns null (rejects unknown User implementations).

### G6-09C (commit bff7b0a) — Fix C-053

**C-053 — failureMessage secret scrubbing:**
- File: `src/gateway/mission-service.ts:64-96` (new function) + 3 call sites at lines 400, 459, 706
- Change: Added `scrubSecrets()` function that redacts 7 secret patterns (Bearer, ghp_, sk-or-v1-, sk-ant-, sk-, AWS_SECRET_ACCESS_KEY, api_key) from error messages before they're stored in `failureMessage`, `cleanupError`, `closeError`.
- Honest disclosure: regex-based, not complete protection (documented in `evidence/c5-claims-reconciliation.md` and `02-p1-shutdown-retest.md`).

## 4. No destructive Git operations

- No force-push: confirmed (push output shows `825888f..bff7b0a` non-forced update)
- No history rewrite: confirmed (fast-forward only)
- No external repository modification: confirmed (only `mayakilzy/AgentCraft-Genesis` was pushed; `mayakilzy/repo-info` will receive the evidence ZIP only — that's the operator's personal evidence archive, not a target repo)
- Historical G6-09A archive preserved at `/home/z/my-project/genesis-audit/g6-09b-archive/` and at the remote `repo-info/Genesis/G6-09-Independent-Qualification.zip` (NOT overwritten)

## 5. Patch verdict

The patch is **SAFE, MINIMAL, and VERIFIED**:
- Safe: no destructive operations, no force-push, no history rewrite
- Minimal: +158/-15 lines across 4 files; no scope creep
- Verified: 590/9 baseline preserved + 98/98 independent tests PASS + GitHub Actions CI GREEN

Recommendation: **APPROVE FOR RELEASE** at commit `bff7b0a` on branch `build/group-06-productionization` (subject to the operational conditions in `09-residual-risks.md`).
