# G6-09C Final Acceptance — Evidence Package Manifest

**Audit date:** 2026-10-08
**Baseline SHA:** 825888fe45326573d9bfc5157f78ada9cd533b20
**Remediation SHA:** 98adb8e7131dc2e5a1acea7120b9abc664f5a830
**Integrated SHA:** bff7b0a6f8b4e35880a9c7453d4e6de343e4e001
**Auditor:** GLM (Independent Principal Engineer)
**Post-integration verdict:** CONDITIONAL_ACCEPT

## Top-level files

| File | SHA-256 | Bytes |
|---|---|---|
| 00-execution-summary.md | 2ecfbbb710c13cef17ebbfcbca2b34b5856fa3faf7389429b34c1041f7f4647b | 4071 |
| 01-patch-review.md | 4b42371745e9c0c89e9142475cbf988486ec5e32395fa9d32908de737b0826e4 | 4587 |
| 02-p1-shutdown-retest.md | 435759434085228f4094b2eb1f864c03294a4bffa3c25287b1a3cdc51c102acd | 6093 |
| 03-p1-environment-retest.md | 28049b8e48e53fcaa9842628cc52269cf843fed10cbc9fd9e03b35b6168ac53b | 6904 |
| 04-p2-p3-regression.md | 2230b68ff0bd5a0a142998de213d99c15366a4cdcc07ed1c92db6aa7153df8da | 4463 |
| 05-claims-reconciliation.md | f110a5a231f19b7d8e3dc89760994474671acb3d7f44dcf25dd95d93ab71cc36 | 8922 |
| 06-campaign-k-results.md | 34f1ad7848a88ff99943bc73b12fd656a81840e246d97434f8003467251b563a | 8993 |
| 07-integration-provenance.md | 47899669a9303426ce2e8d8669124cca36b2a7ca1bf044c74e229e3ef0638b53 | 3777 |
| 08-cleanroom-verification.md | c659287d3deae11a609c0ca06aa1a5d7089fb25b5294705262d88b13f7c558d6 | 3330 |
| 09-residual-risks.md | e10a06470f05efebd482c901100b259d4df3396c63492f0a0344604eea9902f4 | 8274 |
| 10-final-acceptance-verdict.md | b56965893cea02aa2c9118f71bbe545f448936cf1ff7cc28a60f38faabf0069f | 8030 |
| claims-registry-updated.json | 4d31675affda1dcba162bd41f95393f00cabfaaad5ae36b9330a834501654733 | 45017 |
| findings.json | bccc26b76270260e4ec55a26073f0213ee7ce0b35e635782254c636ab7cf11b0 | 5288 |

## evidence/ directory

| File | SHA-256 | Bytes |
|---|---|---|
| c5-claims-reconciliation.md | 165b9f914f92279daed2f65956e0406a3ae0d0b556c0f052c719b63a440124b7 | 25634 |

## harness/ directory

| File | SHA-256 | Bytes |
|---|---|---|
| c09c-c053-scrub-output.txt | 382b0542edab8f6ac6ff9523838f565705861ffcf99ee41a884475671d8fdfaa | 256 |
| c09c-c053-scrub.test.ts | c232d2a4634f2a0aacea6c3120796f39c6b1bb38b08dc2b4d4b2a705798225b4 | 8704 |
| c09c-campaign-k-output.txt | 0e3925b2c7e857f44ec3c5935923a8980928701f4d055cf5e77732ae44518196 | 6526 |
| c09c-campaign-k.test.ts | ca1351a6b8085d0693942afb212c1d28663830420d784e384ed17a8e7a2fe670 | 27937 |
| c09c-env-isolation-output.txt | 0081750755d992fdedeb1ff634631062ed06b489ae4b1c8a178017f35de3001d | 258 |
| c09c-env-isolation.test.ts | 0af5c941c5197cc2c0cb78dc604f90730af3a804c9fc8e49841be5c9a2bf457e | 15151 |
| c09c-phase2-security-review-output.txt | b5179b27c1079e885eff952b1620f9956935e3f9396a9abeaec1874171c94be9 | 257 |
| c09c-phase2-security-review.test.ts | 3064625bf694fa89cfbdea86202ecbdd6285c26a6765b8c6ad18e638f615edc4 | 11320 |
| c09c-shutdown-retest-output.txt | 7827098fba95e492f3b77657de4d5c5c8dada717c25955f69107fa28a5a559a7 | 1048 |
| c09c-shutdown-retest.test.ts | d1ab935c7390bf7a5487e7101b025f0d71f28d0f6dd8d9cf6fdd34fffe830998 | 23122 |
| g6-09c-integrated.patch | a05651cce26166c99f757f98b952b4db1e954e5b3a86aa91be31b0fdac8a6319 | 13167 |
| independent-adversarial-output.txt | a102cd98e7ffc6732625f4037b2d9607e732a3d6ac9700a1a97edf900f9aa8c3 | 705 |
| independent-adversarial.test.ts | 77818ebd34491867711349021b08244a8afea857415ce0fd90d554518136fcc3 | 22850 |
| post-fix-verification-output.txt | 08ddbed8d151551bcfcd27ccf6212fdf61c08abb2496ddead496b421332a7571 | 396 |
| post-fix-verification.test.ts | 131855cac83654456b4c333f3dc62a51429644f58eca7cc1f60aea29203e3aa5 | 15155 |
| security-adversarial-output.txt | 7d05d60bb45ec61318200f50f7e1b67d234fac806a1375ea4fbc90b84e2fc12e | 706 |
| security-adversarial.test.ts | 1eaa01c7bbf450ce9e4a08c78f9a0ac3467b5e5d1d3cbc4cf6e61cb7c772c1f1 | 10941 |
| tier2-regression-output.txt | 6ac831f3743088fe98b8352208c4687042f4e83c4f0bfbb4811dfb4262aaba26 | 484 |
| tier2-regression.test.ts | 5635ee9705daa6429bb685f7259a3a1c64414415fd005b6b621190b9e07bfdc4 | 22213 |
