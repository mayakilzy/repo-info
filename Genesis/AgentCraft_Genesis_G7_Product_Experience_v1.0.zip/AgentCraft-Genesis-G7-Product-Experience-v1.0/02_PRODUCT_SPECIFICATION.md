# G7 Product Specification v1.0

## Product thesis
**Give Genesis a goal. It builds the organization needed to achieve it.** The product must make an otherwise complex dynamic organization understandable, steerable and accountable. The user should never need to configure a team before submitting a goal.

## Audience and outcomes
- Goal owner: states desired outcome, attaches context, reviews proposed plan, grants consent to execution, inspects result.
- Operator: monitors concurrent missions, errors, resource limits, authorization and audit trail.
- Developer/integrator: discovers supported capabilities, adapters, contracts and actual connection state.
- Reviewer: inspects artifacts, verification evidence and historical event trace.

## Primary information architecture — exactly six sections
1. **Work** — spaces/goals, composer, submissions, mission list and outcome.
2. **Agent** — organization graph/list, roles, genome fields, capabilities and execution ownership.
3. **Mission Control** — real-time mission lifecycle, timeline, worker actions, approval/cancel controls and errors.
4. **Studio** — capabilities, skills, tools, integrations and honest availability status; read-only by default.
5. **Insights** — observed metrics, durations, failures, costs where metered, and learning evidence where actually wired.
6. **Artifacts & Replay** — actual files/outputs, verification state, provenance and recorded-event replay (NOT rerun).

## Navigation model
Persistent responsive shell: product identity, six primary destinations, current mission context, environment label, connection indicator, user menu if identity exists. Desktop left rail; mobile collapsible navigation. Direct links to mission, worker, artifact and event anchors only when backend identifiers exist. Back/forward, refresh, deep link and browser restart should not falsely imply durable mission recovery.

## Golden journey — end to end
1. User opens Work; connection is checked. If gateway unavailable, show explicit unavailable state and retry.
2. User enters goal, optional constraints and references, and desired success criteria. Validate before submission.
3. If preview/organization proposal API exists, show it; if not, do NOT invent a proposed team. Explicitly explain that organization becomes visible after mission start.
4. User submits; show pending until server acknowledgement with canonical mission ID. Handle retry/idempotency according to verified contract.
5. User enters Mission Control, sees observed lifecycle and generated workers; approvals only if supported by backend.
6. Events and status reconcile after reconnect. Events may be delayed, missing or out of order; UI must never manufacture terminal state.
7. User inspects artifacts and verification evidence. Download only genuine server-returned artifacts with authorization.
8. Outcome view distinguishes SUCCEEDED, FAILED, CANCELLED, PARTIAL, BLOCKED and UNKNOWN **only where mapped from actual backend states**; never fabricate missing backend status.

## Functional acceptance by section
### Work
- Goal composer: text input, optional attached references only when supported, validation, constraints and success criteria where contract supports; safe submission; explicit confirmation; errors; resume by mission ID if available.
- Mission list: filter/search by server-supported fields or local loaded data, clear pagination/limits, honest empty/error/loading states. Do not promise persistence across restart without proof.
### Agent
- Dynamic organization list/graph: each node from observed worker or organization records. Show role, objective, model label if known, tool/capability bindings, budget and autonomy only when present. Missing fields displayed 'Not provided', never guessed.
- Organization changes represented as versioned events if available; otherwise snapshot-only with clear label. Worker genome inspection read-only in v1.
### Mission Control
- Lifecycle timeline and worker actions. Real statuses; pause/resume/approve only if actual endpoint exists; cancellation confirmed server-side; repeated cancel safe or transparently handled. No unsupported control buttons.
- Concurrency and error states; out-of-order events; reconnect; explicit 'Last observed at' and stale-state indicators.
### Artifacts & Replay
- Actual artifact metadata and verified content download/preview for safe types. Explicit `verified/unverified/failed/unknown` mapping. No arbitrary HTML execution or unsafe links.
- Replay means navigating a recorded timeline, not re-running commands. Export includes trace provenance and redaction.
### Studio
- Inventory of capabilities/tools/skills/integrations from real API, or clearly labeled static documentation when no discovery API exists. Status SUPPORTED/EXPERIMENTAL/UNAVAILABLE/BLOCKED with evidence and timestamp.
- No plugin installation, tool execution or credential management unless explicit secured API exists.
### Insights
- Only real counters and server-sourced measurements. No invented costs, savings, learning improvements or historical continuity. Show 'No measurement available' where absent. Aggregation method/time window displayed.

## Explicitly out of scope for G7 v1
- New orchestration engine; new agent runtime; arbitrary shell or browser control; direct provider key management; marketplace billing; multi-tenant admin console; production durable recovery; model self-training; autonomous evolution; live OpenBot/ZAI claim; general-purpose visual workflow editor; new proprietary protocols; offline execution.

## Product quality bar
- Functional and understandable at narrow/mobile/desktop widths.
- Accessible navigation and controls; no inaccessible canvas-only graph.
- User can tell whether data is real, controlled-test, stale, unavailable or estimated.
- Real errors are actionable; no 'everything green' default.
- All claims have evidence provenance and known deployment limits.
