# Gateway Discovery & Typed Adapter Contract v1.0

**This file is a required discovery procedure, NOT a fabricated API specification.** Actual routes, types, event names, authentication and behavior must be extracted from the pinned source and observed gateway. Never invent endpoint paths such as `/api/missions` merely because they seem natural.

## Stage A — source inventory
Inspect actual gateway server startup, route registrations, request schemas, auth middleware, MissionService public methods, A2A handlers, AG-UI event emitters, artifact provider, worker genome serialization, configuration, tests and API documentation. Record file path, symbol, line, request, response, error and permission behavior.

## Stage B — executable contract probes
Start gateway in controlled environment. For each discovered route or transport, test authorized success, malformed input, unauthorized, missing resource, conflicting state, timeout/disconnect and cancellation where relevant. Capture sanitized payload examples and status codes. Never expose keys. Test CORS/CSRF/session model based on actual auth mechanism. If gateway is not browser-safe, use a narrow backend-for-frontend proxy with explicit justification, not direct browser secrets.

## Stage C — mapping inventory (must complete before UI integration)
| UI capability | Verified backend source | Transport | Auth | Data source | Status | Gap action |
|---|---|---|---|---|---|---|
| Create mission | TBD by discovery | TBD | TBD | TBD | UNKNOWN | Verify |
| Read mission | TBD | TBD | TBD | TBD | UNKNOWN | Verify |
| List missions | TBD | TBD | TBD | TBD | UNKNOWN | Verify |
| Cancel mission | TBD | TBD | TBD | TBD | UNKNOWN | Verify |
| Observe events | TBD | TBD | TBD | TBD | UNKNOWN | Verify |
| List workers/genomes | TBD | TBD | TBD | TBD | UNKNOWN | Verify |
| List artifacts | TBD | TBD | TBD | TBD | UNKNOWN | Verify |
| Download artifact | TBD | TBD | TBD | TBD | UNKNOWN | Verify |
| Verification evidence | TBD | TBD | TBD | TBD | UNKNOWN | Verify |
| Capability discovery | TBD | TBD | TBD | TBD | UNKNOWN | Verify |
| Metrics | TBD | TBD | TBD | TBD | UNKNOWN | Verify |
| Approvals | TBD | TBD | TBD | TBD | UNKNOWN | Verify |

## Typed UI adapter — conceptual contract, not endpoint prescription
Define only the minimal operations actually supported by source:
```
MissionApi: submitGoal, getMission, [listMissions?], [cancelMission?]
MissionEvents: subscribe, unsubscribe, [resumeFromCursor?]
OrganizationApi: [getOrganization?], [getWorkers?]
ArtifactsApi: [listArtifacts?], [getArtifact?], [getVerification?]
CatalogApi: [listCapabilities?]
MetricsApi: [getObservedMetrics?]
```
Square-bracket operations are optional and MUST NOT be synthesized without evidence. The adapter should return discriminated results: `ok`, `unsupported`, `unauthorized`, `unavailable`, `uncertain`, `error`, with original backend semantics preserved. Do not map all errors to 500 or 200. Avoid frontend imports from engine internals.

## Event contract
Discover actual event IDs, ordering guarantees, mission/worker correlation, terminal markers, retry behavior, event retention and heartbeat. Maintain explicit `connectionState = connecting|live|stale|disconnected|failed` separate from mission status. Never infer a terminal mission from stream close alone.

## Authentication and secrets
Never place gateway admin/API keys in browser bundles, localStorage or query strings. If existing gateway only supports server-to-server keys, use a minimal secure server-side proxy or document G7-01 blocker; require scoped access, session handling, CSRF protection for cookie-auth writes, origin restrictions and rate limits appropriate to deployment. No new identity platform unless explicitly authorized.

## Backend change gate
Before proposing backend work, record missing user journey, source proof of absence, minimal API addition, authorization, backwards compatibility, test plan and impact. Minor read-only adapters can be implemented only after explicit gate acceptance; security/architecture changes require user review.

## API contract evidence file
Persist `evidence/gateway-capability-matrix.json` with `feature`, `routeOrSymbol`, `sourcePath`, `observed`, `auth`, `schema`, `errors`, `limitations`, `uiBehavior`, `testEvidence`. It must be machine-readable and not contain secrets.
