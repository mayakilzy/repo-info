# Checkpoints, Reporting and Session Recovery

## Persist after every group
`evidence/g7/checkpoints/G7-0X.json` with:
```
{
  "group":"G7-01", "status":"PASS|FAIL|BLOCKED|IN_PROGRESS",
  "base_sha":"", "completed_sha":"", "branch":"",
  "worktree_clean":false, "implemented_features":[],
  "api_contracts_verified":[], "tests":[], "evidence_paths":[],
  "production_files_added":0, "production_loc_delta":0,
  "dependencies_added":[], "open_findings":[], "known_limitations":[],
  "next_group":"G7-02", "next_action":""
}
```

## Report after each group
One concise report with summary, actual behavior, UI captures, route/transport evidence, exact tests and counts, failures, security review, LOC/files/deps, SHA and GO/NO-GO. The user may review after each group; continue automatically only if tests and gate pass and no material architectural question exists.

## Recovery prompt
> Resume AgentCraft Genesis G7 from persisted Git commits and `evidence/g7/checkpoints/`, not from chat history. Verify branch, HEAD, worktree and latest passed gate. Do not repeat completed groups. Reproduce essential smoke tests, then continue the next incomplete task. Stop on inconsistent state.

## Session failure policy
- Never rely solely on conversation context for completion.
- Do not rewrite prior evidence. Keep logs and hashes, redact secrets.
- If shell/GitHub unavailable, stop with exact last validated commit and outstanding actions. Do not claim push or CI.
- Do not run paid provider calls or delete credential files.
