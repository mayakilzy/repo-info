# Operator Decisions and No-Go Boundaries

## Decisions already frozen
- One GLM master development session, six checkpointed groups.
- Six UI destinations and goal-first UX.
- Gateway-first, evidence-first, no duplicate engine.
- GLM may be used for development and controlled reasoning substitution; not evidence of live ZAI/OpenBot.
- No extra paid model keys. Jev is not needed for UI build.

## Only ask the operator when necessary
1. Gateway cannot be securely accessed by browser and a new authenticated proxy is needed.
2. Required backend endpoint is absent and a material backend change is needed.
3. Existing repo framework cannot meet requirements without disruptive restructure.
4. G7 acceptance requires relaxing a security, verification or truthfulness invariant.
5. A live-provider acceptance test or external service deployment is proposed.

## Explicit exclusions
No credential deletion, secret copying, force-push, production deployment, purchasing services, external account changes or autonomous code changes outside the authorized repository. Do not claim all six groups PASS if a group is blocked.
