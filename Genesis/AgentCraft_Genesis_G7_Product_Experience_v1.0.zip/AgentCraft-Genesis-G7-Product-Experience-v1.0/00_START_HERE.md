# AgentCraft Genesis — G7 Product Experience v1.0
**Implementation handoff | One GLM session, six gated delivery groups**

## Mission
Turn the qualified Genesis Engine into an honest, functional, accessible, evidence-first product interface. **Do not build a second engine.** User owns the goal; Genesis owns the organization; user retains control.

## Required reading order
1. `01_MASTER_GLM_EXECUTION_PROMPT.md` — paste into the development session.
2. `02_PRODUCT_SPECIFICATION.md` — product and functional requirements.
3. `03_UI_UX_CONTRACT.md` — exact states, screens, interaction rules.
4. `04_GATEWAY_DISCOVERY_AND_ADAPTER_CONTRACT.md` — evidence-based API integration.
5. `05_SECURITY_ACCESSIBILITY_AND_OPERATIONS.md` — mandatory cross-cutting requirements.
6. `06_ACCEPTANCE_AND_TEST_MATRIX.md` — acceptance gates and test requirements.
7. `tasks/G7-01.md` through `tasks/G7-06.md` — implement in order.
8. `07_CHECKPOINT_AND_HANDOFF.md`, `08_DESIGN_SYSTEM.md`, `09_RISK_AND_SCOPE_REGISTER.md`.

## Source-of-truth hierarchy
1. Actual checked-out source, tests, running gateway, and observed traces at pinned SHA.
2. Verified G6-09C evidence and CI, if accessible.
3. This product specification for **desired UI behavior**, not for invented backend behavior.
4. Earlier architecture documents for intent only.

## Baseline (reported, must independently confirm)
- Repository: `https://github.com/mayakilzy/AgentCraft-Genesis`
- Branch: `build/group-06-productionization`
- Reported HEAD: `bff7b0a6f8b4e35880a9c7453d4e6de343e4e001`
- G6-09C: conditional acceptance; 590 passed / 9 skipped, 98 independent passed, CI success **reported**.
- Real ZAI and OpenBot acceptance remains unverified. Campaign K used GLM-assisted controlled runtime.
- Known residuals: shutdown close idempotency, trusted `extraEnv`, `Promise.race` cleanup continuation, durability/network deployment conditions.

## Final handoff artifacts
A functional UI, exact versioned commit, tests, screenshots/video evidence if available, feature-to-endpoint matrix, truthful limitations, and `G7-Final-Release-Evidence.zip` (never secrets).

**No authorization to delete credentials, change production secrets, or claim live provider acceptance.**
