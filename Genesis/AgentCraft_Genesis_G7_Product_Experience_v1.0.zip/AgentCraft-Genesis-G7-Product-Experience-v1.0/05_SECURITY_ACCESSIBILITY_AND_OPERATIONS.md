# Cross-Cutting Nonfunctional Requirements

## Security boundaries
- UI must not execute arbitrary worker commands; any remote actions must pass through existing authenticated, authorized gateway capabilities.
- Never expose `GENESIS_API_KEYS`, OpenRouter, ZAI, GitHub, OpenBot or other provider secrets to browser bundles, logs, analytics or artifacts. Confirm build output has no secret sentinel strings.
- All data from goals, workers, events, files, MCP/A2A tools and external documents is untrusted. Render as text by default; sanitize rich content; avoid `dangerouslySetInnerHTML` unless audited and strictly necessary.
- Prevent path traversal in file names, unsafe URL schemes, arbitrary remote preview and cross-mission artifact access. Test auth on both list and download endpoints.
- Browser authentication must match actual gateway architecture. If server-side API key proxy is necessary, make it minimal and protected; do not ship a shared privileged API key to every browser.
- Confirm idempotency, caller isolation and authorization for mission submission/cancellation. Do not invent tenant boundaries.
- Event/replay exports and error messages must redact secrets and sensitive context. Include tests with harmless sentinel strings.

## Resilience
- Handle gateway outage, slow response, event gaps, stale snapshots, repeated terminal events, refresh, navigation during submission, and cancellation races.
- Poll only where necessary; bounded interval/backoff; clean up subscriptions and abort controllers on unmount.
- Avoid unlimited event lists, DOM nodes, artifact previews or memory. Paginate/virtualize only if observed volumes require it.
- Never claim restart durability. Provide clear status when old missions cannot be retrieved.

## Accessibility and internationalization
- Keyboard-only completion of golden journey; focus-visible; accessible dialogs; proper form labels and validation; live regions for important updates without overwhelming announcements.
- Contrast and non-color status signals; reduced-motion support; mobile zoom; no horizontal overflow.
- RTL-ready layout and locale-aware date/number formatting. Do not assume the user's timezone equals server timezone. Display timezone or relative time with accessible absolute timestamp.

## Privacy and observability
- No analytics provider by default. No telemetry that exports goals, artifacts or tokens. Local structured logs with redaction and correlation IDs if backend supplies them.
- Surface source/freshness/known limitations on metrics and verification claims.

## Deployment and quality
- Document dev/prod startup, config, required gateway address, CORS/origin setup, reverse proxy, security headers, test mode and limitations.
- CI: typecheck, lint, unit/component tests, contract tests, E2E smoke with controlled gateway, build, and security/secret-sentinel scan.
- Check exact dependency licenses and supply chain risk for any added package. Prefer small dependency delta.
- Keep production source manageable: report files/LOC added per group; avoid generator sprawl and one-file-per-state ceremony.
