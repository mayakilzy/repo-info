# UI/UX Contract v1.0 — State and Interaction Rules

## Global invariants
- The interface is not the authority for mission status, worker execution, verification, authorization or billing.
- Every screen has five explicit states: loading, loaded, empty, error, disconnected/stale (where applicable).
- No control without a real supported backend action. Disabled controls must explain why; do not render dead buttons.
- User-triggered mutations require server acknowledgement. Optimistic visuals may show PENDING but not SUCCESS.
- Accessible names, visible focus, keyboard operation, semantic roles, and reduced-motion alternatives are mandatory.

## Global components
`AppShell`, `EnvironmentStatus`, `ConnectionStatus`, `MissionBreadcrumb`, `GoalComposer`, `MissionList`, `MissionStatus`, `OrganizationList`, `WorkerDetail`, `EventTimeline`, `ActionConfirmDialog`, `ArtifactList`, `ArtifactPreview`, `VerificationEvidence`, `ReplayTimeline`, `CapabilityCatalog`, `InsightMetric`, `EmptyState`, `ErrorBoundary`, `LoadingSkeleton`.
These are conceptual boundaries, not mandates to create one file per component.

## Visual language
Calm enterprise palette, soft surface cards, restrained accents, no alarming red for ordinary UI. Red reserved for confirmed errors/critical status. Readable typography, consistent spacing, compact data-dense mode where useful. Prefer text/list to decorative graph. Motion communicates transition, never evidence of ongoing work.

## Work — behavior contract
- Goal input required; empty/whitespace rejected. Max length derived from actual API schema; if unknown, use conservative client cap and server error handling, document it.
- Constraints/success criteria optional only if backend accepts them; otherwise store as goal prose with explicit disclosure, not a phantom structured API field.
- Attachments require real upload/association endpoint; otherwise show disabled with explanation rather than fake upload.
- Submit: idle → validating → submitting → acknowledged(id) / rejected(error) / uncertain(network failure). If acknowledgement lost, never blindly retry non-idempotent operation; offer lookup by correlation/idempotency if supported.
- Mission list and details show timestamp source, data freshness, and state mapping provenance.

## Agent — behavior contract
- Organization view defaults to accessible worker list; optional graph is supplemental and keyboard accessible via equivalent list.
- Each worker card: server ID, role/objective/status, model/provider if returned, tools/skills, resource policy and actual events. Hide absent optional data or label unknown.
- Organization mutations: show observed additions/removals/changes only; no fake animation or pre-generated team. No editing genomes unless endpoint exists and authorized.

## Mission Control — behavior contract
- Show mission identity, status, last observed update, active workers, events and supported actions.
- Streaming transport: use actual protocol (AG-UI/SSE/etc.) as discovered. On reconnect, request snapshot or cursor catch-up only if supported; otherwise explicitly mark potential gaps.
- Deduplicate events using stable server ID if available. Without IDs, avoid destructive dedup assumptions. Out-of-order timestamps should not reorder causal transitions blindly.
- Cancel action: confirm → request → pending → acknowledged/rejected. Cancellation does not mean immediate worker termination. Do not show CANCELLED until server confirms.
- Approval/HITL controls only for real supported request and response schemas.

## Artifacts — behavior contract
- Metadata from actual gateway; never generate placeholder downloadable files. Verification badges reflect exact server verification state, with UNKNOWN if missing.
- Preview only safe text/image/PDF types with size limits and sanitized rendering; download preserves server filename safely. Treat HTML/SVG/scripts as untrusted; do not execute.
- Replay scrubbed recorded events, with timestamp, actor/source and evidence. Replay must never invoke tools or mutate a mission.

## Studio — behavior contract
- Catalog entries include name, type, version if known, source, capability scope, permission requirements and connectivity/availability status.
- If no live discovery endpoint, present only verified documentation references clearly labeled 'Documentation only — not runtime discovery'.
- Never present unavailable integrations as connected. No 'Install' CTA without real authorized installation workflow.

## Insights — behavior contract
- Metric values require definition, unit, time range, source and freshness. Use em dash/Not measured when absent; zero means measured zero, not missing.
- Cost only when actual provider/runtime meter exists. GLM-assisted tests must not be presented as production billing data.
- Learning charts require actual learning event records and baseline; otherwise explanatory unavailable state.

## Failure and boundary copy
- `Connection lost — showing last observed state`.
- `Action submitted; final result not yet confirmed`.
- `Verification evidence unavailable — result is not verified`.
- `Integration not tested in this environment`.
- `Recorded-event replay; no mission is being re-executed`.
- `This is a controlled test environment, not a live production provider`.

## Navigation, responsive and accessibility
- Desktop >=1024: left nav + contextual detail pane.
- Tablet 640–1023: compact nav, detail drawer.
- Mobile <640: collapsible nav, stacked cards, no horizontal page overflow; tables scroll in bounded region.
- RTL-ready: logical CSS properties, text direction handling, icon mirroring only where semantically appropriate. Default copy can be English; do not hardcode layout assuming LTR.
- WCAG 2.2 AA-oriented checks: contrast, focus order, labels, error announcements, non-color status cues, 200% zoom, reduced motion, touch targets. Test with keyboard and automated accessibility tooling where available.
