# G7 Risk and Scope Register

| ID | Risk | Severity | Required control |
|---|---|---|---|
| R01 | Missing actual gateway routes | HIGH | Source and live discovery before UI implementation; NO-GO if core mission submit/read unavailable |
| R02 | Browser exposure of gateway API key | CRITICAL | Secure server-side proxy or supported user auth; never bundle secret |
| R03 | Fake progress/status from local state | HIGH | Server authoritative status and stale/unknown indicators |
| R04 | Unsupported artifact retrieval | HIGH | Honest disabled state; propose minimal authenticated read adapter only with approval |
| R05 | Streaming loss/reordering | MEDIUM | Reconcile snapshot/cursor where supported; show gap/stale state |
| R06 | Live ZAI/OpenBot not validated | HIGH for production | Keep separate G6 operational acceptance gate |
| R07 | No restart durability | HIGH for production | No persistence claim; document expected data loss |
| R08 | Graph complexity/bloat | MEDIUM | Accessible list first; graph only if justified |
| R09 | Recreating orchestration in UI | HIGH | Thin typed adapter; code review |
| R10 | Security of rich previews | HIGH | Sanitize, safe content types, no arbitrary HTML execution |
| R11 | Hidden P3 shutdown/extraEnv limitations | MEDIUM | Preserve risk register, no production claim |
| R12 | Dependency and file explosion | MEDIUM | Measure LOC/files/deps each group |
| R13 | Model-substituted demo confused with live integration | HIGH | Evidence tier labels E0–E3 |
| R14 | Unauthorized replay actions | HIGH | Replay read-only; no tool invocations |
| R15 | User/tenant identity absent | HIGH | Don't invent RBAC; gate public/multiuser deployment |

## Change control
Product decisions frozen: six sections, goal-first, gateway-first, evidence-first, controlled scope, sequential gates. Implementation technologies and backend endpoint mappings are NOT frozen until discovered. A material backend or security architecture change requires user approval.
