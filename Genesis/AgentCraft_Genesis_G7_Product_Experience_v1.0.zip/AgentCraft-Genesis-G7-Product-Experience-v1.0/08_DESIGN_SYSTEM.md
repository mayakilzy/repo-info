# Visual Design System v1.0 — Calm Enterprise

## Identity
Quiet, trustworthy, professional, human-centered. Not sci-fi neon, not an admin dashboard overloaded with metrics. The visual centerpiece is the goal and its evolving organization. Prefer soft neutral surfaces, restrained blue/teal accents, readable typography, generous but efficient spacing.

## Tokens (proposed; adapt to existing framework)
- Background light: `#F7F9FC`; surface `#FFFFFF`; raised `#F0F4F8`; primary text `#182433`; muted `#64748B`; border `#DDE5ED`; accent `#236B88`.
- Success `#19785B`, warning `#996515`, danger `#B43D45` with text/icon labels; validate actual contrast and adjust tokens as needed.
- Radius: 8px controls, 12px cards, 16px major panels. Spacing scale 4/8/12/16/24/32. Focus ring clearly visible.
- Typography: system or existing repo font; headings compact, body 14–16px, code and IDs monospace, no font asset redistribution.
- Dark mode optional only if cheap and fully tested; do not delay functional gates for theme polish.

## Page composition
- Shell: persistent nav + page title/context + connection state.
- Work: goal composer prominent, mission list secondary.
- Agent: accessible list first, optional organization graph second.
- Mission Control: status header, timeline, workers, supported actions, errors.
- Artifacts: files, verification panel, replay timeline with explicit read-only label.
- Studio: catalog with capability type and evidence of connection.
- Insights: source-labeled metrics and honest empty states.

## UX anti-patterns
- Do not display animated 'thinking' unless a live observed processing state exists.
- Do not display hardcoded 100% progress.
- Do not generate fake organization nodes for decoration in connected mode.
- Do not show costs or accuracy percentages without actual data.
- Do not use traffic-light color as sole state representation.
- Do not bury errors behind toast-only notifications.

## Responsive behavior
- 360–639px: stacked panels, drawer nav, 44px touch targets where possible.
- 640–1023px: compact navigation, collapsible detail.
- >=1024px: rail navigation, contextual split panes.
- Use CSS logical properties for RTL readiness; test mixed Arabic/English and long IDs.
