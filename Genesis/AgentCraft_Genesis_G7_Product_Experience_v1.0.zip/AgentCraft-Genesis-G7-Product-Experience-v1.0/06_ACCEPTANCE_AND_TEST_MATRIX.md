# G7 Acceptance Matrix and Test Strategy

## Definition of Done for every group
- User-visible function exercised against a real running gateway or transparently labeled controlled adapter.
- Loading/empty/success/error/disconnected and unauthorized states tested.
- Accessibility and responsive checks completed for changed screens.
- No invented backend capability; unsupported functions clearly marked.
- Tests use independent expected outputs; evidence has command, exit code, commit, mode, environment and artifact path.
- Typecheck, lint, relevant tests and production build pass. Commit/checkpoint saved. No open P0/P1.

## Mandatory acceptance cases
| ID | Area | Scenario | Expected |
|---|---|---|---|
| UI-001 | Shell | Direct route, refresh, mobile nav | Stable accessible navigation |
| UI-002 | Shell | Gateway down | Honest disconnected state, retry |
| UI-003 | Auth | No credentials/401/403 | No protected data/action exposed |
| UI-004 | Work | Empty goal | Client validation, no request |
| UI-005 | Work | Valid goal | Server ack ID shown, no fake success |
| UI-006 | Work | Request timeout after possible commit | UNCERTAIN, no blind duplicate retry |
| UI-007 | Work | Duplicate submit | Actual backend semantics honored |
| UI-008 | Mission | Status transition | Reflects observed backend states |
| UI-009 | Mission | Stream disconnect/reconnect | Stale indicator, no invented events |
| UI-010 | Mission | Event reorder/duplicate | No false terminal state |
| UI-011 | Mission | Cancel race | Pending until server confirms |
| UI-012 | Agent | Worker absent | Explicit unavailable/empty, not fabricated |
| UI-013 | Agent | Worker genome partial | Missing fields unknown, no defaults masquerading as data |
| UI-014 | Artifacts | Real artifact exists | Authorized preview/download; metadata matches |
| UI-015 | Artifacts | No artifact | No placeholder file or false verification |
| UI-016 | Artifacts | Malicious HTML/SVG/file name | No script execution/path escape |
| UI-017 | Verification | Failed/unobserved check | Never marked verified |
| UI-018 | Replay | Play recorded events | No new tool execution or writes |
| UI-019 | Studio | Integration unavailable | Not shown as connected/installable |
| UI-020 | Insights | Cost absent | Not measured, not $0 |
| UI-021 | Insights | Learning not wired | No fabricated improvement chart |
| UI-022 | Security | Secret sentinels in server errors | Not leaked in browser/export |
| UI-023 | Security | Cross-mission artifact request | Denied or flagged as unverified authorization gap |
| UI-024 | A11y | Keyboard journey + reduced motion | Operable, understandable |
| UI-025 | Responsive | 360px/768px/1440px | No inaccessible controls/overflow |
| UI-026 | CI | Clean checkout and install | Reproducible build and tests |

## Evidence tiers
- **E0 Mock-only**: screenshot/layout, not functional proof.
- **E1 Controlled runtime**: real UI/adapter against deterministic gateway or MemoryComputer; label as controlled.
- **E2 Connected engine**: real UI connected to actual Genesis Gateway, executing supported engine paths; provider may be controlled.
- **E3 Live provider/runtime**: actual ZAI/OpenBot verified; not a G7 assumption.

## Mandatory negative controls
Disable/deny the gateway and verify UI does not claim success. Corrupt artifact verification and verify UI does not show verified. Drop stream mid-mission and verify UI shows stale. Inject secret sentinel into error and verify it is redacted. Replay recorded events and verify no mission/tool action occurs.

## Release gates
- G7-01: API inventory evidence and shell integration, no secret in browser.
- G7-02: real submit/read mission path, or explicit NO-GO if impossible.
- G7-03: truthful mission/worker state and cancellation semantics.
- G7-04: real artifact/verification/replay evidence; no false success.
- G7-05: catalog truthfulness; no fake install/connect.
- G7-06: complete journey, accessibility, cleanroom CI, product evidence package.

## Final verdict
`PASS`, `PASS_WITH_LIMITATIONS`, `FAIL`, `INCONCLUSIVE`. Production release cannot be PASS if the six G6-09C operational conditions remain unverified. G7 product-development completion and production acceptance are separate verdicts.
