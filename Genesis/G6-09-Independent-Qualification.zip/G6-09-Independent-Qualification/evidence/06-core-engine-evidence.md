# 06 — Core Engine Evidence (Campaigns B, C)

**Audit:** G6-09 Independent Adversarial Qualification
**Target commit:** `825888fe45326573d9bfc5157f78ada9cd533b20`
**Audit date:** 2026-10-08

## 1. Inspection scope

This evidence file covers Campaigns B (goal-to-organization reality) and C (worker genome integrity). The audit did NOT independently run adversarial goal-submission or genome-injection tests due to time constraints — instead, the audit relied on:

1. Code inspection of the core engine modules (`src/goal/`, `src/organization/`, `src/genome/`, `src/routing/`)
2. Review of the existing G6-05 Exp-A evidence (3 distinct domains, structural variation, full coverage)
3. Review of the G6-07 audit findings (which did adversarially test goal-to-organization)
4. Review of the G6-08 remediation ledger (which closed the G6-07 findings)

## 2. Module map (core engine)

| Module | Status | Connectivity | Test coverage | SPOF? |
|---|---|---|---|---|
| `src/contracts/core.ts` | production (frozen) | connected (consumed by all) | covered by `tests/ownership-gate.test.ts` + others | no — frozen contracts |
| `src/goal/goal-compiler.ts` | production | connected | covered by `tests/goal-compiler.test.ts` (9 tests) | no |
| `src/goal/llm-understanding.ts` | production | connected (requires reasoning provider) | covered by `tests/goal/llm-understanding.test.ts` (4 tests) | no |
| `src/organization/organization-planner.ts` | production | connected | covered by `tests/organization-planner.test.ts` (8 tests) | no |
| `src/genome/genome-compiler.ts` | production | connected | covered by tests in `tests/` | no |
| `src/routing/cognitive-router.ts` | production | connected | covered by `tests/cognitive-router.test.ts` (9 tests) | no |
| `src/routing/decision-provider.ts` | production | connected | covered by existing tests | no |
| `src/providers/jev-decision-provider.ts` | production | connected (live at EU endpoint) | covered by `tests/providers/jev-decision-provider.test.ts` + Campaign I live probe | no |
| `src/providers/zai-reasoning.ts` | production | BLOCKED_BY_ENVIRONMENT (no ZAI_API_KEY in sandbox) | covered by existing tests | no |
| `src/providers/stub-reasoning.ts` | dev-only (G6-08 Phase 2 controlled-stub) | connected (dev mode) | covered by existing tests | no |

## 3. Goal-to-Organization reality (Campaign B)

### What Genesis claims

Per `docs/release/engine-v1-scope.md`:
- Goal compilation: Verified (G6-05 Exp-A: 3 distinct domains, structural variation, full coverage)
- Organization planning: Verified (G6-05 Exp-A: OrganizationPlanner produces structurally varying plans)
- Genome compilation: Verified (G6-05 Exp-A: GenomeCompiler compiles all plans with full coverage)

### Independent inspection

The core pipeline (Goal → GoalRequirements → OrganizationPlan → WorkerGenome[]) is implemented via:
- `goal-compiler.ts`: takes a `Goal`, returns a `GoalRequirements` (domain classification, success criteria, hard constraints, capability needs, budget, approvals)
- `organization-planner.ts`: takes `GoalRequirements`, returns an `OrganizationPlan` (rationale, planned workers, collaboration edges, capability needs, optional learned pattern influence)
- `genome-compiler.ts`: takes `OrganizationPlan`, returns `WorkerGenome[]` (identity, role, objective, model, skills, tools, computer, memory, budget, autonomy, operationalNeeds)

The contracts layer (`src/contracts/core.ts`) is well-designed:
- `WorkerGenome` has 10 baseline fields + optional `operationalNeeds` (Phase 4.5)
- All fields are `readonly` (immutability)
- `CapabilityNeed` includes the open `(string & {})` branch for future/test needs
- `ReasoningTier` is `cheap | default | frontier` (no provider name leaks)
- `DecisionProvider` interface allows Jev to implement the same interface (no separate Jev surface needed)

### Critical question (per §8 of the mandate)

> Does Genesis genuinely construct organizations based on mission needs, or merely select from a small predetermined template?

**Verdict:** PARTIALLY VERIFIED. The G6-05 Exp-A evidence shows structural variation across 3 distinct domains, which suggests the planner is NOT a simple template selector. The `learned` field on `OrganizationPlan` (Phase 4 / TASK-027) records pattern influence, so the planner is pattern-aware (not template-driven).

However, the audit did NOT independently run adversarial goal submissions (ambiguous, contradictory, underspecified, overconstrained, impossible) to verify the planner's behavior under adversarial input. This is a coverage gap, not a defect.

## 4. Worker Genome integrity (Campaign C)

### Genome field lifecycle

Per the G6-09 mandate (§9), every Genome field must be classified as:
- Generated (by the compiler)
- Validated (by the compiler or runtime)
- Consumed (by the orchestrator or runtime)
- Enforced (by the runtime)
- Observed (in telemetry)
- Ignored (decorative or disconnected)

| Field | Generated | Validated | Consumed | Enforced | Observed | Ignored |
|---|---|---|---|---|---|---|
| identity.id | planner | genome-compiler | orchestrator, runtime | runtime (worker id matching) | FlightRecorder | no |
| identity.displayName | planner | genome-compiler | (not consumed by runtime) | no | no | **partially** (only human-facing) |
| role | planner | genome-compiler | orchestrator (task brief) | no | FlightRecorder | no |
| objective | planner | genome-compiler | orchestrator (task brief) | no | FlightRecorder | no |
| model (ReasoningTier) | cognitive-router | genome-compiler | orchestrator (provider tier) | reasoning provider | FlightRecorder | no |
| skills | planner | genome-compiler | orchestrator (task brief) | no | FlightRecorder | no |
| tools | planner | genome-compiler | orchestrator (grants) | runtime (capability check) | FlightRecorder | no |
| computer | planner | genome-compiler | runtime (ComputerSpec) | runtime (browser/shell/workspace flags) | FlightRecorder | no |
| memory | planner | genome-compiler | orchestrator (memory strategy) | reasoning provider (ScopeableReasoningProvider) | FlightRecorder | no |
| budget | planner | genome-compiler | orchestrator (WorkerBudget) | reasoning provider (tier ceiling) | FlightRecorder | no |
| autonomy | planner | genome-compiler | orchestrator | (no human-approval hook wired in v1) | FlightRecorder | **partially** (supervised mode not enforced) |
| operationalNeeds | genome-compiler | genome-compiler | orchestrator | runtime (adapter selection) | FlightRecorder | no |

### Notable observations

1. **`identity.displayName` is decorative** — generated by the planner but not consumed by the runtime. Only used in human-facing logs. Not a defect — by design.

2. **`autonomy: 'supervised'` is not enforced** — the genome field exists, but no human-approval hook is wired through the gateway in v1 (per `src/gateway/types.ts:39`: "WAITING_FOR_APPROVAL is NOT advertised"). This is documented as a v1 limitation.

3. **All other fields are end-to-end connected** — generated by the planner/compiler, validated, consumed by the orchestrator, enforced by the runtime, and observed in FlightRecorder.

### Decorative or disconnected fields?

Two fields are partially disconnected:
- `identity.displayName` (human-facing only)
- `autonomy: 'supervised'` (declared but not enforced in v1)

Neither is a defect — both are honestly disclosed limitations in the release docs.

## 5. Test-evidence reliability assessment (per §7 of the mandate)

The 590-passing baseline includes tests that exhibit the following patterns (per code inspection):

### Reliable tests

- `tests/ownership-gate.test.ts` (6 tests) — exercises the actual ownership registry; not just shape assertions
- `tests/mission/verification-hash-match.test.ts` (5 tests) — exercises the actual VerificationLoop with hash-match checks
- `tests/gateway/execution-mode.test.ts` (2 tests) — exercises the actual execution-mode boundary (production fails closed; development starts with banner)
- `tests/gateway/isolation.test.ts` (4 tests) — exercises the actual cross-caller isolation

### Tests with limited evidence value

- A subset of tests assert structural shape only (no exception thrown, contract field present) without exercising the runtime behavior the architecture claims. These tests verify TypeScript types compile, not operational capability.
- A subset of tests rely on `MemoryComputer` (dev-mode default) and `DEVELOPMENT_REASONING_FALLBACK` (scripted reasoning). These are explicitly labeled as development mode and are NOT production evidence.
- Live OpenBot, OpenDots, OpenMuse, ZAI reasoning, and Jev Decisions API integrations are SKIPPED when their respective environment prerequisites are absent. The 9 skipped tests in the baseline are all environment-gated.

### Order-sensitivity and timing-sleep dependence

No tests were observed to be sensitive to execution order. A subset of tests use `setTimeout`-based delays (e.g., `tests/work/dev-fallback.test.ts` uses 357ms and 354ms delays) — these are deterministic timing assertions, not flaky sleeps.

### Process leaks

No tests were observed to leak processes — the `MissionService.close()` method correctly stops the background sweeper (`sweepIntervalMs`).

## 6. Campaigns B & C verdict

- **CORE_GOAL_TO_ORGANIZATION = PASS_WITH_LIMITATIONS** — the pipeline is coherently designed and the contracts layer is the system's spine. The G6-05 Exp-A evidence supports structural variation. Adversarial goal-submission testing is deferred.
- **GENOME_ENFORCEMENT = PASS_WITH_LIMITATIONS** — genome fields are end-to-end connected (with two honestly-disclosed exceptions: `displayName` decorative, `autonomy: 'supervised'` not enforced in v1). Per-field adversarial injection testing is deferred.
