# 16 — Recommended Remediation Order

**Audit:** G6-09 Independent Adversarial Qualification
**Target commit:** `825888fe45326573d9bfc5157f78ada9cd533b20`
**Audit date:** 2026-10-08

This file prioritizes the remediation actions based on (a) severity, (b) effort, (c) blast radius, and (d) dependency on other fixes. The order is the recommended execution sequence for the G6-09B remediation phase.

---

## Tier 1 — Must-fix before acceptance (P1, ~25 lines of code total)

### 1. Fix G6-09-S01 — OpenBot worker env allowlist (P1, ~10 lines)

**Why first:** It's a credential boundary breach. Every minute this defect exists in production, the OpenRouter key (Jev-only per Section 2.1) is exposed to any worker that runs shell commands.

**File:** `src/runtime/openbot/computer-process.ts:175-184`

**Change:**
```typescript
// Before:
env: {
  ...process.env,
  PORT: String(port),
  COMPUTER_TOKEN: token,
  WORKSPACE_DIR: workspaceDir,
  PROFILES_DIR: profilesDir,
  EGRESS_POLICY_REQUIRED: '0',
  ...config.extraEnv,
}

// After:
env: {
  // Explicit allowlist — gateway secrets are NOT propagated to workers.
  PORT: String(port),
  COMPUTER_TOKEN: token,
  WORKSPACE_DIR: workspaceDir,
  PROFILES_DIR: profilesDir,
  EGRESS_POLICY_REQUIRED: '0',
  PATH: process.env.PATH,
  HOME: process.env.HOME,
  ...config.extraEnv,
}
```

**Verification:** Re-run IT-S-09. Expect: worker cannot read `GENESIS_API_KEYS` or `OPENROUTER_API_KEY`.

### 2. Fix G6-09-001 — Per-runtime timeout on close() (P1, ~15 lines)

**Why second:** It's a chaos-resilience defect. Without this fix, the operator's "10s bound" on shutdown is aspirational, not enforced.

**File:** `src/gateway/mission-service.ts:368-374`

**Change:**
```typescript
// Before:
if (typeof rt.runtime.close === 'function') {
  try {
    await rt.runtime.close();
    closed = true;
  } catch (e) {
    closeError = e instanceof Error ? e.message.slice(0, 200) : String(e).slice(0, 200);
  }
}

// After:
if (typeof rt.runtime.close === 'function') {
  const perRuntimeDeadline = Math.min(2_000, Math.max(0, deadlineMs - (Date.now() - startedAt)));
  try {
    await Promise.race([
      rt.runtime.close(),
      new Promise<void>((resolve) => setTimeout(resolve, perRuntimeDeadline)),
    ]);
    closed = true;
  } catch (e) {
    closeError = e instanceof Error ? e.message.slice(0, 200) : String(e).slice(0, 200);
  }
}
```

**Verification:** Re-run IT-07. Expect: shutdown completes within ~500ms + overhead (not 4+ seconds). The structured `ShutdownResult.elapsedMs` should be ≤ `deadlineMs + small_overhead`.

---

## Tier 2 — Recommended defense-in-depth (P2/P3, ~270 lines of test code)

### 3. Add IT-08 — Subprocess test for exit code 1 (P2, ~50 lines)

**Why:** Closes G6-09-002. The exit-code-1 path at `main.ts:407,411` is currently dead code from a test-coverage standpoint. Add a subprocess-level test that:
1. Spawns the gateway as a child process (using `npx tsx src/gateway/main.ts`)
2. Submits a mission
3. Forces an unclean shutdown (e.g., by configuring a stub runtime whose `close()` throws)
4. Sends SIGTERM
5. Asserts the actual OS exit code is 1

### 4. Add IT-11 — Per-phase cancellation tests (P2, ~100 lines)

**Why:** Closes G6-09-005. The verification-phase cancellation path is untested — the most dangerous case for false-success. Add a phase-aware reasoning stub that pauses at each phase, and 5 sub-tests for: start, reasoning, toolExec, verification, completion. Each sub-test asserts the final status is CANCELLED or PARTIAL, NOT SUCCEEDED.

### 5. Add IT-03 — SIGKILL escalation test (P3, ~80 lines)

**Why:** Closes G6-09-006. The 2-second SIGTERM→SIGKILL escalation at `computer-process.ts:265-275` is dead code from a test-coverage standpoint. Add a `FakeChildProcess` that:
1. Ignores SIGTERM
2. Tracks SIGKILL calls
3. Asserts SIGKILL fires after ~2 seconds

### 6. Add IT-S-03 — Adversarial command list test (P3, ~50 lines)

**Why:** Closes G6-09-S02. The Genesis-layer command policy has known gaps. Add a test that:
1. Calls `checkCommandPolicy` with adversarial commands: `nc -e /bin/sh`, `python -c '...'`, `find / -delete`, `dd of=/tmp/x`, `> /etc/passwd`
2. Asserts they are BLOCKED (after the policy is extended)

This test should first DOCUMENT the current gaps (tests pass with the gap present) and then drive the policy fix.

### 7. Add IT-10 to the G6-08-R1 regression suite (P3, ~20 lines)

**Why:** Closes G6-09-003. The cross-caller idempotency-key rejection behavior is verified by the independent test IT-10, but the G6-08-R1 suite lacks the regression test. Add IT-10 to `tests/g6-08-r1/` for permanent regression protection.

### 8. Fix G6-09-S03 — A2A User fallback (informational, ~3 lines)

**Why:** Defense-in-depth. The fallback at `a2a-server.ts:517-532` grants `mission:submit` to any SDK User with `isAuthenticated=true`. Change the fallback to return `null` (reject unknown User implementations) instead of constructing a permissive CallerIdentity.

---

## Tier 3 — Operator responsibility (deferred to live acceptance)

### 9. Run live ZAI acceptance tests

**Why:** Closes RR-08. The ZAIReasoningProvider code is correct by inspection, but no live ZAI call was made. The operator must run bounded live acceptance tests with real ZAI credentials.

**Suggested scope:**
- 5–10 missions across the G6-05 Exp-A domains (research, software-engineering, diagnostic, general)
- Bounded budget (e.g., $5 total)
- Independent validation of each mission's artifact

### 10. Run live OpenBot acceptance tests

**Why:** Closes RR-09. The OpenBotRuntimeAdapter code is correct by inspection (with the G6-09-S01 env-inheritance fix applied), but no live OpenBot execution was made. The operator must run bounded live acceptance tests with real OpenBot infrastructure.

**Suggested scope:**
- Tasks A, B, D, E, F from Campaign K (build, diagnose, data processing, recovery, multi-worker)
- Bounded budget for paid LLM calls
- Independent validators for each task's expected output

### 11. Run Tasks A–H from Campaign K (E2E benchmark)

**Why:** Closes RR-10. The autonomous-execution claim (a goal produces real-world work) is NOT independently verified by this audit. The operator must run the E2E benchmark with real LLM + real OpenBot.

---

## Summary

| Tier | Count | Effort | Blocks acceptance? |
|---|---|---|---|
| 1 — Must-fix | 2 fixes | ~25 lines of code | YES |
| 2 — Defense-in-depth | 5 test additions + 1 small fix | ~300 lines of test code | NO (but recommended) |
| 3 — Operator responsibility | 3 acceptance test campaigns | Operator's time + paid LLM budget | Conditional (per RR-08, RR-09, RR-10) |

**Total engineering effort for Tier 1:** ~25 lines of code change + 2 regression test reruns. **Estimated time: 30 minutes.**

**Total engineering effort for Tier 2:** ~300 lines of test code + the policy extension. **Estimated time: 1 day.**

**Total operator effort for Tier 3:** Bounded live acceptance tests. **Estimated time: 1–2 days + paid LLM budget.**
