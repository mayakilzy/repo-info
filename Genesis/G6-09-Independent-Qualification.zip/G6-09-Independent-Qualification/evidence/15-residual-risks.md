# 15 — Residual Risks

**Audit:** G6-09 Independent Adversarial Qualification
**Target commit:** `825888fe45326573d9bfc5157f78ada9cd533b20`
**Audit date:** 2026-10-08

This file documents the residual risks that remain AFTER the G6-09 audit. They are organized by category. Each risk includes: severity, likelihood, mitigation, and the action required to close it.

---

## Category 1 — Unresolved P1 defects (must-fix before acceptance)

### RR-01 — Shutdown deadline not enforced (G6-09-001)

- **Severity:** P1
- **Likelihood:** MEDIUM — manifests whenever a worker's `close()` hangs (e.g., a stuck OpenBot process)
- **Mitigation:** Operator can SIGKILL the gateway as fallback; structured `ShutdownResult` surfaces the issue when it resolves
- **Action required:** Apply the ~15-line fix (wrap `close()` in `Promise.race` with per-runtime timeout). Re-run IT-07 to confirm the 500ms deadline is enforced. After fix + retest, this risk closes.

### RR-02 — Worker env inheritance (G6-09-S01)

- **Severity:** P1
- **Likelihood:** HIGH — manifests in production mode with any software-engineering mission that runs shell commands
- **Mitigation:** Dev mode (MemoryComputer) is unaffected; the defect requires real OpenBot which is BLOCKED_BY_ENVIRONMENT in the current sandbox
- **Action required:** Apply the ~10-line fix (replace `env: { ...process.env, ... }` with explicit allowlist). Re-run IT-S-09 to confirm the worker cannot read `GENESIS_API_KEYS` or `OPENROUTER_API_KEY`. After fix + retest, this risk closes.

---

## Category 2 — Coverage gaps (P2/P3, defense-in-depth)

### RR-03 — Verification-phase cancellation untested (G6-09-005)

- **Severity:** P2 (coverage gap)
- **Likelihood:** LOW — the orchestrator's abort signal IS correctly propagated (per existing CANCEL-01 test), but the verification-phase-specific path is unverified
- **Mitigation:** The verification loop's clean-room design (Campaign F IT-FS-01..05) provides defense-in-depth against false-success even if cancellation propagation fails
- **Action required:** Add 5 per-phase cancellation tests (start, reasoning, toolExec, verification, completion) with a phase-aware reasoning stub. Cost: ~100 lines of test code.

### RR-04 — Exit-code-1 path untested (G6-09-002)

- **Severity:** P2 (coverage gap)
- **Likelihood:** LOW — the code path is correct by inspection; just not exercised
- **Mitigation:** The structured `ShutdownResult.clean` field is correctly computed; only the OS exit code translation is unverified
- **Action required:** Add a subprocess-level test that asserts exit code 1 on unclean shutdown. Cost: ~50 lines.

### RR-05 — SIGKILL escalation dead code from test perspective (G6-09-006)

- **Severity:** P3 (coverage gap)
- **Likelihood:** LOW — the code path is correct by inspection
- **Mitigation:** None — the SIGKILL escalation is defense-in-depth; the primary SIGTERM path is tested
- **Action required:** Add a `FakeChildProcess` test that ignores SIGTERM and asserts SIGKILL fires after 2s. Cost: ~80 lines.

### RR-06 — Command policy gaps (G6-09-S02)

- **Severity:** P3 (defense-in-depth gap)
- **Likelihood:** MEDIUM — a prompt-injected worker could emit `nc -e /bin/sh`, `python -c`, `find / -delete`, `dd of=/tmp/x`
- **Mitigation:** The OpenBot adapter's egress filter is the primary defense (not audited here); the Genesis-layer policy is the backstop
- **Action required:** Add 5 regex patterns to `checkCommandPolicy`. Cost: ~7 lines.

### RR-07 — Cross-caller idempotency coverage gap (G6-09-003)

- **Severity:** P3 (coverage gap)
- **Likelihood:** LOW — the production code is correct (IT-10 PASSED)
- **Mitigation:** The behavior is verified by the independent test; the G6-08-R1 suite just lacks the regression test
- **Action required:** Add the IT-10 test to the G6-08-R1 suite for regression protection. Cost: ~20 lines.

---

## Category 3 — Environment-blocked capabilities (cannot be verified in this audit)

### RR-08 — Live ZAI reasoning not exercised

- **Severity:** P2 (BLOCKED_BY_ENVIRONMENT)
- **Likelihood:** N/A — the operator's OPENROUTER_API_KEY is Jev-only per Section 2.1; no ZAI_API_KEY was supplied
- **Mitigation:** The ZAIReasoningProvider code is correct by inspection; the controlled-stub provider exercises the production wiring (G6-08 Phase 2)
- **Action required:** Operator must run bounded live acceptance tests with real ZAI credentials before trusting the engine for real work. Per `engine-v1-known-limitations.md` #11a.

### RR-09 — Live OpenBot execution not exercised

- **Severity:** P2 (BLOCKED_BY_ENVIRONMENT)
- **Likelihood:** N/A — no OpenBot checkout in the sandbox
- **Mitigation:** The OpenBotRuntimeAdapter code is correct by inspection (with the G6-09-S01 env-inheritance defect); the controlled-stub runtime exercises the production wiring
- **Action required:** Operator must run bounded live acceptance tests with real OpenBot infrastructure. Per `engine-v1-known-limitations.md` #11a.

### RR-10 — Realistic E2E benchmark not run

- **Severity:** P2 (BLOCKED_BY_ENVIRONMENT)
- **Likelihood:** N/A — Tasks A–H all require real LLM reasoning
- **Mitigation:** The verification-integrity tests (Campaign F: 5/5 PASS) provide confidence that any failure mode the E2E benchmark surfaces will be caught by the verification loop
- **Action required:** Operator must run Tasks A–H with real LLM + real OpenBot before enterprise acceptance. Per the G6-09 mandate §17.

### RR-11 — Protocol-level adversarial testing not run

- **Severity:** P3 (deferred)
- **Likelihood:** LOW — the protocols use official SDKs and the AgentCard is honestly declared
- **Mitigation:** The code is correct by inspection; SDK versions are verified
- **Action required:** Run independent protocol-client tests against the A2A server and MCP runtime. Per the G6-09 mandate §14.

---

## Category 4 — Honestly-disclosed limitations (not defects)

### RR-12 — In-process state only (no restart recovery)

- **Severity:** N/A (documented as Unsupported)
- **Mitigation:** `engine-v1-known-limitations.md` #1 honestly discloses this; IT-RESTART-01 confirms the no-durability contract
- **Action required:** None for v1. Operators must NOT deploy without an external durability layer (e.g., a process supervisor that restarts the gateway AND re-submits in-flight missions).

### RR-13 — API-key authentication only (no mTLS/OAuth/JWT)

- **Severity:** N/A (documented as Limited)
- **Mitigation:** `engine-v1-known-limitations.md` #3 honestly discloses this
- **Action required:** None for v1 if deployed behind a server-to-server transport. Operators must NOT expose the gateway to untrusted networks without additional transport security.

### RR-14 — Single-process (no horizontal scaling)

- **Severity:** N/A (documented as limitation)
- **Mitigation:** `engine-v1-known-limitations.md` #13 honestly discloses this
- **Action required:** None for v1. Operators must NOT expect horizontal scaling without an external load balancer + shared-state layer.

### RR-15 — Bounded registry (maxActiveMissionsGlobal = 50)

- **Severity:** N/A (documented as limitation)
- **Mitigation:** `engine-v1-known-limitations.md` #14 honestly discloses this; the registry caps concurrent active missions at 50 (configurable)
- **Action required:** None for v1. Operators must tune `maxActiveMissionsGlobal` per their workload.

---

## Summary

| Category | Count | Action required before acceptance? |
|---|---|---|
| 1 — Unresolved P1 defects | 2 | YES (must fix) |
| 2 — Coverage gaps (P2/P3) | 5 | Recommended (defense-in-depth) |
| 3 — Environment-blocked | 4 | Operator's responsibility (live acceptance) |
| 4 — Honestly-disclosed limitations | 4 | None (documented) |

**Total residual risks: 15.**

Of these, ONLY Category 1 (2 risks) blocks enterprise acceptance. Categories 2–4 are deferred or accepted by design.

After the two P1 fixes are applied and retested, the engine should be eligible for **CONDITIONAL_ACCEPT** with the following conditions:
1. Operators MUST run bounded live acceptance tests with real ZAI + real OpenBot before production deployment (per RR-08, RR-09, RR-10).
2. Operators MUST NOT deploy without an external durability layer (per RR-12).
3. Operators MUST NOT expose the gateway to untrusted networks without additional transport security (per RR-13).
4. Operators MUST tune `maxActiveMissionsGlobal` per their workload (per RR-15).

These conditions are explicit, enforceable, and bounded — they meet the Section 22 criteria for CONDITIONAL_ACCEPT (after the P1 fixes).
