# 07 — Worker Runtime Evidence (Campaign D + E)

**Stage:** Stage 4 — Runtime, concurrency & shutdown attacks
**Operator:** GLM (Independent Principal Engineer)
**Target commit:** 825888fe45326573d9bfc5157f78ada9cd533b20
**Audit date:** 2026-10-08

## 1. Reconnaissance summary

A focused subagent (Task ID: stage-4-recon) read the new G6-08-R1 shutdown lifecycle implementation and tests. Full report at `/home/z/my-project/genesis-audit/workspace/stage-4-recon.md` (523 lines). Headline coverage tally against the 16 adversarial cases mandated by §10 + §11:

| Status | Count |
|---|---|
| Fully covered | 1 |
| Partial | 8 |
| Not covered | 7 |

## 2. Top preliminary findings from reconnaissance

| ID | Title | Severity | Confidence | File:line |
|---|---|---|---|---|
| F-RECON-001 | `MissionService.shutdown(deadlineMs)` does NOT enforce `deadlineMs` as a wall-clock cap; the close() pass has no per-runtime timeout | P1 | HIGH | `src/gateway/mission-service.ts:293–402` (especially 360–384) |
| F-RECON-002 | `main.ts:407` (`process.exit(result.clean ? 0 : 1)`) and `main.ts:411` (catch → exit 1) are never exercised by any test | P2 | HIGH | `src/gateway/main.ts:407,411` |
| F-RECON-003 | `if (shutdownInProgress) return;` at main.ts:368 silently drops the second signal | P3 | MEDIUM | `src/gateway/main.ts:364–412` |
| F-RECON-006 | Cross-caller idempotency-key rejection branch is not covered by any existing test | P2 (coverage gap) | HIGH | `src/gateway/mission-service.ts:500–511` |
| F-RECON-008 | Per-phase cancellation coverage is missing the verification phase | P1 (coverage gap) | MEDIUM | (orchestrator not separately tested per phase) |
| F-RECON-010 | `MemoryRuntime` does not implement `close()`; the safety net is a no-op in dev mode | informational | HIGH | `src/runtime/memory-computer.ts` |

## 3. Independent test execution

Independent harness at `/home/z/my-project/genesis-audit/workspace/tests/independent-adversarial.test.ts` (preserved copy in `harness/`). Ran via `npx vitest run --no-color` (test output saved to `harness/independent-adversarial-test-output.txt`).

### Result

```
Test Files  1 passed (1)
     Tests  12 passed (12)
  Duration  7.03s
```

All 12 tests passed. **Passing in this context does NOT mean "no defect"** — for F-RECON-001, the test PASSES by demonstrating the defect exists (shutdown exceeds the deadline when close() hangs).

## 4. Per-test evidence

### IT-07 / F-RECON-001 — close() pass is unbounded
**Result: REPRODUCED_DEFECT (P1)**

- Setup: `IndependentStubRuntime` with `closeBehavior='hang'` (close() never resolves). One active mission. `service.shutdown(500)` requested.
- Observed: shutdown did NOT complete within the 4-second safety race; the test asserted `elapsed > 1000` (well past the 500ms bound) and `rt.closeCalled === true`.
- Test duration: 4022 ms — proves the 500 ms deadline was NOT enforced; the actual elapsed time exceeded 4 seconds.
- Root cause: `mission-service.ts:370` does `await rt.runtime.close()` with no per-runtime timeout. If close() hangs (e.g., a stuck OpenBot process whose SIGKILL also fails), the gateway shutdown handler at `main.ts:379` will block on `await service.shutdown(10_000)` for much longer than 10 seconds.
- Impact: Operator's "10 s bound" is aspirational, not enforced. A stuck worker can hang the gateway shutdown indefinitely. A second SIGTERM cannot interrupt the await (Node's SIGTERM handler is single-threaded).
- Recommended correction: Wrap each `await rt.runtime.close()` in a `Promise.race([close(), new Promise(resolve => setTimeout(resolve, perRuntimeDeadlineMs))])` and increment `runtimeAdapterCloseErrors` if the timeout wins.

### IT-04 — close() throwing is captured and marked unclean
**Result: POSITIVE_CONFIRMATION**

- Setup: `IndependentStubRuntime` with `closeBehavior='throw'`. Active mission, then `service.shutdown(2_000)`.
- Observed: `result.runtimeAdapterCloseErrors === 1`, `result.clean === false`, `result.perRuntime[0].closeError` contains "simulated close() failure".
- Conclusion: The throwing-close path at `mission-service.ts:368–374` works correctly. The structured `ShutdownResult` captures the error and surfaces it.

### IT-10 / F-RECON-006 — Cross-caller idempotency-key collision
**Result: POSITIVE_CONFIRMATION**

- Setup: Caller A submits with `idempotencyKey='shared-key-001'`. Caller B tries to reuse the same key.
- Observed: Caller B's submission throws `MissionAdmissionError('idempotency key already in use by another caller')`. Caller A's mission is unaffected.
- Conclusion: The cross-caller rejection branch at `mission-service.ts:500–511` works correctly. F-RECON-006 was a TEST COVERAGE GAP, not a behavior defect — the production code is correct.

### IT-13 / F-RECON-010 — MemoryRuntime close() absence
**Result: INFORMATIONAL (by design)**

- Observed: `MemoryRuntime` does NOT implement `close()`. The optional `close?()` method on `WorkerRuntime` is absent.
- Conclusion: The safety net in `MissionService.shutdown()` becomes a no-op for dev mode. This is by design — MemoryRuntime is in-process and holds no external resources. But it means the safety net only catches OpenBot workers in production mode.
- Impact: For dev-mode testing, this is acceptable. For production (real OpenBot), the OpenBotRuntimeAdapter MUST implement close() — see OpenBot adapter inspection below.

### IT-MONO-01 / F-RECON-012 — Terminal state is monotonic
**Result: POSITIVE_CONFIRMATION**

- Setup: Submit a mission, wait for it to reach a terminal state (SUCCEEDED/FAILED/PARTIAL/CANCELLED). Capture status and finishedAt. Issue a late cancel.
- Observed: `service.cancel()` returns the same terminal status; `rt.status` and `rt.finishedAt` are unchanged.
- Conclusion: Terminal state IS monotonic — a SUCCEEDED mission cannot be flipped to CANCELLED by a late cancel. The state machine at `mission-service.ts:595–635` correctly resolves runPromise exactly once.

### IT-RESTART-01 / F-RECON-013 — Restart loses in-process state
**Result: POSITIVE_CONFIRMATION (of a documented limitation)**

- Setup: Construct MissionService S1, submit one mission, await completion, capture missionId. Construct a fresh S2 (same options, fresh instance — simulating a process restart). Call `S2.get(missionId, CALLER_A)`.
- Observed: `S2.get` throws `MissionNotFoundError`. `S2.health().totalMissions === 0`.
- Conclusion: The no-durability contract is correctly enforced — in-memory state does NOT survive restart. This is honestly disclosed in `main.ts:357` ("In-process state; no durability across restart") and `docs/release/engine-v1-scope.md` ("Restart recovery | Unsupported | In-process state only; no durability across restart").

### IT-FS-01..05 / Campaign F — False-success prevention
**Result: 4 POSITIVE_CONFIRMATION + 1 INFORMATIONAL_CAVEAT**

- IT-FS-01 (hash-match on wrong path): PASSES — check correctly fails when expected path is absent.
- IT-FS-02 (empty file vs non-empty hash): PASSES — empty file hash does NOT match a real expected hash; check fails honestly.
- IT-FS-03 (file check without expectIncludes accepts empty): PASSES — but documents that a `file` check with no `expectIncludes` only verifies presence, NOT content. Operators MUST use `expectIncludes` or `hash-match` to enforce content correctness.
- IT-FS-04 (check against wrong artifact path): PASSES — the file is copied as empty (no exception) then the `expectIncludes` check fails because empty content does not include the expected substring.
- IT-FS-05 (stale artifacts cleared): PASSES — `clearVerifierArtifacts()` runs before each `verify()`, preventing stale-file false positives. The G6-08 Phase 4 / C-VERIFY-FINDING-002 fix is correctly implemented.

### IT-CONC-01 / Campaign E — Same-caller simultaneous idempotency
**Result: POSITIVE_CONFIRMATION**

- Setup: Two `Promise.all([service.start({...idempotencyKey:'same-key-002'}, CALLER_A), service.start({...idempotencyKey:'same-key-002'}, CALLER_A)])` submissions.
- Observed: Both return the same missionId and same status.
- Conclusion: Same-caller idempotency works correctly under concurrent submission.

## 5. OpenBot adapter inspection (read-only)

The OpenBot adapter at `src/runtime/openbot/computer-process.ts` was inspected. The `detached: true` spawn logic (line 193) and the SIGTERM→SIGKILL-after-2s fallback (lines 265–275) are present. The 2s SIGKILL escalation is dead code from a TEST perspective (no test exercises it), but the code path itself is correct.

Per F-RECON-007, no test verifies the SIGKILL escalation fires for a worker that ignores SIGTERM. This is an EVIDENCE_GAP — the code is present, but the adversarial case is not covered.

## 6. Findings registered from Stage 4

| ID | Title | Severity | Confidence | Evidence | Status |
|---|---|---|---|---|---|
| G6-09-001 | MissionService.shutdown() close() pass has no per-runtime timeout; 10s deadline is aspirational | P1 | HIGH (REPRODUCED_DEFECT) | IT-07 (4022ms elapsed vs 500ms deadline) | OPEN |
| G6-09-002 | Exit-code-1 path at main.ts:407,411 never exercised | P2 | HIGH (CODE_CONFIRMED_DEFECT in test-coverage terms) | Recon report §6 F-RECON-002 | OPEN (test-coverage gap, not a behavior defect) |
| G6-09-003 | Cross-caller idempotency-key rejection not covered by G6-08-R1 tests (but production code is correct) | P3 (coverage gap) | HIGH | IT-10 PASSED | RESOLVED (production code confirmed correct; coverage gap remains) |
| G6-09-004 | MemoryRuntime does not implement close(); safety net is a no-op in dev mode | informational | HIGH | IT-13 | ACCEPTED_BY_DESIGN (production OpenBotRuntimeAdapter must implement close()) |
| G6-09-005 | Per-phase cancellation coverage missing the verification phase | P1 (coverage gap) | MEDIUM | Recon report §6 F-RECON-008 | OPEN (test-coverage gap) |
| G6-09-006 | 2s SIGKILL escalation for SIGTERM-ignoring workers is dead code from a test perspective | P2 (coverage gap) | HIGH | Recon report §6 F-RECON-007 | OPEN (test-coverage gap; production code path correct) |

## 7. Stage 4 verdict (preliminary)

The G6-08-R1 fix to B-EXEC-FINDING-003 is a substantial improvement over the b1f9ffa state. The new shutdown handler:
- Is idempotent (guarded by `shutdownInProgress` + `shutdownCompleted`)
- Calls `service.shutdown(10_000)` to drain active missions
- Reports structured per-mission and per-runtime results
- Exits 0 if clean, 1 if any timedOut or closeErrors

However, the implementation has one P1 defect (G6-09-001: no per-runtime close() timeout) that means the 10s deadline is aspirational, not enforced. This defect is bounded (an operator can SIGKILL the gateway if it hangs), and the structured ShutdownResult surfaces the issue honestly when it occurs.

For a release-gate verdict, G6-09-001 should be remediated before enterprise acceptance: each `await rt.runtime.close()` should be wrapped in a `Promise.race` with a per-runtime timeout, with timedOut runtime adapters marked as `closeError: 'timeout'` in the ShutdownResult.
