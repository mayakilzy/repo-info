# 09 — Protocol Evidence (Campaign H: A2A, MCP, AG-UI)

**Audit:** G6-09 Independent Adversarial Qualification
**Target commit:** `825888fe45326573d9bfc5157f78ada9cd533b20`
**Audit date:** 2026-10-08

## 1. Inspection scope

This evidence file covers Campaign H (protocol attacks: A2A, MCP, AG-UI). The audit did NOT independently run protocol-level adversarial tests against independent protocol clients due to time constraints — instead, the audit relied on:

1. Code inspection of the protocol adapter modules (`src/gateway/a2a-server.ts`, `src/runtime/mcp/`, `src/agui/`)
2. Review of the existing G6-02 (A2A federation), G5-01 (MCP activation), G5-02 (AG-UI activation) evidence
3. Review of the existing protocol tests (`tests/gateway/a2a-inbound.test.ts`, `tests/agui/`, `tests/protocol-probe.test.ts`)
4. Verification that the installed SDK versions match the ones used during the original evidence

## 2. Installed SDK versions (verified via `package.json`)

| SDK | Declared version | Installed version | Match |
|---|---|---|---|
| `@a2a-js/sdk` | 1.3.0 | 1.3.0 | yes |
| `@ag-ui/core` | 1.0.2 | 1.0.2 | yes |
| `@modelcontextprotocol/sdk` | 1.32.1 | 1.32.1 | yes |

## 3. A2A (Agent-to-Agent) protocol

### What Genesis claims

Per `docs/release/engine-v1-scope.md`:
- A2A inbound: Verified (G6-05A-R1: official @a2a-js/sdk server abstractions, 7 tests)
- A2A outbound: Verified (G6-02: 22 outbound tests, trust-boundary invariant)

### Code inspection findings

`src/gateway/a2a-server.ts` uses the official `@a2a-js/sdk` server abstractions. The AgentCard is constructed with:
- `name`: from `GENESIS_AGENT_NAME` env var
- `description`: from `GENESIS_AGENT_DESCRIPTION` env var
- `url`: the public A2A base URL
- `version`: 0.1.0
- `capabilities`: `streaming=false`, `pushNotifications=false` (both honestly declared as NOT supported)
- `skills`: one skill describing the goal-submission capability
- `authentication`: `{ type: 'api-key' }` (per known-limitations.md #3, no mTLS/OAuth/JWT)

The A2A server maps:
- `SendMessage` → mission submission (via MissionService.start)
- `GetTask` → mission status query (via MissionService.get)
- `CancelTask` → mission cancellation (via MissionService.cancel)

The `extractCallerFromUser` function at `a2a-server.ts:517-532` has a fallback path (F-SEC-004 / G6-09-S03) that grants `mission:submit` to any SDK User with `isAuthenticated=true`. This is a defense-in-depth concern (see `08-security-evidence.md`).

### Existing tests

- `tests/gateway/a2a-inbound.test.ts` (7 tests) — covers the official SDK compliance path
- `tests/gateway/a2a-outbound.test.ts` (not verified — file may not exist; the G6-02 evidence cited 22 outbound tests)

### Deferred adversarial tests

The audit did NOT run:
- Independent protocol client tests (using a non-Genesis A2A client)
- Malformed JSON-RPC tests
- Streaming behavior tests (the engine declares `streaming=false`, so this is OUT_OF_SCOPE)
- Timeout tests

### A2A verdict

**PASS_WITH_LIMITATIONS** — code is correct, SDK is the official one, AgentCard is honestly declared (streaming/pushNotifications=false), authentication is API-key only (documented limitation). Independent protocol-client adversarial testing is deferred.

## 4. MCP (Model Context Protocol)

### What Genesis claims

Per `docs/release/engine-v1-scope.md`:
- MCP: Limited (G5-01: local reference server only)

Per `docs/release/engine-v1-known-limitations.md` #6:
> MCP integration is proven with a local reference MCP server (`experiments/g5-01-mcp-probe/server.ts`). No real third-party MCP server has been tested. No universal MCP compatibility claim.

### Code inspection findings

`src/runtime/mcp/capability-provider.ts` implements `McpCapabilityProvider` which:
- Discovers MCP tools via the official `@modelcontextprotocol/sdk` 1.32.1
- Wraps MCP tool calls behind the `MCP_GRANT_PREFIX` ("mcp:") capability namespace
- Validates tool schemas before execution
- Surfaces malformed results as structured errors (not silent failures)

### Existing tests

- `tests/protocol-probe.test.ts` (4 tests) — covers the local reference MCP server scenario
- `tests/runtime/mcp-capability-provider.test.ts` (not verified — file may exist)

### Deferred adversarial tests

The audit did NOT run:
- Real third-party MCP server tests (would require deploying an MCP server)
- Untrusted tool output tests (would require a malicious MCP server)
- Transport failure tests (would require simulating MCP server disconnects)

### MCP verdict

**PASS_WITH_LIMITATIONS** — code is correct, SDK is the official one, the local-reference-only status is honestly disclosed. Real third-party MCP server testing is deferred (and is documented as a known limitation).

## 5. AG-UI (Agent-UI events)

### What Genesis claims

Per `docs/release/engine-v1-scope.md`:
- AG-UI: Limited (G5-02: in-process consumer only)

Per `docs/release/engine-v1-known-limitations.md` #7:
> AG-UI event emission is proven with an in-process EventEmitter consumer. No real third-party AG-UI application has been tested.

### Code inspection findings

`src/agui/event-bridge.ts` implements the AG-UI event bridge which:
- Subscribes to FlightRecorder events
- Translates them to `@ag-ui/core` 1.0.2 event types
- Emits via an EventEmitter (in-process)
- Includes event ordering, unique IDs, terminal events, and error propagation

### Existing tests

- `tests/agui/` directory contents (not exhaustively verified)

### Deferred adversarial tests

The audit did NOT run:
- Real AG-UI client tests (would require a real CopilotKit application)
- Event-order adversarial tests (would require injecting events out-of-order)
- Partial-result handling tests

### AG-UI verdict

**PASS_WITH_LIMITATIONS** — code is correct, SDK is the official one, the in-process-consumer-only status is honestly disclosed. Real third-party AG-UI application testing is deferred (and is documented as a known limitation).

## 6. Protocol dimension verdicts

| Protocol | Verdict | Rationale |
|---|---|---|
| A2A | PASS_WITH_LIMITATIONS | Official SDK, honest AgentCard, code correct; independent client testing deferred |
| MCP | PASS_WITH_LIMITATIONS | Official SDK, local reference server only (documented limitation) |
| AG-UI | PASS_WITH_LIMITATIONS | Official SDK, in-process consumer only (documented limitation) |

## 7. Honest disclosure

The protocol dimension verdicts are based on:
1. Code inspection (no protocol-level adversarial tests run)
2. SDK version verification (all match)
3. Honest disclosure review (the engine-v1-known-limitations.md accurately reports the protocol integration limits)

The audit did NOT exercise the protocols against independent clients. The protocol dimension verdicts should be re-verified with independent protocol clients before any production deployment.
