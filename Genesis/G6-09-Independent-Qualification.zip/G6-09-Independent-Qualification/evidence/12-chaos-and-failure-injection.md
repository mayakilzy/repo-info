# 12 — Chaos and Failure Injection (Campaign M)

**Audit:** G6-09 Independent Adversarial Qualification
**Target commit:** `825888fe45326573d9bfc5157f78ada9cd533b20`
**Audit date:** 2026-10-08

## 1. Inspection scope

This evidence file covers Campaign M (chaos and fault injection). The G6-09 mandate (§19) specifies 15 fault scenarios:

1. Delayed provider responses
2. Provider rejection
3. Invalid model output
4. Worker crash
5. Tool timeout
6. File permission denial
7. Disk quota exhaustion in a temporary workspace
8. A2A remote disconnect
9. MCP malformed response
10. Gateway SIGTERM
11. Duplicate requests
12. Stale artifacts
13. Verification failure
14. Event recorder failure
15. Cleanup failure

## 2. Audit findings

The audit did NOT independently run all 15 fault scenarios due to time constraints. The audit ran a SUBSET of chaos tests, with the following results:

### Scenario 10 — Gateway SIGTERM (PARTIALLY TESTED)

Independent test IT-07 (in `independent-adversarial.test.ts`) simulated a SIGTERM-equivalent scenario by calling `service.shutdown(500)` while a mission was active. The test demonstrated G6-09-001: the 500ms deadline was NOT enforced; the actual elapsed time exceeded 4 seconds.

**Result:** DEFECT CONFIRMED (G6-09-001, P1, REPRODUCED).

### Scenario 11 — Duplicate requests (TESTED)

Independent test IT-CONC-01 verified that two simultaneous submissions with the same idempotency key from the same caller return the same missionId (no double execution).

Independent test IT-10 verified that cross-caller idempotency-key reuse is rejected (no confused-deputy).

**Result:** POSITIVE_CONFIRMATION — duplicate-request handling works correctly.

### Scenario 12 — Stale artifacts (TESTED)

Independent test IT-FS-05 (Campaign F) verified that `clearVerifierArtifacts()` runs before each `verify()` call, preventing stale-file false positives. The first verify writes `real.txt` to the verifier; the second verify (with a different producer that does NOT have `real.txt`) correctly fails because the stale file is cleared.

**Result:** POSITIVE_CONFIRMATION — stale-artifact handling works correctly.

### Scenario 13 — Verification failure (TESTED)

Independent tests IT-FS-01, IT-FS-02, IT-FS-04 (Campaign F) verified that verification failures are correctly reported as `result.ok === false` with traceable `result.outcomes[i].detail` strings. No false-success path was found.

**Result:** POSITIVE_CONFIRMATION — verification failure handling works correctly.

### Scenario 15 — Cleanup failure (PARTIALLY TESTED)

Independent test IT-04 (F-RECON-001 series) verified that a runtime adapter whose `close()` throws is correctly captured in the structured `ShutdownResult`:
- `result.runtimeAdapterCloseErrors === 1`
- `result.clean === false`
- `result.perRuntime[0].closeError` contains the error message

The shutdown does NOT propagate the exception — it captures it and continues with the next runtime adapter.

**Result:** POSITIVE_CONFIRMATION — cleanup-failure handling works correctly.

## 3. Scenarios NOT tested

The following scenarios were NOT independently tested:

| # | Scenario | Why deferred |
|---|---|---|
| 1 | Delayed provider responses | Requires a reasoning provider stub with delay control; deferred |
| 2 | Provider rejection | Requires injecting HTTP 401/403/500 from a real provider; covered by JevDecisionProvider unit tests (JevCredentialInvalidError, JevProviderUnavailableError) but not independently re-verified |
| 3 | Invalid model output | Requires injecting malformed JSON; covered by JevDecisionProvider unit tests (JevMalformedResponseError, JevInvalidChoiceError) but not independently re-verified |
| 4 | Worker crash | Requires a real OpenBot worker that crashes; BLOCKED_BY_ENVIRONMENT |
| 5 | Tool timeout | Requires a real OpenBot tool that times out; BLOCKED_BY_ENVIRONMENT |
| 6 | File permission denial | Requires a real filesystem; the dev-mode MemoryComputer does NO path validation (F-SEC-002) |
| 7 | Disk quota exhaustion | Requires a real filesystem with quota; deferred |
| 8 | A2A remote disconnect | Requires a real A2A client; deferred |
| 9 | MCP malformed response | Requires a real MCP server; BLOCKED_BY_ENVIRONMENT |
| 14 | Event recorder failure | Requires injecting FlightRecorder failures; deferred |

## 4. What the engine handles correctly (per code inspection)

Code inspection confirmed the engine handles the following fault scenarios correctly:

1. **Provider rejection (HTTP 401/403/500)** — `JevDecisionProvider` throws `JevCredentialInvalidError`, `JevProviderUnavailableError`, or `JevProviderTimeoutError` based on the HTTP status. No silent fallback.

2. **Invalid model output (malformed JSON, choice not in options)** — `JevDecisionProvider` throws `JevMalformedResponseError` or `JevInvalidChoiceError`. The decision is rejected, not silently guessed.

3. **Network error / timeout** — `JevDecisionProvider` wraps `fetch` in `fetchWithTimeout` with a 30-second deadline. Network errors throw `JevProviderUnavailableError(0, ...)`.

4. **Cleanup failure** — `MissionService.shutdown()` catches `close()` throws and captures them in `ShutdownResult.runtimeAdapterCloseErrors`.

5. **Stale artifacts** — `VerificationLoop.verify()` calls `clearVerifierArtifacts()` before each invocation, preventing stale-file false positives.

6. **Duplicate requests** — `MissionService.start()` uses `idempotencyIndex` to return the existing missionId for duplicate keys (same caller) or reject (cross-caller).

## 5. Campaign M verdict

**CHAOS_AND_FAILURE_INJECTION = PARTIALLY_TESTED**

Of the 15 mandated scenarios:
- 5 were independently tested (4 POSITIVE_CONFIRMATION, 1 DEFECT CONFIRMED)
- 10 were deferred (BLOCKED_BY_ENVIRONMENT or time-constrained)

The defect confirmed (G6-09-001: close() pass unbounded) is a chaos-resilience defect — the engine does NOT gracefully handle a hung `close()` in the shutdown path. The structured `ShutdownResult` honestly reports the issue when it eventually resolves, but the deadline is not enforced.

## 6. Recommended chaos-testing follow-up

Before enterprise acceptance, the operator should run:
1. **Provider fault injection** — point JevDecisionProvider at a stub HTTP server that returns 401/403/500/malformed-JSON with controlled delays. Verify the error taxonomy is correct.
2. **Worker crash injection** — with real OpenBot, kill a worker mid-execution and verify the orchestrator's `finally{}` block calls `stopWorker` and the mission is correctly classified as PARTIAL or FAILED.
3. **Disk quota exhaustion** — point `WORKSPACE_DIR` at a small tmpfs and verify the worker's `writeFile` fails gracefully.
4. **A2A remote disconnect** — connect via A2A, then kill the client, and verify the gateway does not hang.

These are bounded tests that can be run in CI without real LLM credentials.
