# 14 — Architecture Assessment

**Audit session:** web-7c6a0087-e31a-4321-ad21-ec1274161b16
**Audit date (UTC+8):** 2026-10-08
**Auditor:** GLM (Independent Principal Engineer)
**Target commit:** `825888fe45326573d9bfc5157f78ada9cd533b20`
**Target branch:** `build/group-06-productionization`
**Source material:** `genesis-audit/workspace/stage-1-arch-claims.md`, `genesis-audit/workspace/stage-5-security-recon.md`, `genesis-audit/workspace/tests/*`, `genesis-audit/scripts/jev-live-probe.ts`, prior evidence files (00, 07, 10, 13).
**Read-only:** No production source files were modified to produce this assessment.

---

## 1. Module map

Module classification columns: **Status** (production / dev-only / test-only / experimental / documented-only); **Connectivity** (connected / partial / disconnected); **Test coverage** (covered / partial / none); **SPOF** (yes / no).

| Module | Status | Connectivity | Test coverage | SPOF | Notes |
|---|---|---|---|---|---|
| `src/contracts/core.ts` | production | connected | covered | no | Frozen minimal contracts; the spine. |
| `src/goal/goal-compiler.ts` | production | connected | covered (9 tests) | no | Goal → GoalRequirements. |
| `src/goal/llm-understanding.ts` | production | partial | partial | no | LLM understanding provider; live ZAI not exercised. |
| `src/organization/organization-planner.ts` | production | connected | covered (8 tests) | no | Includes G5-06 `prefer-role: Sole Operator`. |
| `src/genome/genome-compiler.ts` | production | connected | covered (8 tests) | no | Genome compilation + ownership loading. |
| `src/routing/cognitive-router.ts` | production | connected | covered | no | Tier selection. |
| `src/routing/decision-provider.ts` | production | connected | covered | no | Rule-based fallback DecisionProvider. |
| `src/providers/zai-reasoning.ts` | production | partial | partial | YES | Real ZAI LLM; credential path UNVERIFIED (RR-07); no per-call timeout (F-SEC-007). |
| `src/providers/stub-reasoning.ts` | dev-only | connected | covered | no | G6-08 Phase 2 controlled-stub. Labeled in startup logs. |
| `src/providers/jev-decision-provider.ts` | production | connected | covered (32 tests) | no | Jev optional decision primitive; live call SUCCEEDED at 825888f. |
| `src/runtime/computer.ts` | production | connected | covered | no | WorkerRuntime + ArtifactsProvider contracts. |
| `src/runtime/memory-computer.ts` | dev-only | connected | covered | no | Promoted from `tests/helpers/` (RC-5); dev/stub runtime. Implements ArtifactsProvider; NO path validation (F-SEC-002). |
| `src/runtime/composite-runtime.ts` | production | connected | covered | no | Bundles computer/workspace/job surfaces. |
| `src/runtime/openbot/adapter.ts` | production | partial | partial | YES | OpenBot adapter; only 6/8 tests run (live OpenBot not in sandbox). Implements ArtifactsProvider. |
| `src/runtime/openbot/computer-process.ts` | production | partial | partial | YES | `detached:true` spawn + 2-stage SIGKILL kill; live OpenBot process spawning UNVERIFIED; env-spread leak (F-SEC-001). |
| `src/runtime/openbot/computer-api.ts` | production | partial | partial | no | HTTP client; documented against OpenBot v0.1.0; not exercised with real OpenBot. |
| `src/runtime/opendots/adapter.ts` | production | partial | partial | no | OpenDots workspace; proven in Phase 4.6/4.8E, not in default gateway. |
| `src/runtime/opendots/client.ts` | production | partial | partial | no | HTTP client; not in default gateway. |
| `src/runtime/openmuse/adapter.ts` | production | partial | partial | no | OpenMuse durable delegation; proven in Phase 4.8E. In-flight recovery H-22 NOT proven. |
| `src/runtime/openmuse/client.ts` | production | partial | partial | no | HTTP client. |
| `src/runtime/mcp/capability-provider.ts` | production | partial | covered (4 tests) | no | MCP client; only local reference server tested. |
| `src/runtime/federation/service.ts` | production | partial | covered (22 tests) | no | A2A outbound; trust-boundary invariant tested. TLS pin deferred (RR-02). |
| `src/runtime/federation/types.ts` | production | connected | covered | no | Type-only. |
| `src/worker/worker-agent.ts` | production | connected | covered (8+5 tests) | YES | Acting loop. Genesis-layer command policy + TOOL OUTPUT framing live here; framing source-string-verified only (F-SEC-003). |
| `src/worker/handoff.ts` | production | connected | covered | no | Worker-to-worker channel. |
| `src/mission/orchestrator.ts` | production | connected | covered | YES | Per-mission orchestration. finally{} stopWorker at lines 855-868; inMemoryFlightEvents; expectHash. |
| `src/mission/verification.ts` | production | connected | covered (6+9 tests) | YES | VerificationLoop; clearVerifierArtifacts; default case for unknown check kinds; hash-match. |
| `src/mission/flight-recorder.ts` | production | connected | covered | no | SECRET_PATTERNS (10 patterns); sanitize on push. failureMessage NOT scrubbed (F-SEC-005). |
| `src/mission/artifact-record.ts` | production | connected | covered | no | Artifact provenance. |
| `src/mission/failure-class.ts` | production | connected | covered | no | Failure taxonomy (Section 13). |
| `src/mission/config-validator.ts` | production | connected | covered | no | STANDARD_PROVIDER_REQUIREMENTS. |
| `src/gateway/main.ts` | production | connected | covered | YES | Entry point. Fail-closed logic; `service.shutdown(10_000)` at line 379; `process.exit(clean?0:1)` at line 407; SIGTERM/SIGINT handlers at 414-415. **Exit-code-1 branch UNTESTED (G6-09-002).** |
| `src/gateway/http-server.ts` | production | connected | covered (17 tests) | no | HTTP API; Bearer auth + `timingSafeEqual`; 1MB body cap; `[^/]+` missionId regex. |
| `src/gateway/a2a-server.ts` | production | connected | covered (7+5 tests) | YES | Official @a2a-js/sdk server; AsyncLocalStorage callerContext; cancelTask silent-reject; securitySchemes declared; streaming `-32601`. `extractCallerFromUser` fallback grants mission:submit (F-SEC-004). |
| `src/gateway/mission-service.ts` | production | connected | covered | YES | MissionService; `start()/get()/cancel()/getArtifacts()/shutdown()`; idempotency; admission control; terminal-mission eviction (5 min default); sweepTimer unref. **close() safety net has no per-runtime timeout (G6-09-001).** |
| `src/gateway/types.ts` | production | connected | covered | no | PARTIAL→A2A FAILED (state 4) mapping (P1-A2A-PARTIAL-TO-COMPLETED fix). |
| `src/agui/event-bridge.ts` | production | partial | covered (16 tests) | no | AG-UI emitter; in-process consumer only; 3 schema fixes in Phase 6; 12 protocol findings deferred (RR-06). |
| `src/work/git-workspace.ts` | production | connected | covered | YES | Per-mission clone + worktrees; `inside()` path assertion; shellQuote; never writes to source. |
| `src/work/integration-manager.ts` | production | connected | covered | no | Worker-branch → integration-branch merge. |
| `src/work/repo-mission.ts` | production | connected | covered | no | GROUP 3 repository mission wiring. |
| `src/work/dev-runtime.ts` | dev-only | connected | covered | no | Dev-mode dev-fallback runtime. |
| `src/learning/candidate.ts` | experimental | disconnected | partial | no | Research code; not wired to gateway (C-LEARNING-FINDING-018). |
| `src/learning/candidate-generator.ts` | experimental | disconnected | partial | no | Statistical candidate generator. Dormant. |
| `src/learning/evaluation.ts` | experimental | disconnected | partial | no | RulePatternEvaluator. Dormant. |
| `src/learning/evolution.ts` | experimental | disconnected | partial | no | EvolutionSandbox; bounded variant evaluation. Dormant. |
| `src/learning/experience.ts` | experimental | disconnected | partial | no | Experience schema v2. |
| `src/learning/experience-store.ts` | experimental | disconnected | partial | no | Local experience store. |
| `src/learning/pattern.ts` | experimental | disconnected | partial | no | OrganizationalPattern types. |
| `src/index.ts` | production | connected | covered | no | Barrel. |

**SPOF summary:** 10 production modules are single points of failure (`zai-reasoning`, `openbot/adapter`, `openbot/computer-process`, `worker-agent`, `orchestrator`, `verification`, `gateway/main`, `gateway/a2a-server`, `gateway/mission-service`, `work/git-workspace`). Most SPOFs are inherent to a single-process system; the **OpenBot process spawn + adapter** SPOF is the most consequential because it is not exercised live in any test.

---

## 2. Production LOC count and complexity hotspots

### 2.1 Production LOC by major subsystem

| Subsystem | Files | Approximate LOC (auditor estimate) | Notes |
|---|---|---|---|
| Gateway (main + http-server + a2a-server + mission-service + types) | 5 | ~3,200 | `a2a-server.ts` (721) + `mission-service.ts` (999) dominate. |
| Mission (orchestrator + verification + flight-recorder + artifact-record + failure-class + config-validator) | 6 | ~3,500 | `orchestrator.ts` (1,081) is the largest single file. |
| Worker (worker-agent + handoff) | 2 | ~1,200 | `worker-agent.ts` (1,111) is the second-largest file. |
| Runtime contracts + memory + composite + adapters | 10 | ~2,200 | `computer-process.ts` (320) + `openbot/adapter.ts` (261) + `computer-api.ts` (229) cluster. |
| Providers (zai, stub, jev) | 3 | ~1,000 | `jev-decision-provider.ts` (483) is the largest. |
| Goal / Organization / Genome / Routing | 7 | ~1,500 | Mostly small focused modules. |
| Work (git-workspace + integration-manager + repo-mission + dev-runtime) | 4 | ~1,200 | `git-workspace.ts` (446) is the largest. |
| AG-UI / MCP / Federation | 5 | ~1,400 | `federation/service.ts` is largest; `a2a-server.ts` separate. |
| Contracts (core.ts) | 1 | ~400 | Frozen. |
| Learning (experimental, not in production wiring) | 8 | ~900 | Dormant; not part of production LOC for risk purposes. |
| **Total production LOC** | ~41 files | **~12,100** | Excludes learning experimental code and tests. |

### 2.2 Complexity hotspots

1. **`src/mission/orchestrator.ts` (1,081 LOC, SPOF)** — per-mission orchestration including the `finally{}` cleanup block (lines 855-868), `inMemoryFlightEvents` array (cap 10_000), `expectHash` auto-computation (lines 639-653), the worker-step cap, and the single bounded retry on verification failure. This is the densest single file in the codebase. Cyclomatic complexity appears high due to nested try/catch, per-phase state transitions, and verifier-vs-specialist worker handling.
2. **`src/worker/worker-agent.ts` (1,111 LOC, SPOF)** — action loop, command policy (7 regexes at 263-297), TOOL OUTPUT framing (924-938), claimed-artifacts existence check (964-979), and the genome-grants dispatch table. The framing defense is verified by source-string check only.
3. **`src/gateway/mission-service.ts` (999 LOC, SPOF)** — MissionService with `start()` admission control, `requireMission()` AuthZ, `getArtifacts()` path-traversal filter, `shutdown()` per-mission drain + per-runtime `close()`, `sweepTerminalMissions()` eviction, `cancel()` monotonic-state check, `captureVerificationResult()`. The `shutdown()` close() pass (lines 359-384) has no per-runtime timeout — the largest latent failure mode (G6-09-001).
4. **`src/gateway/a2a-server.ts` (721 LOC, SPOF)** — official @a2a-js/sdk server, AsyncLocalStorage `callerContext`, silent-reject `cancelTask` (three early-return paths at 157-206), `pollToTerminal` deadline, `extractCallerFromUser` fallback (517-532 — confused-deputy surface, F-SEC-004).
5. **`src/providers/jev-decision-provider.ts` (483 LOC)** — optional decision primitive; 32 tests + 1 live call SUCCEEDED. Endpoint/model pinning and allow-list enforcement; low complexity but the only external paid integration.
6. **`src/runtime/openbot/computer-process.ts` (320 LOC, SPOF)** — `detached:true` spawn (173-194) and the 2-stage SIGTERM/SIGKILL kill (256-289). Includes `pidsWorkingUnder()` cwd sweep (Linux procfs dependency). Live spawn never exercised; 2s SIGKILL escalation is dead code from a test perspective.
7. **`src/mission/verification.ts` (709 LOC, SPOF)** — VerificationLoop with `clearVerifierArtifacts()`, `cleanRoomPath()`, `hash-match`/`mission-input` `expectHash` kinds, default case for unknown check kinds. Defense-in-depth for false-success prevention; well-tested (6+9 tests + 5 IT-FS-*).

---

## 3. Hidden coupling / duplicate abstractions

### 3.1 Hidden coupling

1. **In-memory state coupling between MissionService and MissionOrchestrator.** `MissionService.start()` synchronously returns a `missionId` and asynchronously constructs an orchestrator on a `setImmediate`-style tick. The `ShutdownResult` shape depends on the orchestrator's `finally{}` block completing. The `close()` safety net iterates `seenRuntimes` (a Map populated by `runtimeFactory` invocations). A test that calls `service.start()` and immediately `service.shutdown()` may race this set — the `IndependentStubRuntime` race at IT-07 confirms the orchestrator and the close pass share state transitively.
2. **AsyncLocalStorage propagation across the A2A boundary.** `a2a-server.ts` constructs a `callerContext` via `AsyncLocalStorage` and reads it inside `cancelTask`. Any code path that re-enters the SDK (e.g., a future federation call) must propagate the context; there is no compile-time guarantee. The `extractCallerFromUser` fallback (517-532) is reachable if a non-Genesis `User` is ever injected (F-SEC-004).
3. **`process.env` is the implicit config transport.** `loadConfig()` in `main.ts` reads env at startup; runtime adapters and the Jev provider all read env at construction time. The `env: { ...process.env, ... }` spread in `computer-process.ts:175-184` is the largest hidden coupling surface (F-SEC-001) — every worker child process sees the entire gateway env.
4. **`ownership.yaml` is loaded by both genome-compiler and orchestrator.** The orchestrator reads ownership to dispatch workers; the genome compiler reads ownership to compile genomes. The two paths must agree on schema; a schema change in ownership.yaml requires coordinated test updates across two test suites.
5. **Path-traversal filter is duplicated across 4 sites.** The `..`/absolute-path filter appears at `mission-service.ts:720`, `adapter.ts:222`, `memory-computer.ts:135`, and the `[^/]+` regex at `http-server.ts:129`. A regression in one site is not automatically caught by the others' tests.

### 3.2 Duplicate / parallel abstractions

1. **`MemoryComputer` vs `OpenBotRuntimeAdapter` vs `CompositeRuntime`.** All three implement `WorkerRuntime` + `ArtifactsProvider`, but only `OpenBotRuntimeAdapter` enforces real path confinement (via upstream OpenBot). `MemoryComputer` does NO path validation (F-SEC-002) — the dev-mode test path is structurally different from the production path.
2. **`MemoryFlightRecorder` vs `FileFlightRecorder`.** Both sanitize on push, but only `FileFlightRecorder` writes to disk. The `inMemoryFlightEvents` array in the orchestrator is a third parallel event store (capped at 10_000) — three event streams exist concurrently for the same mission.
3. **`StubReasoningProvider` (G6-08 Phase 2) vs `ScriptedReasoningProvider` (independent tests).** Both implement `ReasoningProvider` with hardcoded responses. The G6-08 stub is labeled in startup logs; the independent harness uses a separate stub class. The two implementations could drift in subtle ways (e.g., hangMs handling).
4. **`RuleBasedDecisionProvider` (default) vs `JevDecisionProvider` (optional).** Both implement `DecisionProvider`; the Jev provider is gated by env and falls back transparently. The contract is the same but the test surfaces are different (32 mocked tests for Jev vs X tests for the rule-based path).
5. **`ControlledStubRuntime` (target worktree tests) vs `IndependentStubRuntime` (independent tests).** Both implement `WorkerRuntime` for test purposes. The independent stub adds `closeBehavior: 'hang'|'throw'|'ok'` to surface the close() timeout gap — a capability the target worktree's stub lacks.

---

## 4. Production/test separation quality

### 4.1 Assessment: GOOD with caveats

| Criterion | Assessment | Evidence |
|---|---|---|
| Production source under `src/` | clean separation | All production code lives under `src/`; tests under `tests/`. |
| Test helpers promoted to production when needed | tracked | `MemoryRuntime`/`MemoryComputer` was promoted from `tests/helpers/` to `src/runtime/memory-computer.ts` (RC-5); documented. |
| Stub providers labeled | yes | `stub-reasoning.ts` prints a banner at startup; P5 tests confirm. |
| Controlled-stub runtime explicit | yes | `ControlledStubRuntime` is the canonical test runtime for production-mode integration tests. |
| Independent harness workspace separation | yes | `/home/z/my-project/genesis-audit/workspace/tests/` is outside the target worktree; target worktree is read-only. |
| Tests reach into production source via string paths | only in 1 P5 test | `P5-04` reads `src/worker/worker-agent.ts` source to assert the TOOL OUTPUT prefix string is present (source-string check, F-SEC-003 limitation). |
| Env-var gating for live tests | yes | OpenBot tests skip when `$GENESIS_OPENBOT_DIR` is unset; 6 of 8 skip in clean room. |

### 4.2 Caveats

1. **P5-04 source-string check** is a test-smell — it asserts a string is present in source rather than asserting the runtime behavior. A regression that moves the prefix to a post-hoc log would still pass (F-SEC-003).
2. **No end-to-end subprocess test for exit code 1.** The `tests/g6-08-r1/shutdown-lifecycle.test.ts` suite (12 tests) uses `ControlledStubRuntime` (in-process) and asserts the clean branch only. The unclean branch and the catch block at `main.ts:411` are dead code from a test perspective (G6-09-002).
3. **Independent harness is preserved at** `/home/z/my-project/download/G6-09-Independent-Qualification/harness/independent-adversarial.test.ts` — the harness is part of the audit evidence package, not the target worktree.

---

## 5. Observability assessment

### 5.1 Available signals

| Signal | Source | Coverage |
|---|---|---|
| Flight events (structured) | `flight-recorder.ts` MemoryFlightRecorder + FileFlightRecorder | per-mission event taxonomy: `mission-started`, `worker-step`, `verification-event`, `mission-completed`, etc. Sanitize-on-push with 10 SECRET_PATTERNS. Cap 1000 events default + 10_000 `inMemoryFlightEvents` array. |
| Raw process output | `flight-recorder.ts raw()` | scrubbed per line + 2000-char cap. |
| `health()` endpoint | MissionService.health() | exposes `totalMissions`, active count, terminal count, sweep stats. |
| `ShutdownResult` structured payload | mission-service.ts:173-212 | per-mission drain outcome, per-runtime close outcome, runtimeAdapterCloseErrors count, `clean` boolean. |
| Startup banner | main.ts | prints runtime mode, provider selection, restart-recovery limitation. |
| AG-UI event bridge | `agui/event-bridge.ts` | in-process EventEmitter consumer only; not exposed via SSE per A2A AgentCard. |

### 5.2 Gaps

1. **No metrics exposition (Prometheus / OpenTelemetry).** Observability is log/event-based only; no time-series export.
2. **No distributed tracing.** Cross-mission/cross-worker traces would require manually correlating flight events.
3. **Failure-message leakage.** `failureMessage = error.message.slice(0, 300)` and `cleanupError = e.message.slice(0, 200)` cap length but do NOT pattern-scrub secrets (F-SEC-005). An upstream error containing `Bearer ghp_...` survives into the public API.
4. **No `liveness` vs `readiness` distinction.** `GET /healthz` exists; no separate `readyz` that checks runtime adapter warmup.
5. **Worker-process stdout/stderr** is captured by `flight-recorder.ts raw()` but there is no per-worker log file segregation in the audit evidence — operators must reconstruct from the in-process event stream.
6. **Jev call cost metering.** The credentials.env tracks `1/20 paid calls used, $0.00001667 spent` — this is a manual ledger, not an automated meter. A drift in the meter would not be detected.

---

## 6. Error taxonomy assessment

### 6.1 Implemented taxonomy (`src/mission/failure-class.ts`)

The codebase defines a structured failure taxonomy (the G6-08 §13 spec). Key classes observed:

- `MissionNotFoundError` (404 path for cross-caller)
- `MissionAdmissionError` (admission control: max active, idempotency collision, oversized outcome)
- `MissionTimeoutError` (mission wall-clock)
- Verification failures (`{ ok: false, detail: '...' }` outcomes from `verify()`)
- `runtimeAdapterCloseErrors` counter (in `ShutdownResult`)
- Cleanup errors (length-capped at 200 chars)

### 6.2 Strengths

- **Caller-visible errors map to HTTP status codes correctly.** `MissionNotFoundError` → 404 (not 403, to avoid leaking existence). `MissionAdmissionError` → 429/ADMISSION_DENIED. Verification failures → mission FAILED/PARTIAL.
- **ShutdownResult surfaces unclean shutdown** — `runtimeAdapterCloseErrors` count and per-runtime `closeError` strings are exposed.
- **Idempotency errors are caller-scoped** — the same idempotency key from a different caller yields `MissionAdmissionError` with `idempotency key ... another caller` text.

### 6.3 Gaps

1. **Failure message leakage (F-SEC-005).** `failureMessage` is length-capped (300 chars) but not pattern-scrubbed. Secrets embedded in upstream error messages survive into the public API.
2. **No failure-class field on MissionSnapshot.** The `failureMessage` is a free-text field; there is no enum classifying the failure (TIMEOUT vs VERIFICATION vs RUNTIME vs CANCEL). Operators must regex the message text to classify.
3. **Cleanup errors are best-effort.** The orchestrator's `finally{}` block calls `stopWorker` per-worker; failures are swallowed. The structured `ShutdownResult` only surfaces `runtimeAdapterCloseErrors`, not per-worker stop errors.
4. **No structured retry classification.** The orchestrator has a single bounded retry on verification failure; the retry decision is hardcoded, not configurable per failure class.
5. **`extractCallerFromUser` fallback has no error class** — it silently grants `mission:submit` to any SDK `User` with `isAuthenticated=true` (F-SEC-004, deferred per remediation ledger).

---

## 7. Failure isolation assessment

### 7.1 Per-mission isolation

| Boundary | Mechanism | Strength |
|---|---|---|
| Per-mission workspace dir | `git-workspace.ts` per-mission clone under `${rootDir}/${missionId}/`; `inside()` path assertion | STRONG — filesystem-level separation. |
| Per-mission runtime adapter | `RuntimeFactory` constructs fresh `OpenBotRuntimeAdapter` per mission (RB-2 closure) | STRONG in production (RB2-01..04); MemoryRuntime is shared in dev. |
| Per-mission worker processes | `detached:true` spawn; per-worker `COMPUTER_TOKEN` (24 random bytes); per-worker env (currently leaks gateway env — F-SEC-001) | MIXED — process isolation is strong; secret isolation is BROKEN. |
| Per-mission event stream | `inMemoryFlightEvents` array per orchestrator; `MemoryFlightRecorder` per mission | STRONG. |
| Per-mission verification | `cleanRoomPath()` + verifier worker `mission-verifier-1` deterministic ID + `clearVerifierArtifacts()` bounded to `artifacts/` subtree | STRONG (IT-FS-01..05 confirm). |

### 7.2 Cross-mission isolation

- **Idempotency keys are caller-scoped** — cross-caller reuse rejected (IT-10, P3-04).
- **Mission ID is a `randomUUID`** — not enumerable in practical time.
- **CallerId is enforced at every read path** — `requireMission(missionId, caller)` is the single gate for get/events/result/artifacts/cancel (ISO-01..04).

### 7.3 Failure-domain boundaries

- **`cancelTask` is silent-reject for unauthorized callers** — no eventBus.publish, no JSON-RPC error code that distinguishes "not found" from "not authorized" (P5-03).
- **`pollToTerminal` deadline** — bounds A2A blocking calls; on deadline, publishes FAILED, cancels mission, deletes binding (B-A2A-FINDING-002/-003 closure).
- **Worker step cap (`maxWorkerSteps: 5`)** — bounds per-worker action count.
- **Mission timeout (`defaultMissionTimeoutMs: 60_000`)** — bounds the overall mission wall-clock.

### 7.4 Failure-isolation weaknesses

1. **Single-process gateway.** A bug in any SPOF module (orchestrator, mission-service, a2a-server, worker-agent, verification, gateway/main) crashes the entire gateway and loses all in-flight state. Mitigation: structured shutdown + honest disclosure (C-048 OUT_OF_SCOPE).
2. **`runtime.close()` safety net has no per-runtime timeout.** A hung OpenBot `close()` hangs the entire gateway shutdown (G6-09-001). SIGKILL is the only operator recourse.
3. **`finally{}` block in orchestrator is best-effort.** Per-worker `stopWorker` failures are swallowed.
4. **`zai-reasoning.ts` has no per-call timeout** (F-SEC-007). A single hung reasoning call pins a worker slot for the full `missionTimeoutMs` (60s default); with `maxActiveMissions=5`, a malicious goal can pin 5 slots per caller.

---

## 8. Resource ownership assessment

### 8.1 Resource ownership map

| Resource | Owner | Lifecycle | Cleanup |
|---|---|---|---|
| HTTP server (`node:http`) | `main.ts` | process lifetime | `server.close()` in shutdown handler |
| MissionService instance | `main.ts` | process lifetime | `service.shutdown(10_000)` then `service.close()` |
| Per-mission orchestrator | MissionService.start() | per-mission | `finally{}` block at orchestrator.ts:855-868 |
| Per-mission WorkerRuntime | RuntimeFactory (RB-2 fresh per mission) | per-mission | `runtime.close()` in MissionService.shutdown() safety net |
| Per-worker computer process | OpenBotRuntimeAdapter.ensureWorker() | per-worker | `stopWorker()` then `close()` in adapter |
| Per-mission workspace directory | git-workspace.ts | per-mission | filesystem-side, not aggressively deleted (sweepTerminalMissions evicts from registry, leaves disk) |
| Per-mission event stream | MissionService + Orchestrator | per-mission | GC when mission leaves registry |
| `sweepTimer` | MissionService | process lifetime | `unref()` — does not keep process alive |
| JevDecisionProvider HTTP client | optional, per-call | per-call | none (stateless client) |

### 8.2 Ownership strengths

- **Per-mission runtime factory (RB-2)** is a clean ownership boundary.
- **`sweepTimer.unref()`** correctly prevents the sweep timer from keeping the process alive.
- **Per-worker `COMPUTER_TOKEN`** is 24 random bytes, per-worker, not shared.
- **`detached:true` spawn** correctly places the worker in its own process group for SIGKILL escalation.

### 8.3 Ownership weaknesses

1. **`runtime.close()` in MissionService.shutdown() is awaited without a per-runtime timeout.** The close() safety net iterates `seenRuntimes` and awaits each `rt.runtime.close()`. If a single runtime's close() hangs, the entire shutdown hangs (G6-09-001, P1 REPRODUCED). The operator's only recourse is SIGKILL.
2. **Per-worker `stopWorker` in orchestrator's `finally{}` is best-effort and silent on failure.** If `stopWorker` throws, the error is swallowed; the structured `ShutdownResult` does not surface per-worker stop errors.
3. **Per-mission workspace directory is not aggressively cleaned up.** `sweepTerminalMissions` evicts from the registry but leaves the on-disk workspace. Disk growth is operator-managed.
4. **`MemoryRuntime` does not implement `close()`.** The safety net in `MissionService.shutdown()` becomes a no-op in dev mode (IT-13 confirms). Dev-mode orphaned workers (none, since MemoryRuntime is in-process) are not cleaned up via close() — but this is by design.
5. **`process.env` ownership is implicit.** Every worker child process inherits the gateway's full env (F-SEC-001). The gateway does not own a minimal env for workers.

---

## 9. Documentation quality

### 9.1 Document inventory (READ-ONLY, audited)

| Document | Quality | Notes |
|---|---|---|
| `README.md` | GOOD | Project orientation, layout, OpenBot boundary, GROUP 1/2 status, env-gated live tests. |
| `docs/release/engine-v1-scope.md` | EXCELLENT | Capability matrix, execution modes, "what this release is NOT" — honest about limitations. |
| `docs/release/engine-v1-changelog.md` | EXCELLENT | G6-08 Phase 1-7 remediation ledger in narrative form; finding IDs cited inline. |
| `docs/release/engine-v1-configuration.md` | GOOD | Env vars, fail-closed behavior, secret hygiene. |
| `docs/release/engine-v1-evidence-index.md` | GOOD | Current + historical evidence + test counts (578/9/587). |
| `docs/release/engine-v1-install-and-run.md` | GOOD | Install, smoke mission, gateway startup, controlled-stub path. |
| `docs/release/engine-v1-known-limitations.md` | EXCELLENT | 14 limitations including RESTART_RECOVERY=UNSUPPORTED, BLOCKED_BY_ENVIRONMENT for live ZAI/OpenBot. Honest, structured. |
| `docs/release/engine-v1-security-boundaries.md` | EXCELLENT | AuthN, AuthZ, isolation, secret hygiene, threat model table. |
| `docs/architecture/GENESIS_ARCHITECTURE_MAP_v1.md` | GOOD | Worker action vocabulary, verification kinds, learning loop diagram. |
| `docs/architecture/GENESIS_FOUNDATION_AND_INTEROPERABILITY_MAP_v1.md` | GOOD | Genesis ownership map, three-pillar infra map, protocol relationship map, 10 anti-reimplementation rules. |
| `experiments/g6-07-audit/executive-summary.md` | EXCELLENT | 90 findings, 3 release blockers (RB-1/2/3), 7 root-cause clusters, SAFE_TO_BEGIN_G6_09=NO. |
| `experiments/g6-07-audit/final-audit-report.md` | EXCELLENT | Mandated status block, RB-1/2/3 deep dives. |
| `experiments/g6-07-audit/findings-detailed.md` | GOOD | B-EXEC-FINDING-001..007 detailed records. |
| `experiments/g6-08-remediation/remediation-ledger.json` | EXCELLENT | 129 finding records; closure counts: 51 FIXED_VERIFIED, 57 DEFERRED, 7 DOCUMENTED_LIMITATION, 12 NOT_A_DEFECT, 1 OPEN, 1 BLOCKED_BY_ENVIRONMENT. |
| `experiments/g6-08-remediation/residual-risk-register.md` | EXCELLENT | 9 residual risks (RR-01..09); RR-08 (lint) and RR-09 (worker teardown) are OPEN. |
| `experiments/g6-08-remediation/security-remediation.md` | GOOD | Phase 5 security closure: 5 top findings FIXED_VERIFIED with focused negative tests P5-01..10. |
| `experiments/g6-08-remediation/architecture-decisions.md` | EXCELLENT | Phase 9: DEFER_TO_FUTURE_VERSION for persistence/recovery. Honest disclosure: no persistence implemented. |

### 9.2 Documentation strengths

1. **Honest disclosure of limitations.** The 14-item known-limitations document explicitly enumerates what is NOT supported (restart recovery, single-process, no live ZAI/OpenBot execution, no learning promotion).
2. **Inline finding IDs in changelog.** Every remediation entry cites its finding ID (e.g., C-VERIFY-FINDING-005, C-SECURITY-FINDING-001) — traceable from claim to test.
3. **Structured remediation ledger.** The JSON ledger (`remediation-ledger.json`) gives a single source of truth for closure status (FIXED_VERIFIED / DEFERRED / DOCUMENTED_LIMITATION / NOT_A_DEFECT / OPEN / BLOCKED_BY_ENVIRONMENT).
4. **Architecture maps separate from release notes.** The two `docs/architecture/*` files describe the design intent; the `docs/release/*` files describe what was actually delivered.

### 9.3 Documentation gaps

1. **No live-OpenBot deployment guide.** Operators wishing to deploy with real OpenBot have README.md pointers and `docs/release/engine-v1-install-and-run.md`, but no step-by-step production deployment playbook.
2. **No operational runbook for shutdown hang.** When `service.shutdown(10_000)` hangs (G6-09-001), the operator must SIGKILL; this is not documented.
3. **No threat-model update for the worker env leak (F-SEC-001).** The security-boundaries doc does not currently enumerate the worker-process env inheritance as a residual risk.
4. **AG-UI 12 deferred protocol findings (RR-06)** are not enumerated inline in the AG-UI event-bridge source — operators must consult the remediation ledger.
5. **No "what to monitor" runbook.** Observability gaps (Section 5) are not enumerated for operators.

---

## 10. Architectural maintainability verdict

**Verdict: `PASS_WITH_LIMITATIONS`**

### 10.1 Rationale

The codebase demonstrates strong architectural hygiene in the deterministic core (goal/organization/genome/verification), with clean module separation, a frozen contracts layer, honest documentation, and a structured remediation ledger that traces every G6-07 finding to a G6-08 closure status. The 45 consolidated claims verdict distribution (26 PROVEN, 14 PROVEN_WITH_LIMITATIONS, 3 CONTRADICTED, 2 OUT_OF_SCOPE) reflects a release that is honest about what works and what does not.

However, the G6-09 independent qualification surfaced 3 CONTRADICTED claims that block clean `CONDITIONAL_ACCEPT`:

1. **C-051 (worker env inheritance, F-SEC-001, P1)** — `computer-process.ts:175-184` spreads the full `process.env` to every worker child. Mitigation is ~10 lines of code change (explicit allowlist). The independent test IT-S-09 reproduced the defect via a stub child process.
2. **C-053 (failureMessage secret scrubbing, F-SEC-005, P2)** — `mission-service.ts:620,340` length-caps but does not pattern-scrub error messages. Mitigation is ~10 lines (extend `flight-recorder.scrub()` to failureMessage).
3. **C-013 (G6-07 RB-1 defect preserved for traceability)** — the defect is GONE; the CONTRADICTED verdict tracks that the G6-07 finding is closed at the current commit. Not a blocker.

Additionally, **C-027 (shutdown deadline enforcement, G6-09-001, P1)** is PROVEN_WITH_LIMITATIONS: the drain logic exists, but the close() pass has no per-runtime timeout and the exit-code-1 branch is untested.

The architectural verdict is `PASS_WITH_LIMITATIONS` because:
- The deterministic core (Sections 3.1, 3.3, 3.4 of the claims registry) is structurally sound.
- The SPOF modules are inherent to a single-process v1 system and are honestly disclosed (C-050 OUT_OF_SCOPE).
- The 3 P1/P2 defects are localized and fixable with <30 lines of code total.
- The remediation ledger and known-limitations doc demonstrate mature engineering process.

The verdict would move to `FAIL` only if the P1 defects (C-051, G6-09-001) were not remediated before production deployment; the verdict would move to `PASS` if those defects are remediated and the test gaps (G6-09-002 exit-code-1, F-SEC-003 prompt-delivery, F-SEC-006 adversarial commands) are closed.

---

## 11. Top architectural strengths

1. **Frozen contracts layer (`src/contracts/core.ts`).** The minimal type contracts for `WorkerRuntime`, `ArtifactsProvider`, `ReasoningProvider`, `DecisionProvider` are frozen and serve as the spine of the system. Every adapter (OpenBot, OpenDots, OpenMuse, Memory, Composite) implements the same contracts.
2. **Per-mission runtime factory (RB-2 closure).** `RuntimeFactory` constructs a fresh `OpenBotRuntimeAdapter` per mission with a per-mission `rootDir`. No shared adapter, no shared workers, no shared workspace directories. RB2-01..04 tests confirm.
3. **Clean-room verification with hash-match.** `verification.ts` does clean-room copies (no shared filesystem with the producer), `clearVerifierArtifacts()` is bounded to the `artifacts/` subtree using `rm -f <path>` per file (no `rm -rf`), and the `expectHash` mechanism (orchestrator auto-computes SHA-256) replaces the fabricable 60-char fingerprint. Independent tests IT-FS-01..05 confirm false-success prevention.
4. **Honest disclosure of limitations.** The `engine-v1-known-limitations.md` document enumerates 14 limitations including `RESTART_RECOVERY=UNSUPPORTED`, `BLOCKED_BY_ENVIRONMENT` for live ZAI/OpenBot, single-process gateway, no learning promotion. The Phase 9 architectural decision (`DEFER_TO_FUTURE_VERSION` for persistence) is documented in `architecture-decisions.md`. Independent test IT-RESTART-01 confirms no durability.
5. **Caller-scoped AuthZ with 404-not-403.** `requireMission(missionId, caller)` returns 404 on callerId mismatch (not 403) to avoid leaking mission existence. `cancelTask` silent-rejects (no JSON-RPC error code that distinguishes "not found" from "not authorized"). ISO-01..04 + P5-03 tests confirm.
6. **Bounded registry with unref'd sweep timer.** `sweepTerminalMissions()` evicts terminal missions after a 5-min default TTL; `sweepTimer.unref()` does not keep the process alive. P3-01..05 tests confirm.
7. **Structured ShutdownResult payload.** The `ShutdownResult` shape exposes per-mission drain outcomes, per-runtime close outcomes, and `runtimeAdapterCloseErrors` count. This is the structured surface that surfaces the G6-09-001 close() hang defect honestly when it occurs (after the hang resolves).
8. **Jev integration is OPTIONAL and credential-scoped.** `JevDecisionProvider` is a `DecisionProvider` capability, not a hard dependency. Production deployments without `OPENROUTER_API_KEY` still function via the rule-based fallback. The 1 live diagnostic call (Campaign I) confirmed endpoint pinning, model pinning, allow-list enforcement, and bounded choice selection (no silent fallback).

---

## 12. Top architectural weaknesses

1. **Worker process env inheritance (F-SEC-001, P1 REPRODUCED, C-051 CONTRADICTED).** `computer-process.ts:175-184` uses `env: { ...process.env, ...workerSpecificVars }`. Every worker child inherits `GENESIS_API_KEYS`, `OPENROUTER_API_KEY`, `ZAI_API_KEY`. A malicious or prompt-injected worker can read all gateway secrets by running `printenv` or `cat /proc/self/environ`. **Mitigation: explicit allowlist (~10 lines of code).**
2. **No per-runtime timeout on `close()` safety net (G6-09-001, P1 REPRODUCED, C-027 PROVEN_WITH_LIMITATIONS).** `MissionService.shutdown()` iterates `seenRuntimes` and awaits `rt.runtime.close()` with no per-runtime timeout. A hung close() hangs the entire gateway shutdown. The 10s deadline at `main.ts:379` is aspirational, not enforced. Operator's only recourse is SIGKILL. **Mitigation: wrap each `await rt.runtime.close()` in `Promise.race([close(), setTimeout(perRuntimeDeadlineMs)])` (~15 lines).**
3. **Exit-code-1 branch is dead code from a test perspective (G6-09-002, P2 CODE_CONFIRMED).** `main.ts:407 process.exit(result.clean ? 0 : 1)` and `main.ts:411 catch → process.exit(1)` are never exercised by any test. An operator relying on the exit code to detect orphaned workers cannot trust the unclean path works correctly.
4. **`failureMessage` does not scrub secret patterns (F-SEC-005, P2, C-053 CONTRADICTED).** `mission-service.ts:620,340` length-caps (300/200 chars) but does not pattern-scrub. An upstream error message containing `Bearer ghp_...` or `sk-or-v1-...` survives into the public API. **Mitigation: extend `flight-recorder.scrub()` to failureMessage/cleanupError (~10 lines).**
5. **`zai-reasoning.ts` has no per-call timeout (F-SEC-007, MEDIUM).** A single hung reasoning call pins a worker slot for the full `missionTimeoutMs` (60s default). With `maxActiveMissions=5`, a malicious goal can pin 5 slots per caller for the full timeout window.
6. **Genesis-layer command policy is permissive (F-SEC-006, MEDIUM, C-034 PROVEN_WITH_LIMITATIONS).** Only 7 regex patterns are blocked. Adversarial commands (`nc -e /bin/sh`, `python -c 'import os; os.system("rm -rf ~")'`, `find / -delete`, `dd of=/tmp/x`, `chmod 666/a+w`, `tar --checkpoint-action=exec`) are NOT blocked. Defense relies on the upstream OpenBot egress filter, which is not asserted by any Genesis test.
7. **TOOL OUTPUT framing is source-string-verified only (F-SEC-003, MEDIUM, C-035 PROVEN_WITH_LIMITATIONS).** P5-04 reads `src/worker/worker-agent.ts` and asserts the prefix string is present. A regression that moves the prefix out of the scratchpad (e.g., to a post-hoc log) would still pass P5-04. No test asserts the framing reaches the reasoning provider's prompt.
8. **`MemoryComputer` does NO path validation (F-SEC-002, MEDIUM-HIGH).** Dev-mode tests do NOT catch path-traversal regressions. Production OpenBot upstream confines to `WORKSPACE_DIR`, but no Genesis test asserts this.
9. **10 SPOF modules in a single-process gateway.** `zai-reasoning`, `openbot/adapter`, `openbot/computer-process`, `worker-agent`, `orchestrator`, `verification`, `gateway/main`, `gateway/a2a-server`, `gateway/mission-service`, `work/git-workspace`. A bug in any crashes the entire gateway. Mitigated by honest disclosure (C-050 OUT_OF_SCOPE).
10. **`extractCallerFromUser` fallback (F-SEC-004, MEDIUM).** `a2a-server.ts:517-532` grants `mission:submit` to any SDK `User` with `isAuthenticated=true`. The fallback is documented as DEFERRED_WITH_JUSTIFICATION but is reachable if any non-Genesis `User` implementation is ever injected.
11. **2-stage SIGKILL escalation is dead code from a test perspective (F-SEC-008, LOW-MEDIUM, G6-09-006).** `computer-process.ts:256-289` SIGTERM → 2s grace → SIGKILL + cwd sweep. The `pidsWorkingUnder()` cwd sweep requires Linux procfs and returns empty on non-Linux. No test exercises a SIGTERM-ignoring worker.
12. **AG-UI 12 deferred protocol-compliance findings (RR-06, LOW-MEDIUM).** A strict AG-UI consumer would notice schema gaps (RUN_STARTED guard, AgentCard provider/skill fields).
13. **Hidden coupling via `process.env`.** Every worker child process sees the entire gateway env. The implicit config transport has no compile-time guarantee of secret isolation.
14. **`inMemoryFlightEvents` + `MemoryFlightRecorder` + `FileFlightRecorder` are three parallel event stores.** Schema drift across the three is possible; cap semantics differ (10_000 in-memory vs 1000 in recorder).

---

## 13. Recommended architectural improvements (prioritized)

### P0 — Required before production deployment (blocks clean `CONDITIONAL_ACCEPT`)

1. **Worker env allowlist (C-051 / F-SEC-001 / G6-09-S01).** Replace `env: { ...process.env, ...workerSpecificVars }` in `computer-process.ts:175-184` with an explicit allowlist: `env: { PORT, COMPUTER_TOKEN, WORKSPACE_DIR, PROFILES_DIR, EGRESS_POLICY_REQUIRED, PATH, HOME, ...config.extraEnv }`. ~10 lines of code change. Add a unit test that asserts `GENESIS_API_KEYS`, `OPENROUTER_API_KEY`, `ZAI_API_KEY` are NOT in the spawned worker's env. The mitigation test in `security-adversarial.test.ts` (IT-S-09 second case) already demonstrates the fix.

2. **Per-runtime timeout on `close()` safety net (C-027 / G6-09-001).** Wrap each `await rt.runtime.close()` in `Promise.race([close(), new Promise(resolve => setTimeout(resolve, perRuntimeDeadlineMs))])` in `mission-service.ts:359-384`. If the timeout wins, set `perRuntime[i].closeError = 'timeout'` and increment `runtimeAdapterCloseErrors`. ~15 lines of code change. Add a test that asserts `service.shutdown(500)` returns within ~500ms even when `close()` hangs (the IT-07 test in `independent-adversarial.test.ts` already demonstrates the defect).

3. **`failureMessage` and `cleanupError` pattern-scrubbing (C-053 / F-SEC-005).** Extend `flight-recorder.scrub()` (or its `SECRET_PATTERNS` array) to `mission-service.ts:620 (failureMessage = error.message.slice(0, 300))` and `:340 (cleanupError = e.message.slice(0, 200))`. Apply the same 10 SECRET_PATTERNS regexes. ~10 lines of code change. Add a test that asserts a fake `Bearer ghp_...` in an upstream error message is redacted in `failureMessage`. The IT-S-08 test in `security-adversarial.test.ts` already demonstrates the defect.

### P1 — Required for confident production operation

4. **Exit-code-1 end-to-end subprocess test (G6-09-002).** Add a test that spawns the gateway as a subprocess, triggers an unclean shutdown (e.g., via a stub runtime whose `close()` throws), and asserts the OS exit code is 1. Reuses the existing `tests/g6-08-r1/shutdown-lifecycle.test.ts` harness pattern but spawns a real subprocess. ~50 lines of test code. Closes the dead-code gap at `main.ts:407,411`.

5. **Per-call timeout on `ZAIReasoningProvider.reason()` (F-SEC-007).** Add a `Promise.race([reason(), new Promise((_, reject) => setTimeout(() => reject(new Error('reasoning timeout')), reasoningTimeoutMs))])` wrapper around the ZAI SDK call. Default `reasoningTimeoutMs = 10_000` (well below `missionTimeoutMs`). ~10 lines of code change. Add a test that mocks the ZAI SDK with a never-resolving promise and asserts the mission reaches FAILED within `reasoningTimeoutMs + buffer`.

6. **Prompt-delivery verification for TOOL OUTPUT framing (F-SEC-003).** Replace the source-string check (P5-04) with an end-to-end test that injects a stub reasoning provider, records the prompt it receives, triggers a tool call whose output contains "ignore previous instructions", and asserts the prompt contains the `[TOOL OUTPUT ...]` prefix. ~50 lines of test code. No production source change.

7. **Genesis-layer path validator for `MemoryComputer` (F-SEC-002).** Add `inside(workspaceDir, path)` assertion to `MemoryComputer.writeFile/readFile/listFiles`, mirroring `git-workspace.ts`. ~15 lines of code change. Add a test that asserts `writeFile('../../etc/passwd', ...)` is rejected.

### P2 — Hardening

8. **Expand the command policy blocklist OR document the upstream-filter dependency (F-SEC-006).** Either add regex patterns for `nc -e`, `python -c`, `find / -delete`, `dd of=/tmp/`, `chmod 666/a+w`, `tar --checkpoint-action=exec` OR document explicitly in `engine-v1-security-boundaries.md` that the Genesis-layer policy is intentionally permissive and the upstream OpenBot egress filter is the second layer.

9. **Tighten `extractCallerFromUser` fallback (F-SEC-004).** Remove the `user.userName` fallback for non-Genesis `User` implementations; require an explicit `callerId` field. ~5 lines of code change.

10. **2-stage SIGKILL escalation test (G6-09-006 / F-SEC-008).** Add a test that spawns a stub process that ignores SIGTERM, triggers `startComputerProcess.stop()`, and asserts the process is SIGKILL'd within 2.5s. Linux-only (procfs required). ~30 lines of test code.

11. **AG-UI 12 deferred protocol-compliance findings (RR-06).** Triage the 12 findings; close or document each.

12. **Structured failure-class enum on MissionSnapshot.** Add a `failureClass: 'TIMEOUT' | 'VERIFICATION' | 'RUNTIME' | 'CANCEL' | 'ADMISSION' | 'UNKNOWN'` field alongside `failureMessage`. Enables operators to classify failures without regex. ~20 lines of code change.

### P3 — Hygiene

13. **De-duplicate the path-traversal filter.** Extract `mission-service.ts:720`, `adapter.ts:222`, `memory-computer.ts:135` into a single `pathFilter()` utility in `src/work/path-filter.ts`. ~30 lines of code change.

14. **De-duplicate the verifier-exclusion check.** Extract `isVerifierWorkerId()` (currently at `adapter.ts:51-53`, `memory-computer.ts:32-34`, `mission-service.ts:715`) into a single utility. ~15 lines of code change.

15. **Add a `readyz` endpoint distinct from `healthz`.** `healthz` returns process-up; `readyz` returns runtime-adapter-warmup-complete. ~20 lines of code change.

16. **Prometheus metrics exposition.** Add `/metrics` endpoint with mission counters (active, terminal, failed-by-class, drained-on-shutdown, runtime-close-errors). ~100 lines of code change.

17. **Operational runbook for shutdown hang.** Document that when `service.shutdown(10_000)` hangs, the operator must SIGKILL the gateway process and manually inspect any worker child processes via `pidsWorkingUnder()`.

18. **Live-OpenBot deployment playbook.** Step-by-step production deployment guide for operators wishing to deploy with real OpenBot, including `$GENESIS_OPENBOT_DIR`, env allowlist verification, and worker egress filter assertion.

---

**End of architecture assessment.**
