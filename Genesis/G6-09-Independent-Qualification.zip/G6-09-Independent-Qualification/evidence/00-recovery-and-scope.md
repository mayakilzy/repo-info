# 00 — Recovery and Scope Verification

**Audit session:** web-7c6a0087-e31a-4321-ad21-ec1274161b16
**Audit start (UTC+8):** 2026-10-08 07:55
**Role:** Independent Principal Engineer / Enterprise Acceptance Authority
**Mode:** Adversarial, evidence-first, read-only production audit
**Target commit (immutable, expected):** `825888fe45326573d9bfc5157f78ada9cd533b20`
**Target branch:** `build/group-06-productionization`

## 1. Repository verification

| Field | Expected | Observed | Match |
|---|---|---|---|
| Owner/repo | mayakilzy/AgentCraft-Genesis | mayakilzy/AgentCraft-Genesis | yes |
| Visibility (per GitHub API) | — | public (`private: false`) | n/a |
| Default branch | — | `build/group-01-foundation-born-core` | n/a |
| Default branch SHA | — | (not audited, out of scope) | n/a |
| Target branch | `build/group-06-productionization` | `build/group-06-productionization` | yes |
| Target branch HEAD SHA | `825888fe45326573d9bfc5157f78ada9cd533b20` | `825888fe45326573d9bfc5157f78ada9cd533b20` | yes |
| Target commit reachable | yes | HTTP 200 via API | yes |
| Commit author | — | `g6-08-r1@genesis.local` | n/a |
| Commit message (first line) | — | `G6-08-R1: final release-gate closure (CI, lint, B-EXEC-FINDING-003)` | n/a |
| Worktree status | clean | clean (0 dirty) | yes |
| Remote origin URL | — | `https://github.com/mayakilzy/AgentCraft-Genesis.git` | n/a |

**Verdict:** TARGET_COMMIT_VERIFIED ✓

## 2. Toolchain

| Component | Version |
|---|---|
| Node.js | v24.21.0 |
| npm | 11.19.0 |
| git | 2.47.3 |
| Python | 3.12.14 |
| OS | Linux 5.10.134 x86_64 (Alibaba Cloud kernel) |
| Hostname | c-6ac7442c-14810412-0e0f07112a62 |

## 3. Audit workspace layout

```
/home/z/my-project/
├── secure/credentials.env              # GH_TOKEN + OPENROUTER_API_KEY (mode 0600)
├── genesis-audit/
│   ├── worktree/genesis/              # clean clone pinned to target SHA
│   ├── workspace/                     # independent test harness workspace
│   └── checkpoints/                  # per-stage resume state
├── download/G6-09-Independent-Qualification/
│   ├── evidence/                      # evidence files (this file lives here)
│   ├── harness/                       # independent test harnesses
│   ├── fixtures/                      # test inputs and expected outputs
│   └── manifests/                     # SHA-256 evidence package manifest
└── worklog.md                         # shared multi-agent work log
```

## 4. Credential handling

- Operator supplied obfuscated credentials via `newT5.zip` (GitHub PAT) and `newT6.zip` (OpenRouter API key) at the operator's personal public repository.
- Both were de-obfuscated per operator instructions (strip obfuscation characters; CRLF handled).
- Format sanity check performed (length + regex); both pass.
- Persisted at `/home/z/my-project/secure/credentials.env` with mode 0600.
- No credential has been printed in any artifact, log, script source, git config, or chat output.
- The clone was performed **anonymously** because the repository is public; the GitHub PAT was not used for cloning and is retained only for any subsequent operator-authorized operations.
- The OpenRouter key is reserved exclusively for Campaign I (live Jev qualification), with hard caps: USD $0.25 total spend, 20 paid calls.

## 5. Audit independence safeguards

- No modification to the target commit.
- No modification to existing tests in the target worktree.
- No new commits on the target branch.
- All independent harnesses live under `/home/z/my-project/genesis-audit/workspace/` and under the audit evidence package — not in the cloned worktree.
- Any fault injection is bounded to the audit workspace; cleanup is tracked.
