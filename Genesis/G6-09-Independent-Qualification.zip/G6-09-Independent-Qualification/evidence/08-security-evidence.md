# 08 — Security Evidence (Campaign G)

**Audit:** G6-09 Independent Adversarial Qualification
**Target commit:** `825888fe45326573d9bfc5157f78ada9cd533b20`
**Audit date:** 2026-10-08

## 1. Reconnaissance summary

A focused subagent (Task ID: stage-1-5-recon) inspected the security-relevant modules and produced a full report at `/home/z/my-project/genesis-audit/workspace/stage-5-security-recon.md`. The report covers:

- 12 source files inspected (http-server, a2a-server, mission-service, git-workspace, computer-process, openbot/adapter, orchestrator, plus 6 tests)
- 13 threat classes from §13 of the G6-09 mandate
- 10 security findings (F-SEC-001..010)
- 15 proposed independent tests (IT-S-01..15)

## 2. Top security findings

| ID | Title | Severity | Confidence | Reproduced by IT-S-NN? |
|---|---|---|---|---|
| G6-09-S01 / F-SEC-001 | OpenBot worker process inherits gateway's full env | P1 | HIGH | IT-S-09 ✓ |
| F-SEC-002 | MemoryComputer (dev mode) does NO path validation | MEDIUM-HIGH | (not independently tested) |
| F-SEC-003 | TOOL OUTPUT framing verified only by source-code string check | MEDIUM | (not independently tested) |
| G6-09-S03 / F-SEC-004 | A2A User fallback grants mission:submit | informational (MEDIUM) | code inspection only |
| F-SEC-005 | Error messages length-capped but NOT pattern-scrubbed | MEDIUM | IT-S-08 (partial — defect not reproduced in this run; defense-in-depth concern remains) |
| G6-09-S02 / F-SEC-006 | Genesis command policy blocks 7 patterns but allows common adversarial commands | P3 (defense-in-depth gap) | IT-S-06 (code inspection) |

## 3. Independent test execution

Independent harness at `/home/z/my-project/genesis-audit/workspace/tests/security-adversarial.test.ts` (preserved copy in `harness/`). Ran via `npx vitest run --no-color tests/security-adversarial.test.ts` (test output saved to `harness/security-adversarial-test-output.txt`).

### Result

```
Test Files  1 passed (1)
     Tests  4 passed (4)
  Duration  1.89s
```

All 4 tests passed. **Passing in this context means "test ran without unexpected failure"** — for IT-S-09, the test PASSES by demonstrating the defect exists (the worker can read the gateway's secrets).

## 4. Per-test evidence

### IT-S-09 / F-SEC-001 — OpenBot worker env inheritance (HIGH, REPRODUCED)

**Setup:**
1. Set `process.env.GENESIS_API_KEYS` to a fake JSON map.
2. Set `process.env.OPENROUTER_API_KEY` to a fake `sk-or-v1-...` value.
3. Spawn a stub `bun` (a small Node script that prints its env) using the exact same `env: { ...process.env, ...workerSpecificVars }` pattern from `computer-process.ts:175-184`.

**Observed:**
- The stub worker's printed env contained `GENESIS_API_KEYS` with the gateway's value.
- The stub worker's printed env contained `OPENROUTER_API_KEY` with the gateway's value.
- The stub worker's printed env also contained `COMPUTER_TOKEN` (this one is intentional — the worker needs it to authenticate to the runtime).

**Conclusion:** DEFECT CONFIRMED. The OpenBot worker process inherits the gateway's full `process.env`, including `GENESIS_API_KEYS`, `OPENROUTER_API_KEY`, and `ZAI_API_KEY`. A malicious or prompt-injected worker can exfiltrate these by running `printenv` or `cat /proc/self/environ`.

### IT-S-09 (mitigation variant) — Explicit env allowlist prevents the leak

**Setup:** Same as above, but the spawn uses an explicit allowlist instead of `...process.env`:
```typescript
env: {
  PORT: '4199',
  COMPUTER_TOKEN: 'stub-token',
  WORKSPACE_DIR: '/tmp/stub-ws',
  PROFILES_DIR: '/tmp/stub-pr',
  EGRESS_POLICY_REQUIRED: '0',
  PATH: process.env.PATH,
  HOME: process.env.HOME,
}
```

**Observed:**
- The stub worker's printed env did NOT contain `GENESIS_API_KEYS` (undefined).
- The stub worker's printed env did NOT contain `OPENROUTER_API_KEY` (undefined).
- The stub worker's printed env DID contain `COMPUTER_TOKEN`, `PORT`, `WORKSPACE_DIR` (intentional).

**Conclusion:** MITIGATION CONFIRMED. Replacing `env: { ...process.env, ... }` with an explicit allowlist closes the credential boundary breach with ~10 lines of code change.

### IT-S-08 / F-SEC-005 — Error message secret scrubbing (MEDIUM)

**Setup:** Constructed a MissionService with a reasoning provider that throws an error whose message contains a fake secret pattern (`Bearer sk-or-v1-FAKE_SECRET_FOR_AUDIT_DEMO_12345`). Submitted a mission, let it fail, and read the `failureMessage` via the public API.

**Observed:** The mission reached FAILED or PARTIAL state. The `failureMessage` field was a string. The test could not conclusively determine whether the secret pattern appeared in the failureMessage because the orchestrator may have caught the error elsewhere (the secret may not have propagated to the public API surface).

**Conclusion:** This test is INCONCLUSIVE — the defense-in-depth concern (F-SEC-005: error messages are length-capped but NOT pattern-scrubbed) remains valid from code inspection, but the public API surface may already scrub it. Further investigation needed.

### IT-S-06 / F-SEC-006 — Genesis command policy inspection

**Setup:** Searched the source tree for command-policy logic. Found 3 files matching the policy patterns:
- `src/gateway/http-server.ts`
- `src/mission/verification.ts`
- `src/worker/worker-agent.ts`

**Observed:** The `checkCommandPolicy` function at `src/worker/worker-agent.ts:280-310` implements 7 regex patterns (rm -rf /, rm -rf ~/$HOME, mkfs, dd of=/dev/, shutdown/reboot/halt/poweroff, curl|sh, chmod 777). The function comment states the policy is "intentionally permissive for normal development work" and that defense-in-depth relies on the OpenBot adapter's egress filter as the primary defense.

**Conclusion:** The command policy has known gaps — adversarial commands like `nc -e /bin/sh` (reverse shell), `python -c '...'` (arbitrary code execution), `find / -delete` (alternative recursive deletion) are NOT blocked by the Genesis layer. The OpenBot egress filter is the primary defense, but was not audited (requires real OpenBot infrastructure).

## 5. Campaign G verdict

**SECURITY = FAIL** (per the qualification matrix).

The failure is caused by one independently reproduced P1 defect (G6-09-S01: OpenBot worker env inheritance) that constitutes a credential boundary breach in production mode. The defect is minimal to fix (~10 lines of code change with an explicit env allowlist), and the mitigation is proven by the second variant of IT-S-09.

The other security findings (F-SEC-002 through F-SEC-006) are MEDIUM/LOW/informational — defense-in-depth gaps that do NOT block release but should be remediated in a follow-up.

## 6. Deferred security investigations

The following security investigations were NOT run due to time and environment constraints:

1. **Prompt injection attack** (Campaign G threat class: prompt injection) — requires a real LLM to test if injected instructions in tool descriptions or retrieved documents can subvert the worker's authorized goal. The verification loop's clean-room design (Campaign F IT-FS-01..05) provides defense-in-depth against prompt-injected false-success, but does NOT prevent prompt injection itself.

2. **Workspace traversal attack** — requires a real OpenBot worker to test if a malicious file path (e.g., `../../etc/passwd`) escapes the workspace confinement. The dev-mode MemoryComputer does NO path validation (F-SEC-002) — production OpenBot does, but was not exercised.

3. **Confused-deputy attack** — requires a multi-caller scenario where one caller's mission is influenced by another's. The cross-caller idempotency rejection (IT-10) and terminal-state monotonicity (IT-MONO-01) cover the basic cases, but a full confused-deputy attack would require a multi-caller concurrent setup with shared resources.

These deferred investigations are documented as EVIDENCE_GAP — they are NOT failures, but they are NOT independently verified either.

## 7. What the audit DID confirm

Despite the REJECT verdict on the security dimension, the audit confirmed several security-positive behaviors:

1. **Authentication boundary** — `authenticateA2A` and the HTTP API authentication both use constant-time comparison of opaque API keys. No mTLS/OAuth/JWT (documented as limitation #3 in `engine-v1-known-limitations.md`).

2. **Authorization enforcement** — `caller.allowedOperations` is checked at `mission-service.ts:492-497`; callers without `mission:submit` are rejected.

3. **Idempotency-key caller binding** — `mission-service.ts:504` checks `existingMission.callerId === caller.callerId` before returning the existing missionId. Cross-caller reuse is rejected (IT-10 PASSED).

4. **Terminal-state immutability** — once a mission reaches SUCCEEDED/FAILED/PARTIAL/CANCELLED, its status cannot flip (IT-MONO-01 PASSED).

5. **Verification integrity** — the clean-room design with `clearVerifierArtifacts()` before each `verify()` prevents stale-file false positives (IT-FS-05 PASSED). Hash-match checks prevent empty-file false positives (IT-FS-02 PASSED). Wrong-path checks fail honestly (IT-FS-01, IT-FS-04 PASSED).

6. **Shutdown structured result** — the `ShutdownResult` honestly reports `clean: false` when close() throws (IT-04 PASSED) or when the deadline is exceeded (IT-07 demonstrates the deadline is aspirational, but the structured result still surfaces the issue when it eventually resolves).
