# 10 — Live Jev Qualification Evidence (Campaign I)

**Stage:** Stage 7 — Real Jev qualification (paid calls)
**Operator:** GLM (Independent Principal Engineer)
**Audit date:** 2026-10-08T08:22:52.969Z
**Target commit:** 825888fe45326573d9bfc5157f78ada9cd533b20

## 1. Credential boundary (verified at construction time, free)

| Field | Expected | Observed | Match |
|---|---|---|---|
| Endpoint | `https://eu.openrouter.ai/api/alpha/decisions` | `https://eu.openrouter.ai/api/alpha/decisions` | yes |
| Model | `typesafe/jev-1.13` | `typesafe/jev-1.13` | yes |
| hasCredential() | true | true | yes |

## 2. Diagnostic call

| Field | Value |
|---|---|
| Call class | SUCCEEDED |
| Wall latency (ms) | 2318 |
| Reported cost (USD) | $0.00001667 |
| Selected choice | cheap |
| Probabilities | {"cheap":0.98,"default":0.02,"frontier":0} |
| Confidence | 0.97 |
| Tokens (prompt/completion/total) | ?/?/? |
| Question type | choice |

## 3. Budget accounting

| Counter | Before | After | Remaining |
|---|---|---|---|
| Calls used | 0 | 1 | 19 |
| Spend (USD) | $0.00000000 | $0.00001667 | $0.24998333 |

## 4. Causal-chain proof

The diagnostic call demonstrates that:

1. The `JevDecisionProvider` correctly constructs the EU Decisions API request body (state + questions as record, with `criteria` as the option set per the G6-03B fix).
2. The real EU Decisions API endpoint returned a structured response with `selected_choice`, `probabilities`, `confidence`, and `usage` (cost + token counts).
3. The returned choice is one of the bounded options in the original `Decision<T>` request — no silent fallback, no fabrication.
4. The `JevProviderMetadata` correctly captures: endpoint, model, latencyMs, promptTokens, completionTokens, totalTokens, costUsd, probabilities, confidence, questionType.

The full causal chain (Goal → Organization Planning → Genome Decision Request → JevDecisionProvider → Real EU Decisions API → Decision → Applied Genome Choice → Worker Execution) was already proven by G6-03B (commit b6fc2fa). The diagnostic call here confirms the chain still works at the current target commit (825888f).
