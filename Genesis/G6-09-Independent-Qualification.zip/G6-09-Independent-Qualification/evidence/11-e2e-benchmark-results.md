# 11 — Realistic End-to-End Benchmark Results (Campaign K)

**Audit:** G6-09 Independent Adversarial Qualification
**Target commit:** `825888fe45326573d9bfc5157f78ada9cd533b20`
**Audit date:** 2026-10-08

## 1. Inspection scope

This evidence file covers Campaign K (realistic end-to-end benchmark). The G6-09 mandate (§17) specifies Tasks A–H:

| Task | Description | Requires |
|---|---|---|
| A | Build and verify a small functioning software component with tests | Real LLM reasoning + Real OpenBot runtime |
| B | Diagnose and repair a deliberately broken small repository | Real LLM reasoning + Real OpenBot runtime |
| C | Multi-source analysis (local documents with conflicting evidence) | Real LLM reasoning |
| D | Data processing (structured dataset with known expected outputs) | Real LLM reasoning + Real OpenBot runtime |
| E | Recovery (interrupt a mission during execution) | Real LLM reasoning + Real OpenBot runtime |
| F | Multi-worker coordination (two specialists produce complementary work) | Real LLM reasoning + Real OpenBot runtime |
| G | Impossible goal (cannot be completed with available tools) | Real LLM reasoning (to refuse gracefully) |
| H | Adversarial input (malicious instructions in untrusted local source material) | Real LLM reasoning |

## 2. Environment constraints

Per `docs/release/engine-v1-known-limitations.md` #11a:
> Live production-mode execution against real ZAI (LLM reasoning) and real OpenBot (worker runtime) is **not exercised** in the v1 release evidence. The sandbox in which v1 was verified does not have real ZAI credentials or a real OpenBot checkout, so:
> ```
> LIVE_PRODUCTION_EXECUTION   = BLOCKED_BY_ENVIRONMENT
> LIVE_REASONING_PROVIDER     = BLOCKED_BY_ENVIRONMENT (no ZAI_API_KEY in sandbox)
> LIVE_OPENBOT_EXECUTION      = BLOCKED_BY_ENVIRONMENT (no OpenBot checkout in sandbox)
> ```

The G6-09 audit inherited the same environment constraints:
- No real ZAI credentials (the OPENROUTER_API_KEY is authorized for Jev Decisions API only per Section 2.1, NOT for ZAI reasoning)
- No real OpenBot checkout (the `$GENESIS_OPENBOT_DIR` env var is not set)

## 3. What the audit DID run

The audit ran 4 controlled-stub scenarios that exercise the production code path (Gateway → MissionService → Orchestrator → Runtime → Verification → Artifact) without real external services:

1. **Stub-reasoning + stub-runtime mission** (independent test file `independent-adversarial.test.ts`) — verified:
   - Mission submission via MissionService.start() works
   - Mission reaches terminal state (FAILED/PARTIAL) when the stub reasoning throws
   - failureMessage is surfaced via the public API
   - The structured MissionSnapshot is correctly returned

2. **Verification-loop false-success prevention** (IT-FS-01..05) — verified:
   - Hash-match on wrong path fails honestly
   - Empty file does not match non-empty expected hash
   - Wrong artifact path fails honestly
   - Stale artifacts are cleared before each verify
   - File check without expectIncludes accepts empty (documented caveat)

3. **Cancellation and idempotency** (IT-CONC-01, IT-10, IT-MONO-01, IT-RESTART-01) — verified:
   - Same-caller idempotency under concurrent submission
   - Cross-caller idempotency-key rejection
   - Terminal-state monotonicity
   - No-durability contract across restart

4. **Live Jev integration** (Stage 7) — verified:
   - The JevDecisionProvider correctly constructs the EU Decisions API request
   - The real EU Decisions API returns a structured response
   - The returned choice is bounded to the requested options
   - The full JevProviderMetadata is correctly captured

## 4. What the audit did NOT run

Tasks A–H from Campaign K were NOT run because they all require real LLM reasoning (ZAI) or real OpenBot infrastructure, both of which are BLOCKED_BY_ENVIRONMENT in this audit sandbox.

This is the same limitation disclosed in `engine-v1-known-limitations.md` #11a. The audit confirms the limitation is honestly disclosed.

## 5. Per-task assessment

| Task | Audit verdict | Rationale |
|---|---|---|
| A — Build and verify | NOT_TESTED (BLOCKED_BY_ENVIRONMENT) | Requires real LLM + OpenBot |
| B — Diagnose and repair | NOT_TESTED (BLOCKED_BY_ENVIRONMENT) | Requires real LLM + OpenBot |
| C — Multi-source analysis | NOT_TESTED (BLOCKED_BY_ENVIRONMENT) | Requires real LLM |
| D — Data processing | NOT_TESTED (BLOCKED_BY_ENVIRONMENT) | Requires real LLM + OpenBot |
| E — Recovery | NOT_TESTED (PARTIAL) | The IT-MONO-01 + IT-RESTART-01 tests verify the contracts; live recovery NOT tested |
| F — Multi-worker coordination | NOT_TESTED (BLOCKED_BY_ENVIRONMENT) | Requires real LLM + OpenBot |
| G — Impossible goal | NOT_TESTED (BLOCKED_BY_ENVIRONMENT) | Requires real LLM (to refuse gracefully) |
| H — Adversarial input | NOT_TESTED (BLOCKED_BY_ENVIRONMENT) | Requires real LLM (to test prompt-injection resistance) |

## 6. Campaign K verdict

**REALISTIC_E2E = NOT_TESTED** (BLOCKED_BY_ENVIRONMENT)

This is NOT a failure of the engine — it is a limitation of the audit environment. The engine's controlled-stub positive path is verified (per `engine-v1-evidence-index.md` and the G6-08 Phase 2 evidence), but the autonomous-execution claim (a goal produces real-world work) is NOT independently verified by this audit.

Per the G6-09 mandate:
> If the system cannot perform these tasks without a real LLM provider, report the limitation instead of substituting GLM and claiming autonomous Genesis success.

This audit reports the limitation honestly. It does NOT substitute GLM reasoning for ZAI reasoning.

## 7. Recommended follow-up

Before any enterprise acceptance, the operator should run the E2E benchmark with:
1. Real ZAI credentials (ZAI_API_KEY set, GENESIS_REASONING_PROVIDER=zai)
2. Real OpenBot checkout (GENESIS_RUNTIME_PROVIDER=openbot, OPENBOT_CHECKOUT_DIR + OPENBOT_ROOT_DIR set)
3. Bounded budget for paid LLM calls
4. Independent validators for each task's expected output

The audit's verification-integrity findings (Campaign F: 5/5 false-success prevention tests PASS) provide confidence that the verification loop will correctly catch any failure modes the E2E benchmark surfaces.
