# G6-09 Independent Qualification + G6-09B Remediation — Evidence Package Manifest

**Audit date:** 2026-10-08
**Original target commit:** 825888fe45326573d9bfc5157f78ada9cd533b20
**Remediation commit:** 98adb8e7131dc2e5a1acea7120b9abc664f5a830
**Auditor:** GLM (Independent Principal Engineer)
**Post-remediation verdict:** CONDITIONAL_ACCEPT

## Top-level files

| File | SHA-256 | Bytes |
|---|---|---|
| 00-remediation-summary.md | ac68d37d1bfada9b18c20ba78dc69b3c5ce14a1882d53c99a5ee6ec952053990 | 9217 |
| 01-executive-verdict.md | eb44241c004726fde552c621b64be5abeb3cddd236720f6ce107e3764f71bd30 | 12093 |
| 02-claims-registry.json | 5cf04e0b71e6db620d17dd59e671c60438a7e42f77af923c8d26f4838330e3c6 | 38623 |
| 03-qualification-matrix.md | f2e321ae1596d1a786c3038dd442f3b4b2b240d39919b0862222a1a3bb4b1b80 | 6093 |
| 04-findings-register.json | 9ba99b13abad8b1718cdc9eb2ab3d470e328e3ecbe7260891b0c6e48f8137e99 | 8304 |
| 05-findings-detailed.md | 0d919560eeb3f9a12263c381f85d92b85fbc8a41888ad21817c5bc5df4d64281 | 14858 |
| 17-final-enterprise-acceptance-report.md | 4851ba7a5ea401ba79b67ca2956feb217e662eff514f05b7287486f352657e7e | 10311 |

## evidence/ directory

| File | SHA-256 | Bytes |
|---|---|---|
| 00-recovery-and-scope.md | cd37764d9c215224c8732ac660fb19e56b3bcd34163cedfd0a93370c49bd6169 | 3790 |
| 06-core-engine-evidence.md | 452546fa938f5fa0df45fa2a15d4c95fece2636e3e8612b6b2a0326c872f0bf2 | 9789 |
| 07-worker-runtime-evidence.md | 610962d754352a6846a3be6f4c53a59913651694f8f0b98d328826cbec54918a | 11062 |
| 08-security-evidence.md | 8d1830a0a07d5b8bc40fd318f944e2def1ccdd7bcc9ca3639b6d27100cc5ec3a | 9419 |
| 09-protocol-evidence.md | 734734118e434c122112215a304e748871c789a36a30a868097001ae9950701f | 6837 |
| 10-jev-live-evidence.md | bbb8a513a049e467d6d9045d7cb240c665e7ef011259c682529a72833ee1b60d | 2144 |
| 11-e2e-benchmark-results.md | d89f9ffcda89d4986c9dee0f9a4409fd143fb81d76833412a8dfe27833419bf1 | 6229 |
| 12-chaos-and-failure-injection.md | c26073b8fbd407882d8b940b03046ec26fae0bb71900434ddaed3aca186ac51d | 6897 |
| 13-reproducibility-and-ci.md | 8692b795b4118da61b9abb83f0b7b99e92a38e22b5c83671254548dc2a04e0a9 | 4174 |
| 14-architecture-assessment.md | 4e23f6add5845ee3a582596e4e43f811f8b0b132bb9673a2aeecf1e65c7391b9 | 47654 |
| 15-residual-risks.md | b85add1b787db2761da71a0fc2c568767958320d4dee2ad00c2149b3d4ff76d4 | 8627 |
| 16-recommended-remediation-order.md | e06fc7f374a369cc449fc381c02c7592ec57ba36999655f701d830a44a5316ec | 7043 |

## harness/ directory

| File | SHA-256 | Bytes |
|---|---|---|
| independent-adversarial-test-output.txt | 48fd1179d8fbc6d65cfeb2b39f7c7b53b4289aeec2e3219b84280eea0402e1bf | 706 |
| independent-adversarial.test.ts | 77818ebd34491867711349021b08244a8afea857415ce0fd90d554518136fcc3 | 22850 |
| jev-live-probe.ts | 831263d8d2026a4041ab680f04154795938030bdb2d591e9b4d95baeaa370702 | 12985 |
| post-fix-verification-test-output.txt | 89ae21aabfd5d1d3abe6b8c3cdf6e0b3e174221d9fef6b559e957e3e3ba9d8b7 | 396 |
| post-fix-verification.test.ts | 131855cac83654456b4c333f3dc62a51429644f58eca7cc1f60aea29203e3aa5 | 15155 |
| security-adversarial-test-output.txt | 08b08a93e5613e2caee4940d3134eb242b9f2fe83c91a9a7950321ad981af22e | 706 |
| security-adversarial.test.ts | 1eaa01c7bbf450ce9e4a08c78f9a0ac3467b5e5d1d3cbc4cf6e61cb7c772c1f1 | 10941 |
| stage-1-arch-claims.md | 5c10962b7f230103a89e0d16b590dcf7e6a63869ff7a48640db2a1ff284e0d98 | 36359 |
| stage-4-recon.md | 439bbaa061b18c2bfdac50902f88447d3007f00e53bd4967a9e981636f2161d3 | 44313 |
| stage-5-security-recon.md | 247d4badd9c8164ce81e4470359325e9fe44ac8fbd35704e7425c75c48cc4512 | 36575 |
| tier2-regression-test-output.txt | a7d7852770a9f7992f5a5ece1ad443f83eb96b38cbd419a1983097a433bbc845 | 484 |
| tier2-regression.test.ts | 5635ee9705daa6429bb685f7259a3a1c64414415fd005b6b621190b9e07bfdc4 | 22213 |

## patches/ directory

| File | SHA-256 | Bytes |
|---|---|---|
| g6-09b-remediation.patch | bf0a32db9eb9a1e7b0ee412f8ad72037689eae757ab1a9ff9d56c961f9a889e0 | 8488 |
