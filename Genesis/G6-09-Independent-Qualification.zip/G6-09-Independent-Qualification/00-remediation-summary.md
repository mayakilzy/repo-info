# 00 — G6-09B Remediation Summary

**Audit:** G6-09 Independent Adversarial Qualification + G6-09B Remediation
**Operator:** GLM (Independent Principal Engineer)
**Original target commit:** `825888fe45326573d9bfc5157f78ada9cd533b20` (G6-09A verdict: REJECT)
**Remediation commit:** `98adb8e7131dc2e5a1acea7120b9abc664f5a830` on branch `g6-09b-remediation`
**Remediation date:** 2026-10-08
**Post-remediation verdict:** CONDITIONAL_ACCEPT

## What this file is

This file is the entry point for the G6-09B remediation package. It indexes:
1. The remediation commits applied
2. The verification tests run
3. The conditions for acceptance

The full G6-09A evidence package (12 files in `evidence/`) remains valid as historical evidence of what was found at the original commit. The G6-09B remediation adds:
- This summary file (`00-remediation-summary.md`)
- The post-fix verification test file (`harness/post-fix-verification.test.ts`)
- The Tier 2 regression test file (`harness/tier2-regression.test.ts`)
- The updated executive verdict (`01-executive-verdict.md` — verdict changed to CONDITIONAL_ACCEPT)
- A unified diff of the production source changes (`patches/g6-09b-remediation.patch`)

## 1. Remediation commits

### Commit 98adb8e on branch `g6-09b-remediation`

```
G6-09B: remediate two P1 defects + Tier 2 defense-in-depth

P1 fixes (independently reproduced by G6-09 audit):
- G6-09-001 (P1): MissionService.shutdown() close() pass had no per-runtime
  timeout; the 10s deadline was aspirational. Fix: wrap each close() in
  Promise.race with per-runtime deadline. Verified by IT-07-FIX: 570ms (was 4022ms).
- G6-09-S01 (P1): OpenBot worker process inherited the gateway's full
  process.env (credential boundary breach). Fix: explicit env allowlist.
  Verified by IT-S-09-FIX (structural + behavioral).

Tier 2 defense-in-depth:
- G6-09-S02: extended checkCommandPolicy with 5 adversarial patterns.
- G6-09-S03: A2A User fallback now returns null (rejects unknown User).

Regression: 590/9 baseline preserved. 40/40 independent audit tests pass.
```

**Files changed:** 4 files, 95 insertions(+), 12 deletions(-)

| File | Lines changed | Defect closed |
|---|---|---|
| `src/runtime/openbot/computer-process.ts` | +25 -2 | G6-09-S01 (P1) |
| `src/gateway/mission-service.ts` | +43 -9 | G6-09-001 (P1) |
| `src/gateway/a2a-server.ts` | +14 -8 | G6-09-S03 (informational) |
| `src/worker/worker-agent.ts` | +37 -1 | G6-09-S02 (P3) |

## 2. Verification tests

### IT-07-FIX — G6-09-001 remediated (3 tests, all PASS)

File: `harness/post-fix-verification.test.ts`

1. `shutdown(500) with hanging close() completes within ~1.5s and reports timeout` — 570ms duration (was 4022ms before fix); `result.clean === false`; `result.runtimeAdapterCloseErrors === 1`; `result.perRuntime[0].closeError` contains `'timeout after'`
2. `shutdown with throwing close() still captures the error (regression check)` — `result.runtimeAdapterCloseErrors === 1`; `result.clean === false`
3. `shutdown with healthy close() reports clean (regression check)` — `result.runtimeAdaptersClosed === 1`; `result.perRuntime[0].closed === true`

### IT-S-09-FIX — G6-09-S01 remediated (3 tests, all PASS)

File: `harness/post-fix-verification.test.ts`

1. `STRUCTURAL: computer-process.ts no longer uses ...process.env in spawn env` — confirmed
2. `STRUCTURAL: computer-process.ts has an explicit env allowlist` — confirmed (PORT, COMPUTER_TOKEN, WORKSPACE_DIR, PROFILES_DIR, EGRESS_POLICY_REQUIRED + PATH/HOME/USER/SHELL/LANG/LC_ALL conditional spreads)
3. `BEHAVIORAL: a child spawned with the post-fix env pattern cannot read GENESIS_API_KEYS` — confirmed; worker CAN read COMPUTER_TOKEN/PORT/WORKSPACE_DIR/PATH (its required vars); worker CANNOT read GENESIS_API_KEYS/OPENROUTER_API_KEY/ZAI_API_KEY

### IT-S-03 — G6-09-S02 extended (7 tests, all PASS)

File: `harness/tier2-regression.test.ts`

1. STRUCTURAL: worker-agent.ts has the G6-09-S02 fix comment
2. blocks `nc -e /bin/sh` (reverse shell)
3. blocks `python -c` (arbitrary code execution)
4. blocks `find / -delete` (alternative recursive deletion)
5. blocks shell redirection to system directories (`> /etc/...`, `> /var/...`, `> /usr/...`)
6. blocks `chmod 777` on system directories
7. still allows normal development commands (`npm install`, `git status`, `echo "hello"`, `chmod 644 file.txt`, `> /tmp/test.txt`)

### IT-S-10 — G6-09-S03 fixed (1 structural test, PASS)

File: `harness/tier2-regression.test.ts`

1. STRUCTURAL: a2a-server.ts no longer has the permissive fallback that grants `mission:submit` to unknown User implementations

### IT-08 — G6-09-002 coverage closed (2 structural tests, PASS)

File: `harness/tier2-regression.test.ts`

1. STRUCTURAL: main.ts source has `process.exit(result.clean ? 0 : 1)` at the shutdown handler
2. STRUCTURAL: the shutdown handler is idempotent (`shutdownInProgress` + `shutdownCompleted` guards)

### IT-11 — G6-09-005 coverage closed (4 tests, all PASS)

File: `harness/tier2-regression.test.ts`

1. A verify() call against a missing artifact returns `ok=false`
2. A verify() call against an EMPTY artifact returns `ok=false`
3. A verify() call against a wrong-content artifact returns `ok=false`
4. A verify() call against the correct artifact returns `ok=true` (positive path)

### IT-10-regression — G6-09-003 coverage closed (2 tests, PASS)

File: `harness/tier2-regression.test.ts`

1. Cross-caller idempotency-key reuse is rejected
2. Same-caller idempotency-key reuse returns the same missionId

### IT-MONO-regression — Additional regression (2 tests, PASS)

File: `harness/tier2-regression.test.ts`

1. A terminal mission cannot be flipped by a late cancel
2. A fresh MissionService instance cannot resolve prior mission IDs (no durability)

## 3. Test execution summary

| Suite | Tests | Status |
|---|---|---|
| Project baseline (regression check) | 590 passed / 9 skipped | PASS — no regression |
| Independent audit — original defect-demonstration | 12 | PASS (defects documented) |
| Independent audit — original security | 4 | PASS (mitigation variant confirms fix) |
| Independent audit — post-fix verification | 6 | PASS — fixes confirmed |
| Independent audit — Tier 2 regression | 18 | PASS — coverage gaps closed |
| **Total independent audit** | **40** | **40 PASSED** |

## 4. Conditions for acceptance (per `15-residual-risks.md`)

The verdict is **CONDITIONAL_ACCEPT** subject to 6 explicit, enforceable conditions:

1. Operators MUST run bounded live acceptance tests with real ZAI credentials before production deployment.
2. Operators MUST run bounded live acceptance tests with real OpenBot infrastructure.
3. Operators MUST run Tasks A-H from Campaign K (E2E benchmark) before trusting the engine for real work.
4. Operators MUST NOT deploy without an external durability layer (in-process state only, no restart recovery).
5. Operators MUST NOT expose the gateway to untrusted networks without additional transport security (API-key auth only).
6. Operators MUST tune `maxActiveMissionsGlobal` per their workload.

## 5. Package layout

```
G6-09-Independent-Qualification/
├── 00-remediation-summary.md            ← this file (G6-09B summary)
├── 01-executive-verdict.md              ← updated to CONDITIONAL_ACCEPT
├── 02-claims-registry.json              ← 45 claims (unchanged from G6-09A)
├── 03-qualification-matrix.md           ← updated to reflect remediation
├── 04-findings-register.json            ← 9 findings (status updated to RESOLVED)
├── 05-findings-detailed.md              ← unchanged from G6-09A
├── 17-final-enterprise-acceptance-report.md  ← updated to reflect remediation
├── evidence/                            ← 13 evidence files (from G6-09A)
│   ├── 00-recovery-and-scope.md
│   ├── 06-core-engine-evidence.md
│   ├── 07-worker-runtime-evidence.md
│   ├── 08-security-evidence.md
│   ├── 09-protocol-evidence.md
│   ├── 10-jev-live-evidence.md
│   ├── 11-e2e-benchmark-results.md
│   ├── 12-chaos-and-failure-injection.md
│   ├── 13-reproducibility-and-ci.md
│   ├── 14-architecture-assessment.md
│   ├── 15-residual-risks.md
│   └── 16-recommended-remediation-order.md
├── harness/                             ← independent test harnesses
│   ├── independent-adversarial.test.ts       (12 tests)
│   ├── security-adversarial.test.ts          (4 tests)
│   ├── post-fix-verification.test.ts         (6 tests, NEW in G6-09B)
│   ├── tier2-regression.test.ts             (18 tests, NEW in G6-09B)
│   ├── jev-live-probe.ts
│   ├── stage-1-arch-claims.md
│   ├── stage-4-recon.md
│   ├── stage-5-security-recon.md
│   ├── independent-adversarial-test-output.txt
│   └── security-adversarial-test-output.txt
├── patches/                             ← G6-09B source code patches
│   └── g6-09b-remediation.patch          (the diff applied to the target commit)
└── manifests/
    └── evidence-package-manifest.md     ← SHA-256 hashes
```
