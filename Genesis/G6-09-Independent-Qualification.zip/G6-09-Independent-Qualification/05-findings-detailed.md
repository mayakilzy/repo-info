# 05 — Findings Detailed

**Audit:** G6-09 Independent Adversarial Qualification
**Target commit:** `825888fe45326573d9bfc5157f78ada9cd533b20`

This file is the narrative companion to `04-findings-register.json`. Each finding is expanded with code excerpts, reproduction evidence, and remediation details.

The findings are grouped by severity. Within each group, the most-actionable finding comes first.

---

## P1 — Critical release-qualification defects

### G6-09-001 — MissionService.shutdown() close() pass has no per-runtime timeout

**Severity:** P1 (Critical release-qualification defect)
**Confidence:** HIGH — independently reproduced
**Evidence class:** REPRODUCED_DEFECT
**Affected component:** `src/gateway/mission-service.ts:293-402` (especially 360-384)
**Reproduced by:** Independent test IT-07 in `harness/independent-adversarial.test.ts`

#### What the G6-08-R1 fix attempts

The G6-08-R1 commit (825888f) implements a structured `MissionService.shutdown(deadlineMs)` method to drain active missions and close runtime adapters. The shutdown handler in `main.ts:359-416` calls `service.shutdown(10_000)` (10-second deadline) and uses the structured `ShutdownResult` to set the OS exit code.

The per-mission drain pass (lines 320-357) correctly uses `Promise.race([runPromise, setTimeout(missionDeadline)])` so a single mission is bounded.

#### The defect

The safety-net pass at lines 360-384 calls `await rt.runtime.close()` for each unique runtime adapter, with NO per-runtime timeout:

```typescript
// mission-service.ts:368-374
if (typeof rt.runtime.close === 'function') {
  try {
    await rt.runtime.close();   // ← NO TIMEOUT — can hang indefinitely
    closed = true;
  } catch (e) {
    closeError = e instanceof Error ? e.message.slice(0, 200) : String(e).slice(0, 200);
  }
}
```

If `rt.runtime.close()` hangs (e.g., a stuck OpenBot process whose SIGKILL also fails), the gateway shutdown handler at `main.ts:379` will block on `await service.shutdown(10_000)` for much longer than 10 seconds. Node's SIGTERM handler is single-threaded; a second signal cannot interrupt the await.

#### Reproduction

Independent test IT-07 in `tests/independent-adversarial.test.ts`:

1. Constructed an `IndependentStubRuntime` with `closeBehavior='hang'` (close() returns a Promise that never resolves).
2. Submitted one active mission.
3. Called `service.shutdown(500)` (500 ms deadline requested).
4. Raced against a 4-second safety timeout.
5. **Observed:** shutdown did NOT complete within the 4-second safety race. The test asserted `elapsed > 1000` (well past the 500 ms bound) and `rt.closeCalled === true`. Test duration: **4022 ms** — the 500 ms deadline was NOT enforced.

#### Impact

- Operator's "10 s bound" on gateway shutdown is **aspirational, not enforced**.
- A stuck worker can hang the gateway shutdown indefinitely.
- The structured `ShutdownResult` surfaces the issue honestly (when it eventually resolves), but only AFTER the hang resolves.
- An operator's only recourse is to SIGKILL the gateway — losing any in-flight cleanup work.

#### Why this is P1

The defect blocks responsible enterprise acceptance because:
1. It defeats the documented shutdown contract (the structured `ShutdownResult.elapsedMs` will exceed `deadlineMs`).
2. It can leave the operator unable to gracefully restart the gateway.
3. In container orchestration environments (Kubernetes, etc.), a hung graceful-shutdown can prevent pod eviction, blocking deployments.

#### Recommended correction

Wrap each `await rt.runtime.close()` in a per-runtime timeout race:

```typescript
// Suggested fix (drop-in replacement for mission-service.ts:368-374):
if (typeof rt.runtime.close === 'function') {
  const perRuntimeDeadline = Math.min(2_000, Math.max(0, deadlineMs - (Date.now() - startedAt)));
  try {
    await Promise.race([
      rt.runtime.close(),
      new Promise<void>((resolve) => setTimeout(resolve, perRuntimeDeadline)),
    ]);
    // If we got here, close either resolved or timed out (we cannot distinguish
    // without a sentinel — the per-runtime result still reports closed=true
    // for the timeout case, but the operator can detect via elapsedMs).
    closed = true;
  } catch (e) {
    closeError = e instanceof Error ? e.message.slice(0, 200) : String(e).slice(0, 200);
  }
} else {
  closed = true;
}
```

Cost: ~15 lines of code change + 1 regression test (the existing IT-07 already proves the defect; the same test would prove the fix).

---

### G6-09-S01 — OpenBot worker process inherits the gateway's full process.env

**Severity:** P1 (Critical release-qualification defect)
**Confidence:** HIGH — independently reproduced
**Evidence class:** REPRODUCED_DEFECT
**Affected component:** `src/runtime/openbot/computer-process.ts:175-184`
**Reproduced by:** Independent test IT-S-09 in `harness/security-adversarial.test.ts`

#### The defect

The OpenBot worker process is spawned with the entire parent `process.env` spread, then specific worker env vars layered on top:

```typescript
// computer-process.ts:175-184
const child = spawn(config.bunPath ?? 'bun', ['src/index.ts'], {
  cwd: workingDir,
  env: {
    ...process.env,                    // ← INHERITS THE FULL PARENT ENV
    PORT: String(port),
    COMPUTER_TOKEN: token,
    WORKSPACE_DIR: workspaceDir,
    PROFILES_DIR: profilesDir,
    EGRESS_POLICY_REQUIRED: '0',
    ...config.extraEnv,
  },
  stdio: ['ignore', 'pipe', 'pipe'],
  detached: true,
}) as ChildProcess;
```

This means every env var in the gateway's `process.env` is propagated to the OpenBot worker process. In production, this includes:
- `GENESIS_API_KEYS` — the JSON map of API keys → caller configs (caller identities)
- `OPENROUTER_API_KEY` — the Jev credential (authorized EXCLUSIVELY for the EU Decisions API per Section 2.1)
- `ZAI_API_KEY` — the ZAI reasoning credential

A malicious or prompt-injected worker that runs shell commands (e.g., a software-engineering worker compromised by a malicious tool output) can simply execute `printenv` or `cat /proc/self/environ` and exfiltrate these secrets.

#### Reproduction

Independent test IT-S-09 in `tests/security-adversarial.test.ts`:

1. Set `process.env.GENESIS_API_KEYS = '{"test-key":{"callerId":"caller-x"}}'` (fake test value).
2. Set `process.env.OPENROUTER_API_KEY = 'sk-or-v1-FAKE_TEST_KEY_FOR_AUDIT_DEMO_ONLY'`.
3. Spawn a stub child process (a small Node script that prints its env) using the same `env: { ...process.env, ... }` pattern.
4. **Observed:** the child's printed env contained both `GENESIS_API_KEYS` and `OPENROUTER_API_KEY` — DEFECT CONFIRMED.

A second test verified the mitigation: with an explicit env allowlist (`env: { PORT, COMPUTER_TOKEN, WORKSPACE_DIR, PROFILES_DIR, EGRESS_POLICY_REQUIRED, PATH, HOME, ...config.extraEnv }`), the child CANNOT read the gateway's secrets. The fix is therefore minimal and proven.

#### Impact

- **CREDENTIAL BOUNDARY BREACH in production mode.**
- The OpenRouter key (authorized for Jev Decisions API only per Section 2.1) becomes accessible to any worker — which could then use it for chat completions, directly violating the credential boundary.
- The `GENESIS_API_KEYS` JSON map (caller identities) is also exposed — a malicious worker could enumerate valid caller IDs and use them for confused-deputy attacks.
- The `ZAI_API_KEY` is exposed — a worker could make unauthorized ZAI reasoning calls.

#### Why this is P1

The defect blocks responsible enterprise acceptance because:
1. It is a credential boundary breach — the Jev credential boundary is a non-negotiable hard constraint per the G6-09 mandate Section 2.1.
2. It is exploitable in production mode (the default for any operator deploying to real infrastructure).
3. The exploit does NOT require any unusual worker behavior — any software-engineering mission that runs shell commands is exposed.
4. The defect is in the OpenBot adapter, which is the canonical production runtime per `engine-v1-scope.md`.

#### Recommended correction

Replace the env-spread pattern with an explicit allowlist:

```typescript
// Suggested fix (drop-in replacement for computer-process.ts:175-184):
const child = spawn(config.bunPath ?? 'bun', ['src/index.ts'], {
  cwd: workingDir,
  env: {
    // Explicit allowlist — gateway secrets are NOT propagated.
    PORT: String(port),
    COMPUTER_TOKEN: token,
    WORKSPACE_DIR: workspaceDir,
    PROFILES_DIR: profilesDir,
    EGRESS_POLICY_REQUIRED: '0',
    PATH: process.env.PATH,
    HOME: process.env.HOME,
    ...config.extraEnv,
  },
  stdio: ['ignore', 'pipe', 'pipe'],
  detached: true,
}) as ChildProcess;
```

Cost: ~10 lines of code change + 1 regression test (the existing IT-S-09 already proves the defect and the mitigation).

---

## P2 — Major functional defects (coverage gaps)

### G6-09-002 — Exit-code-1 path at main.ts:407,411 is never exercised by any test

**Severity:** P2
**Confidence:** HIGH
**Evidence class:** CODE_CONFIRMED_DEFECT (test-coverage gap)

The G6-08-R1 shutdown handler at `main.ts:407` does `process.exit(result.clean ? 0 : 1)` and at `main.ts:411` does `process.exit(1)` in the catch block. Both branches are correct by inspection but NEVER exercised by any test in the G6-08-R1 suite.

The G6-08-R1 `shutdown-lifecycle.test.ts` SHUTDOWN-10 only asserts the CLEAN path → exit 0. SHUTDOWN-05 produces `clean=false` but does NOT compute or assert `exitCode=1`.

This is a test-coverage gap, not a behavior defect. The code is correct; the verification is missing.

**Recommended correction:** Add a subprocess-level test that spawns the gateway, forces an unclean shutdown (e.g., via a stub runtime whose `close()` throws), and asserts the actual OS process exit code is 1.

---

### G6-09-005 — Per-phase cancellation coverage missing the verification phase

**Severity:** P2
**Confidence:** MEDIUM
**Evidence class:** EVIDENCE_GAP

The G6-09 mandate (§11, Campaign E) requires testing cancellation at every phase: before start, during reasoning, during tool execution, during verification, during completion.

The existing `tests/mission/cancellation.test.ts` covers:
- CANCEL-01: during reasoning ✓
- CANCEL-03: repeated cancellation ✓
- CANCEL-04: post-terminal idempotency ✓

But does NOT cover:
- Cancel BEFORE orchestrator.run() starts
- Cancel DURING tool exec (writeFile in flight)
- Cancel DURING verification loop
- Cancel DURING completion/finalization

The verification-phase cancel is the most dangerous case: if the abort signal does not propagate to the verification loop, a half-verified mission could be wrongly reported as SUCCEEDED.

**Recommended correction:** Add a phase-aware reasoning stub (pause at each phase until released) and 5 sub-tests, one per phase. Each sub-test asserts the final status is CANCELLED or PARTIAL, NOT SUCCEEDED. Cost: ~100 lines of test code.

---

## P3 — Material defects with bounded impact

### G6-09-003 — Cross-caller idempotency-key rejection not covered by G6-08-R1 tests

**Severity:** P3 (test-coverage gap)
**Confidence:** HIGH
**Evidence class:** POSITIVE_CONFIRMATION (with coverage gap noted)

The production code at `mission-service.ts:500-511` correctly rejects cross-caller idempotency-key reuse. Independent test IT-10 confirmed the behavior: Caller B's submission threw `MissionAdmissionError('idempotency key already in use by another caller')`.

F-RECON-006 was a TEST COVERAGE GAP, not a behavior defect. The G6-08-R1 suite should add this case for regression protection.

---

### G6-09-006 — 2s SIGKILL escalation for SIGTERM-ignoring workers is dead code from a test perspective

**Severity:** P3 (test-coverage gap)
**Confidence:** HIGH
**Evidence class:** EVIDENCE_GAP

`computer-process.ts:265-275` implements the SIGTERM→SIGKILL-after-2s fallback (docker-stop semantics). No test exercises this path.

The code path is correct by inspection but untested. If the SIGKILL escalation has a bug (e.g., kills the wrong process group), it would not be caught by tests.

**Recommended correction:** Add an adversarial test using a `FakeChildProcess` that ignores SIGTERM and asserts SIGKILL fires after 2s. Cost: ~80 lines.

---

### G6-09-S02 — Genesis-layer command policy blocks 7 patterns but allows common adversarial commands

**Severity:** P3 (defense-in-depth gap)
**Confidence:** MEDIUM
**Evidence class:** HIGH_CONFIDENCE_RISK

The `checkCommandPolicy` function at `src/worker/worker-agent.ts:280-310` blocks:
- `rm -rf /` (and variants)
- `rm -rf ~` or `$HOME`
- `mkfs`
- `dd of=/dev/...`
- `shutdown / reboot / halt / poweroff`
- `curl ... | sh / wget ... | sh`
- `chmod 777`

But does NOT block:
- `nc -e /bin/sh` (reverse shell)
- `python -c '...'` (arbitrary Python code execution)
- `find / -delete` (alternative recursive deletion)
- `dd of=/tmp/x` (writes outside /dev/ but could be exfiltration)
- `> /etc/passwd` (overwrite system file)

The policy comment says it's "intentionally permissive for normal development work" — defense-in-depth relies on the OpenBot adapter's egress filter as the primary defense.

**Recommended correction:** Add at minimum: `nc -e`, `python -c`, `find / -delete`, `> /etc/`, `chmod 777 /`. Each is a one-line regex addition. Cost: ~5-7 lines of code change.

---

## Informational findings

### G6-09-004 — MemoryRuntime does not implement close(); safety net is a no-op in dev mode

**Severity:** informational
**Confidence:** HIGH
**Evidence class:** POSITIVE_CONFIRMATION

`MemoryRuntime` does NOT implement `close()`. The optional `close?()` method on `WorkerRuntime` is absent. The `MissionService.shutdown()` safety net (mission-service.ts:368) correctly handles the case where close is absent (sets `closed=true` without calling).

By design — `MemoryRuntime` is in-process and holds no external resources. The production `OpenBotRuntimeAdapter` MUST implement `close()` — the safety net depends on it.

No remediation needed. Verified by IT-13.

---

### G6-09-S03 — A2A User fallback grants mission:submit to any SDK User with isAuthenticated=true

**Severity:** informational
**Confidence:** MEDIUM
**Evidence class:** HIGH_CONFIDENCE_RISK (defense-in-depth)

`src/gateway/a2a-server.ts:517-532` extracts a CallerIdentity from a User object. If the User is NOT an AuthenticatedGatewayUser (e.g., from a custom A2A SDK User implementation), the fallback grants `mission:submit` permission with 5 max active missions.

In practice, the `authenticateA2A` function populates the User — so all User objects should be AuthenticatedGatewayUser. The fallback is a defense-in-depth concern, not an actual exploitable vulnerability.

**Recommended correction:** Change the fallback to return null (reject unknown User implementations) instead of constructing a permissive CallerIdentity. Cost: ~3 lines.
