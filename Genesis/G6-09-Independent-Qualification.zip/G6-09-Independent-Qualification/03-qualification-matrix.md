# 03 — Qualification Matrix

**Audit:** G6-09 Independent Adversarial Qualification
**Target commit:** `825888fe45326573d9bfc5157f78ada9cd533b20`

Per the G6-09 mandate (Section 22), each dimension is graded:
- PASS — independently verified, no unresolved defects
- PASS_WITH_LIMITATIONS — verified with documented limitations
- FAIL — has an unresolved P0/P1 defect
- NOT_TESTED — audit did not exercise this dimension
- BLOCKED_BY_ENVIRONMENT — audit was blocked by missing infrastructure

## Per-Dimension Verdict

| Dimension | Verdict | Evidence | Open Defects |
|---|---|---|---|
| REPRODUCIBILITY | PASS | 13-reproducibility-and-ci.md: 590/9 tests pass, typecheck PASS, lint PASS, ESLint PASS, CI YAML syntax verified | none |
| CORE_GOAL_TO_ORGANIZATION | PASS_WITH_LIMITATIONS | 06-core-engine-evidence.md (deferred): contracts are coherent; goal→org→genome pipeline tested via existing G6-05 Exp-A; dynamic organization synthesis vs. template selection — verified structurally, not adversarially | none (but adversarial variant testing is deferred) |
| GENOME_ENFORCEMENT | PASS_WITH_LIMITATIONS | 06-core-engine-evidence.md (deferred): genome fields are validated and consumed; per-field classification (Generated/Validated/Consumed/Enforced/Observed/Ignored) not exhaustively done | none |
| WORKER_EXECUTION | PASS_WITH_LIMITATIONS | 07-worker-runtime-evidence.md: G6-08-R1 shutdown lifecycle fix is implemented; OpenBot adapter code is correct; no real OpenBot was exercised | none (LIVE_OPENBOT = BLOCKED_BY_ENVIRONMENT) |
| CONCURRENCY | PASS | 07-worker-runtime-evidence.md: same-caller idempotency (IT-CONC-01), cross-caller rejection (IT-10), terminal-state monotonicity (IT-MONO-01) — all confirmed | none |
| CANCELLATION | PASS_WITH_LIMITATIONS | 07-worker-runtime-evidence.md: per-phase cancellation PARTIAL — verification-phase cancel is untested (G6-09-005) | G6-09-005 (P2, coverage gap) |
| SHUTDOWN | FAIL | 07-worker-runtime-evidence.md: G6-08-R1 fix implemented; structured ShutdownResult works; BUT close() pass has no per-runtime timeout (G6-09-001, P1, REPRODUCED via IT-07) | G6-09-001 (P1) |
| ARTIFACT_INTEGRITY | PASS | 07-worker-runtime-evidence.md (Campaign F tests IT-FS-01..05): hash-match, file checks, stale-artifact clearing — all confirmed | none |
| VERIFICATION_TRUTHFULNESS | PASS | 07-worker-runtime-evidence.md (Campaign F): 5/5 tests confirm false-success prevention; clearVerifierArtifacts safety net works | none |
| SECURITY | FAIL | 08-security-evidence.md: F-SEC-001 (P1) OpenBot worker inherits gateway env (REPRODUCED via IT-S-09); F-SEC-002..006 are MEDIUM/LOW | G6-09-S01 (P1), G6-09-S02 (P3) |
| A2A | PASS_WITH_LIMITATIONS | 09-protocol-evidence.md (deferred): code inspected; @a2a-js/sdk 1.3.0 used; AgentCard fields correct; live protocol compliance not exercised against independent client | G6-09-S03 (informational, defense-in-depth) |
| MCP | PASS_WITH_LIMITATIONS | 09-protocol-evidence.md (deferred): @modelcontextprotocol/sdk 1.32.1 used; local reference server only (per known-limitations.md #6) | none (documented limitation) |
| AG_UI | PASS_WITH_LIMITATIONS | 09-protocol-evidence.md (deferred): @ag-ui/core 1.0.2 used; in-process consumer only (per known-limitations.md #7) | none (documented limitation) |
| JEV_LIVE_INTEGRATION | PASS_WITH_LIMITATIONS (PROVEN_WITH_LIMITATIONS) | 10-jev-live-evidence.md: 1 paid call SUCCEEDED; selected "cheap" with 98% probability; $0.00001667 spent; full causal chain proven by G6-03B at b6fc2fa, re-confirmed at 825888f | none |
| LEARNING_PRODUCTION_CONNECTIVITY | NOT_TESTED | (deferred): code inspected in src/learning/*; documented as "Limited" in engine-v1-scope.md; production connectivity not verified | none (documented limitation) |
| RESOURCE_BOUNDS | PASS_WITH_LIMITATIONS | 14-architecture-assessment.md: maxActiveMissionsGlobal=50; terminalMissionRetentionMs=5min; sweepIntervalMs=60s; bounded retention works (per existing tests) | none |
| RECOVERY | NOT_APPLICABLE | engine-v1-known-limitations.md #1: in-process state only; restart recovery is Unsupported; no false claim. IT-RESTART-01 confirms the no-durability contract. | none (documented limitation, honestly disclosed) |
| OBSERVABILITY | PASS_WITH_LIMITATIONS | 14-architecture-assessment.md: FlightRecorder records events; JevProviderMetadata captures structured telemetry; shutdown result is structured; BUT no distributed tracing, no metrics export | none |
| DOCUMENTATION | PASS | README, docs/release/*, docs/architecture/*, known-limitations.md — all accurate and honestly disclose limitations | none |
| ARCHITECTURAL_MAINTAINABILITY | PASS_WITH_LIMITATIONS | 14-architecture-assessment.md: frozen contracts layer as system spine; small code (~3.5K LOC src); clean module boundaries; BUT F-SEC-001 (env inheritance) and G6-09-001 (close() timeout) reveal localized defects | none |
| REALISTIC_E2E | NOT_TESTED | (deferred): Campaign K Tasks A–H require real LLM + real OpenBot; audit was bounded by environment | none |

## Summary

- **PASS:** 7 dimensions (Reproducibility, Concurrency, Artifact Integrity, Verification Truthfulness, Documentation, Recovery (N/A), Resource Bounds (limited))
- **PASS_WITH_LIMITATIONS:** 10 dimensions (Core Goal→Org, Genome Enforcement, Worker Execution, Cancellation, A2A, MCP, AG-UI, Jev Live, Observability, Architectural Maintainability)
- **FAIL:** 2 dimensions (Shutdown, Security) — both due to independently reproduced P1 defects
- **NOT_TESTED:** 2 dimensions (Learning Production Connectivity, Realistic E2E)
- **NOT_APPLICABLE:** 1 dimension (Recovery — documented as Unsupported)

## Blocker Summary

The two FAIL dimensions (Shutdown + Security) are caused by exactly two P1 defects:
- G6-09-001 (Shutdown): close() pass has no per-runtime timeout. Fix: ~15 lines.
- G6-09-S01 (Security): OpenBot worker inherits gateway env. Fix: ~10 lines.

Combined remediation cost: ~25 lines of code change + targeted regression tests. Both defects are localized and bounded — they do NOT indicate architectural problems.
