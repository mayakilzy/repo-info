# Stage 4 Reconnaissance — G6-08-R1 Shutdown Lifecycle Test Coverage Audit

**Task ID:** stage-4-recon
**Agent:** general-purpose (Independent Test Engineer)
**Target commit:** 825888fe45326573d9bfc5157f78ada9cd533b20
**Date:** 2026-01 (audit session)
**Scope:** READ-ONLY reconnaissance of the G6-08-R1 fix for B-EXEC-FINDING-003 (graceful worker teardown on shutdown) and identification of adversarial gaps for Campaign D (§10) and Campaign E (§11).

All file paths below are relative to the worktree root
`/home/z/my-project/genesis-audit/worktree/genesis/`.

---

## 1. Shutdown Handler Control Flow (`src/gateway/main.ts`)

The shutdown path lives in the top-level `main()` async function. Two closure-scoped
booleans guard idempotency:

| Step | main.ts line(s) | What happens |
|------|------------------|--------------|
| (a) Declare guards | 364–365 | `let shutdownInProgress = false; let shutdownCompleted = false;` |
| (b) Define `shutdown(signal)` async fn | 366 | `const shutdown = async (signal: string): Promise<void> => {` |
| (c) Idempotency guard #1 | 367 | `if (shutdownCompleted) return;` — already torn down, do nothing |
| (d) Idempotency guard #2 | 368 | `if (shutdownInProgress) return;` — deduplicate concurrent SIGTERM/SIGINT (NOTE: returns silently, does NOT await the in-flight shutdown) |
| (e) Mark in-progress | 369 | `shutdownInProgress = true;` |
| (f) Log the signal | 370 | `console.error('[genesis-gateway] received ${signal}, ...')` |
| (g) Stop accepting connections (synchronous) | 372–373 | `http.server.close(); a2a.server.close();` — these mark the servers as closing but do NOT await in-flight socket drains |
| (h) Invoke service shutdown with 10s bound | 379 | `const result = await service.shutdown(10_000);` — single overall deadline; service internally caps per-mission to `min(deadlineMs, 5_000)` |
| (i) Log summary line | 380–386 | drained/timedOut/closed/closeErrors + elapsedMs |
| (j) Warn if missions timed out | 387–394 | iterates `result.perMission`, logs each `timedOut` mission's id + final status |
| (k) Warn if runtimes had close errors | 395–402 | iterates `result.perRuntime`, logs each `closeError` |
| (l) Mark completed | 403 | `shutdownCompleted = true;` |
| (m) Exit with `result.clean ? 0 : 1` | 407 | `process.exit(result.clean ? 0 : 1);` — exit code reflects cleanup outcome |
| (n) Catch unexpected throw | 408–412 | `console.error('shutdown threw: ...'); shutdownCompleted = true; process.exit(1);` |
| (o) Register signal handlers | 414–415 | `process.on('SIGTERM', () => { void shutdown('SIGTERM'); }); process.on('SIGINT', () => { void shutdown('SIGINT'); });` |

**Observations on the control flow (preliminary findings, see §6):**
- The 10 000 ms deadline is a single overall budget. If the first mission's 5 s
  per-mission cap is consumed, the second mission's per-mission deadline is
  `min(deadlineMs - elapsed, 5_000)` — which can be much shorter than 5 s. There is
  no minimum floor (e.g., 1 s) per mission.
- `http.server.close()` / `a2a.server.close()` are synchronous markers — they do
  not await in-flight HTTP request bodies. A long-running in-flight request can
  still be processing during shutdown.
- The idempotency guard at line 368 returns silently without awaiting the
  in-flight shutdown. This is acceptable for signal handling (Node delivers the
  signals one at a time on the main thread) but means a SIGINT received mid-shutdown
  cannot be observed.

---

## 2. MissionService.shutdown() Implementation (`src/gateway/mission-service.ts:293`)

**Signature & return type** (lines 173–212):

```ts
async shutdown(deadlineMs: number = 10_000): Promise<ShutdownResult>
```

`ShutdownResult` (lines 179–196):
```
{
  clean: boolean;             // true iff totalTimedOut === 0 && totalCloseErrors === 0
  elapsedMs: number;
  activeMissionsDrained: number;
  activeMissionsTimedOut: number;
  runtimeAdaptersClosed: number;
  runtimeAdapterCloseErrors: number;
  perMission: ShutdownMissionResult[];   // { missionId, callerId, drained, timedOut, finalStatus, cleanupError? }
  perRuntime: ShutdownRuntimeResult[];    // { missionId, runtimeName, closed, closeError? }
}
```

**What it iterates (both, in two passes):**

1. **Pass A — active missions** (lines 302–357): iterates `this.missions` Map,
   filtering out terminal missions. For each active mission:
   - sets `rt.canceled = true`
   - sets `rt.status = 'CANCELLATION_REQUESTED'`
   - calls `rt.controller.abort()` (best-effort, try/catch)
2. **Pass B — per-mission drain** (lines 318–357): for each active mission,
   `Promise.race`s `rt.runPromise` against a setTimeout of `missionDeadline`
   (capped at `min(deadlineMs, 5_000)` and further reduced by elapsed time).
   - On resolve: drained iff `isTerminal(rt.status)` else timedOut.
   - On reject (runPromise threw): `cleanupError` captured (truncated 200 chars);
     `drained = isTerminal(rt.status)` (i.e., the orchestrator's finally still ran
     and set a terminal status).
   - If `rt.runPromise === undefined`: marks mission CANCELLED, drained=true
     (mission was accepted but orchestrator never started — defensive path).
3. **Pass C — runtime.close() safety net** (lines 360–384): iterates
   `this.missions` again (NOT just active ones), deduplicating by runtime instance
   via a `seenRuntimes` Set. For each unique runtime:
   - If `typeof rt.runtime.close === 'function'`: await it, set `closed=true`;
     on throw, capture `closeError` (truncated 200 chars), `closed=false`.
   - Else: `closed=true` (no close method = no-op success — MemoryRuntime does
     not implement close()).

**How it cancels:** via the same `AbortController` that `cancel()` uses —
`rt.controller.abort()`. The orchestrator's `onExternalAbort` listener (orchestrator
line 371–374) calls its internal controller's abort, which propagates to the
worker-agent's signal-aborted check (`src/worker/worker-agent.ts:796`).

**How it waits:** `Promise.race(runPromise, setTimeout(missionDeadline))`. The
overall `deadlineMs` is enforced only by the per-mission budget reductions — there
is NO global `setTimeout` race wrapping the entire `shutdown()` call. If pass C
(`runtime.close()`) hangs, the gateway's shutdown handler will block indefinitely
on `await service.shutdown()` — Node's SIGTERM handler cannot be re-entered to
escalate. (Preliminary finding F-RECON-001.)

**What `clean` is set to (line 393):**
```ts
clean: totalTimedOut === 0 && totalCloseErrors === 0
```
Note: `activeMissionsDrained` is NOT part of the `clean` predicate — only
"didn't time out" and "no close errors" matter. A mission whose `runPromise`
rejected (cleanupError captured) but reached a terminal status still counts as
`drained=true` and does NOT make `clean=false`.

---

## 3. New Shutdown-Lifecycle Test Coverage (`tests/g6-08-r1/shutdown-lifecycle.test.ts`, 434 lines)

| # | Test name | Lines | 1-line summary | Adversarial cases covered |
|---|-----------|-------|-----------------|----------------------------|
| 1 | SHUTDOWN-01: two active missions receiving shutdown → both workers cleaned up via runtime.close() | 173–209 | Submits 2 missions (in-process stub runtimes), shutdown(6 000), asserts drained=2, closeCalled on both runtimes, unstoppedWorkerCount=0. | Partial #1 (no real process groups — both are in-process ControlledStubRuntime), #10 (clean exit). |
| 2 | SHUTDOWN-02: cancellation racing with natural completion — already-terminal missions are not re-cancelled | 211–230 | Mission completes naturally; shutdown(2 000) returns drained=0, clean=true; runtime.close() still called as safety net. | Partial #13 (cancel after completion — but via shutdown, not cancel()). |
| 3 | SHUTDOWN-03: repeated shutdown() calls are idempotent | 232–254 | 3 concurrent `service.shutdown(5_000)` Promise.all; all return clean=true. | Partial #7 (only tests concurrent service.shutdown(), NOT real SIGTERM/SIGINT signals). |
| 4 | SHUTDOWN-04: worker cleanup failure (stopWorker throws) is handled by close() safety net | 256–273 | `stopWorkerThrowOn='sole-operator-1'`; shutdown(5 000); asserts drained=1, clean=true, unstoppedWorkerCount=0. | Partial #5 (only stopWorker throws, NOT close() itself throwing — case #5 explicitly says "worker failing close()"). |
| 5 | SHUTDOWN-05: bounded timeout — mission that never terminates is reported as timedOut | 275–292 | stopWorkerDelayMs=10_000, deadline=500ms; asserts timedOut=1, clean=false, closeCalled=true. | Partial #8 (deadline expiration — but uses 500ms, not the actual 10s bound). |
| 6 | SHUTDOWN-06: shutdown rejects new mission submissions (start() throws) | 294–310 | After shutdown() begins (not awaited), `service.start(...)` throws `/shutting down/`. | (Extra — not in the 16 case list.) |
| 7 | SHUTDOWN-07: cross-mission isolation — Mission A workers are not affected by Mission B runtime | 312–336 | Two missions × two stub runtimes; both closeCalled, both unstopped=0. | Partial #1 (no real process groups). |
| 8 | SHUTDOWN-08: shutdown result reports per-mission and per-runtime breakdown | 338–366 | Asserts `perMission.length=2`, `perRuntime.length=2`, runtimeNames contain 'runtime-A'/'runtime-B', every perRuntime.closed=true. | (Coverage of structured result, not adversarial case.) |
| 9 | SHUTDOWN-09: no unrelated process termination — runtimes NOT in the service are untouched | 368–383 | RuntimeInService.closeCalled=true; runtimeNotInService.closeCalled=false. | YES #10 (no unrelated process termination — for the in-process case). |
| 10 | SHUTDOWN-10: process-level shutdown with independently tracked detached worker (gateway SIGTERM path) | 385–407 | Simulates gateway shutdown path; `exitCode = result.clean ? 0 : 1`; asserts exitCode=0 and unstoppedWorkerCount=0. Has a debug `console.error` if not clean. | Partial #9 (only the CLEAN path is asserted; the non-clean → exit 1 path is NOT exercised). |
| 11 | SHUTDOWN-11: shutdown with no active missions is clean and fast | 409–421 | No missions submitted; shutdown(2 000) returns drained=0, clean=true, elapsedMs<500. | (Coverage of the trivial path.) |
| 12 | SHUTDOWN-12: controlled-process evidence is explicitly distinguished from live OpenBot | 423–433 | Documentation test asserting `LIVE_OPENBOT_TEST='BLOCKED_BY_ENVIRONMENT'` and `CONTROLLED_PROCESS_EVIDENCE='PASS'`. | (Honest-evidence marker.) |

---

## 4. Coverage Matrix — 16 Adversarial Cases (§10 Campaign D + §11 Campaign E)

| # | Adversarial case | Covered? | Which test/line | Gap notes |
|---|------------------|----------|-----------------|-----------|
| 1 | Two active missions with two independent **worker process groups** | **PARTIAL** | shutdown-lifecycle.test.ts SHUTDOWN-01 (173–209), SHUTDOWN-07 (312–336), SHUTDOWN-08 (338–366) | All three use in-process `ControlledStubRuntime` instances — there are NO real OS process groups. The mandate specifically calls out "worker process groups" (plural) — the `detached: true` spawn logic in computer-process.ts:193 is NEVER exercised by any of these tests. No test asserts that Mission A's `process.kill(-pgid, SIGTERM)` does not reach Mission B's pgid. |
| 2 | SIGTERM **during** active execution | **PARTIAL** | clean-room-gateway.test.ts GATEWAY-04 (240–315) SIGTERMs a gateway with NO active missions (dev-mode, idle). shutdown-lifecycle SHUTDOWN-01 SIGTERMs the service.shutdown() while missions run, but does not deliver an actual SIGTERM signal to the process. | No test delivers a real SIGTERM to a gateway that has actively-running missions and asserts the missions drain and the process exits 0. |
| 3 | Cancellation **during cleanup** | **NO** | — | No test fires `service.cancel()` (or a second `service.shutdown()`) WHILE the first `service.shutdown()` is mid-drain. mission-service.ts:294 sets `shuttingDown=true` synchronously before iteration begins, so `service.cancel()` racing with shutdown would hit `requireMission` while the registry is being mutated — undefined behavior. |
| 4 | A worker **ignoring SIGTERM** | **NO** | — | computer-process.ts:265–275 implements the SIGTERM→SIGKILL-after-2s fallback (docker-stop semantics). No test asserts that the 2s SIGKILL escalation fires for a worker that ignores SIGTERM. ControlledStubRuntime cannot simulate this (no real process). |
| 5 | A worker **failing close()** | **PARTIAL** | shutdown-lifecycle SHUTDOWN-04 (256–273) | SHUTDOWN-04 makes `stopWorker` throw, then asserts close() (the safety net) succeeds. But the mandate case #5 is the inverse: close() itself throws. mission-service.ts:368–374 does capture `closeError` and sets `closed=false`, but NO test exercises this branch (no test configures a runtime whose `close()` rejects). |
| 6 | A worker **already exited** | **NO** | — | No test asserts that stopWorker() on an already-exited worker is a no-op (the OpenBot adapter's stopWorker:166–177 returns silently if `!running`, but the orchestrator finally:860–867 catches throws — neither path is asserted for the "already exited" race). |
| 7 | **Repeated shutdown signals** (SIGTERM twice, SIGTERM+SIGINT) | **PARTIAL** | shutdown-lifecycle SHUTDOWN-03 (232–254) | Only tests concurrent `service.shutdown()` (3×). Does NOT test the real signal handler path: (a) SIGTERM delivered twice in quick succession; (b) SIGTERM then SIGINT mid-shutdown; (c) whether `shutdownInProgress` guard at main.ts:368 prevents process.exit being skipped if the second signal arrives between `await service.shutdown` returning and `process.exit` being called. |
| 8 | **Deadline expiration** (worker that doesn't drain within 10 s) | **PARTIAL** | shutdown-lifecycle SHUTDOWN-05 (275–292) | Uses 500 ms deadline, not the actual 10 000 ms bound from main.ts:379. Does not test the scenario where stopWorker takes 11 s (just past the 10 s bound) — which would prove the global 10 s deadline is enforced (it isn't — see F-RECON-001). |
| 9 | **Process exit status** correctness (0 if clean, 1 if not) | **PARTIAL** | shutdown-lifecycle SHUTDOWN-10 (385–407) | Only asserts the CLEAN path → exit 0. SHUTDOWN-05 has `clean=false` but does NOT compute/verify exitCode=1. main.ts:407 (`process.exit(result.clean ? 0 : 1)`) and main.ts:411 (`process.exit(1)` in the catch) are NEVER exercised by any test. |
| 10 | **No unrelated process termination** | **YES** | shutdown-lifecycle SHUTDOWN-09 (368–383) | Asserts runtimeNotInService.closeCalled=false. (But only for in-process runtimes — does not verify a separate MissionService instance's spawned child processes are untouched.) |
| 11 | **Simultaneous mission submission** | **PARTIAL** | rb2-concurrent-isolation.test.ts RB2-01 (115–176); concurrent-a2a.test.ts CONCURRENT-01 (150–163) | RB2-01 uses `Promise.all([startA, startB])` with controlled stub runtime — confirms distinct missionId and distinct runtime instance, but NOT real process groups. CONCURRENT-01 covers simultaneous A2A submission from two callers. Neither verifies two real OpenBot workers spawned simultaneously do not race on shared filesystem workspace dirs. |
| 12 | **Identical idempotency keys** (different callers using same key) | **NO** | — | mission-service.ts:500–511 rejects with `MissionAdmissionError('idempotency key already in use by another caller')`, but NO TEST exercises this branch. http-api.test.ts API-11 (137–156) tests SAME-caller idempotency only (returns same missionId). isolation.test.ts ISO-01..04 (10–40) only test cross-caller READ/CANCEL denial, not submission with shared idempotency key. |
| 13 | **Cancellation before/during/after** start, reasoning, tool execution, verification, completion | **PARTIAL** | cancellation.test.ts CANCEL-01..04 (196–331); http-api.test.ts API-10/API-10b (112–135); shutdown-lifecycle SHUTDOWN-02 (211–230) | CANCEL-01 covers during-reasoning. CANCEL-03/04 cover repeated + post-terminal idempotency. SHUTDOWN-02 covers not re-cancelling a terminal mission. NO test covers: cancel BEFORE orchestrator.run() starts; cancel DURING tool exec (writeFile in flight); cancel DURING verification loop; cancel DURING completion/finalization. The orchestrator's per-phase abort hooks (worker-agent.ts:796, 1044–1059) are not adversarially exercised per-phase. |
| 14 | **Repeated cancellation** | **YES** | cancellation.test.ts CANCEL-03 (272–299); http-api.test.ts API-10b (127–135) | 3 repeated cancels in CANCEL-03; idempotent terminal-cancel in API-10b. Adequate. |
| 15 | **Duplicate terminal transitions** | **NO** | — | No test asserts that a mission reaching SUCCEEDED cannot subsequently be flipped to CANCELLED/FAILED by a late abort or a second finishMission() call. mission-service.ts:595–635 sets terminal status exactly once via the `runPromise` resolve/reject handlers, but no test verifies the state machine is monotonic once terminal. |
| 16 | **Gateway restart** (in-process state, no durability) | **NO** | — | mission-service.ts:22–23 documents `RESTART_RECOVERY = LIMITED` and main.ts:357 logs "In-process state; no durability across restart." But NO test verifies that after constructing a fresh MissionService instance, prior mission IDs are unresolvable (i.e., confirms the no-durability contract). |

**Coverage tally:** 1 fully covered (✓), 8 partial, 7 not covered.

---

## 5. Independent Test Recommendations (for UNCOVERED / PARTIAL cases)

> All tests below are designed to run **without** real OpenBot infrastructure, using
> a controlled stub runtime (the same `ControlledStubRuntime` pattern already used
> in shutdown-lifecycle.test.ts) plus, where the case demands, a `FakeChildProcess`
> stub that emulates `detached: true` semantics without spawning real OS processes.

### F-RECON-IT-01 — SIGTERM delivered to a gateway with active missions (case #2, partial → full)
- **Test name:** `ADVERSARIAL-SHUTDOWN-SIGTERM-DURING-EXEC`
- **Setup:** Construct a `MissionService` with 1+ active mission whose
  scripted reasoning hangs for 60 s (use `scriptedReasoning(null)`). Spawn the
  gateway via `tsx src/gateway/main.ts` in its own process group
  (`detached: true`, `stdio: ['ignore','pipe','pipe']`) — same pattern as
  clean-room-gateway.test.ts GATEWAY-04 but submit a real mission first via
  HTTP POST.
- **Action:** `process.kill(-gatewayPid, 'SIGTERM')` 200 ms after submission.
- **Expected:** gateway logs `received SIGTERM, shutting down...`; service.shutdown
  drains the mission (orchestrator abort fires, finally{} runs stopWorker); gateway
  exits 0; HTTP port released (ECONNREFUSED on /health probe).
- **Failure indicator:** gateway exits non-zero OR /health still responds 5 s after
  SIGTERM (orphan).
- **Real OpenBot needed?** No — use the stub reasoning + stub runtime via
  `GENESIS_RUNTIME_PROVIDER=stub` + `GENESIS_REASONING_PROVIDER=stub`
  (already supported by main.ts:100–123 and 160–182).

### F-RECON-IT-02 — Cancellation racing with shutdown (case #3)
- **Test name:** `ADVERSARIAL-CANCEL-DURING-SHUTDOWN`
- **Setup:** One active mission (scripted reasoning hangs). Begin
  `service.shutdown(2_000)` but do NOT await it.
- **Action:** Concurrently call `service.cancel(missionId, CALLER)` 50 ms later
  (during the drain pass). Then await the shutdown promise.
- **Expected:** shutdown completes cleanly; the cancel call either returns
  CANCELLATION_REQUESTED (if mission not yet terminal) or the terminal status
  (idempotent); no exception thrown; final perMission entry shows drained=true.
- **Failure indicator:** cancel() throws (because the registry is being iterated
  during shutdown) OR shutdown hangs (because cancel's abort fired while shutdown
  was already mid-await on runPromise, somehow settling the promise incorrectly).
- **Real OpenBot needed?** No — `ControlledStubRuntime`.

### F-RECON-IT-03 — Worker ignoring SIGTERM triggers SIGKILL escalation (case #4)
- **Test name:** `ADVERSARIAL-WORKER-IGNORES-SIGTERM-ESCALATES-TO-SIGKILL`
- **Setup:** Unit-test `startComputerProcess()` indirectly by injecting a
  `FakeChildProcess` that ignores SIGTERM (mock `child.kill` to no-op on
  SIGTERM, accept SIGKILL). Cannot use real OpenBot; instead, drive the
  adapter's `stopWorker()` against a fake `RunningComputer.stop()`.
- **Action:** Invoke `stop()` on the RunningComputer.
- **Expected:** `killGroup('SIGTERM')` fires; 2 s later `killGroup('SIGKILL')`
  fires; `exited` promise resolves; `stop()` returns.
- **Failure indicator:** `stop()` hangs past 2.5 s, or SIGKILL is never invoked
  on the group.
- **Real OpenBot needed?** No — controlled stub at the ComputerProcess spawn
  boundary. The 2 s grace is enforced inside `stop()` (computer-process.ts:266–275).

### F-RECON-IT-04 — Worker close() throwing (case #5, partial → full)
- **Test name:** `ADVERSARIAL-CLOSE-THROWS-MARKED-UNCLEAN`
- **Setup:** `ControlledStubRuntime` with a `close()` that throws
  `new Error('close failed')`. Submit 1 active mission, then call
  `service.shutdown(2_000)`.
- **Action:** Await shutdown.
- **Expected:** `result.runtimeAdapterCloseErrors === 1`;
  `result.perRuntime[0].closeError` contains 'close failed';
  `result.clean === false`; orchestrator finally{} still ran stopWorker for the
  ensured worker (assert via a stopWorker-call counter on the stub).
- **Failure indicator:** shutdown rejects (instead of returning a structured
  result with closeError captured), OR `clean=true` despite close throwing.
- **Real OpenBot needed?** No.

### F-RECON-IT-05 — Worker already exited (case #6)
- **Test name:** `ADVERSARIAL-STOPWORKER-ON-ALREADY-EXITED-WORKER-IS-NOOP`
- **Setup:** `ControlledStubRuntime` configured so that `ensureWorker` records
  the handle, then a separate test hook calls `stopWorker` once before shutdown
  (simulating the worker having exited on its own and the adapter having
  already retired it). Then call `service.shutdown(2_000)`.
- **Action:** Await shutdown.
- **Expected:** No exception; perRuntime.closeCalled=true; orchestrator's
  finally stopWorker on the (now-missing) worker is a no-op (OpenBot adapter
  path: stopWorker returns silently if `!running`).
- **Failure indicator:** shutdown throws, OR `closeError` populated because
  stopWorker on a missing handle threw.
- **Real OpenBot needed?** No — verify the OpenBot adapter's `stopWorker:166–177`
  early-return branch directly with a stubbed `workers` Map.

### F-RECON-IT-06 — Repeated SIGTERM / SIGTERM+SIGINT (case #7, partial → full)
- **Test name:** `ADVERSARIAL-REPEATED-SIGNALS-IDEMPOTENT-EXIT-CODE`
- **Setup:** Spawn the gateway as in IT-01 with one active mission.
- **Action:** (a) Send SIGTERM twice within 100 ms. (b) In a separate run,
  send SIGTERM, wait 50 ms, send SIGINT. Observe exit code and stderr.
- **Expected:** Gateway exits exactly once with the correct exit code (0 for
  clean). Stderr contains exactly one "received SIGTERM" / "received SIGINT"
  line per signal (or exactly one if deduplicated — TBD by spec). No second
  shutdown sequence runs (no duplicate "drained N missions" log).
- **Failure indicator:** Multiple shutdown sequences logged; gateway exits
  with non-zero when shutdown was actually clean; or gateway hangs because
  `shutdownInProgress` was set but `process.exit` was skipped due to a race.
- **Real OpenBot needed?** No — stub runtime/reasoning providers.

### F-RECON-IT-07 — 10 s deadline expiration (case #8, partial → full)
- **Test name:** `ADVERSARIAL-SHUTDOWN-DEADLINE-10S-EXACT`
- **Setup:** `ControlledStubRuntime` with `stopWorkerDelayMs = 11_000`
  (exceeds the 10 000 ms bound from main.ts:379). One active mission.
- **Action:** Call `service.shutdown(10_000)`. Use `Date.now()` bracketing.
- **Expected:** `result.activeMissionsTimedOut === 1`; `result.clean === false`;
  `result.elapsedMs` is in [9_900, 12_000] ms (the 10 s deadline + close() pass);
  `result.perMission[0].timedOut === true`.
- **Failure indicator:** shutdown takes 11+ seconds (proves the 10 s global bound
  is NOT enforced — see F-RECON-001), OR `clean === true`.
- **Real OpenBot needed?** No.

### F-RECON-IT-08 — Exit code 1 path on unclean shutdown (case #9, partial → full)
- **Test name:** `ADVERSARIAL-EXIT-CODE-1-ON-UNCLEAN-SHUTDOWN`
- **Setup:** Spawn gateway as in IT-01 with a stub runtime whose `close()`
  throws (or with a worker that ignores SIGTERM past 10 s). Submit one mission.
- **Action:** SIGTERM the gateway; capture exit code via `child.once('exit', (code) => ...)`.
- **Expected:** exit code === 1 (main.ts:407). Stderr contains the warning
  lines for timedOut/closeErrors.
- **Failure indicator:** exit code === 0 (clean misreported) OR exit code === null
  (process killed by external SIGKILL fallback rather than exiting on its own).
- **Real OpenBot needed?** No — stub providers.

### F-RECON-IT-09 — Two real process groups not cross-terminated (case #1, partial → full)
- **Test name:** `ADVERSARIAL-TWO-PROCESS-GROUPS-ISOLATED-KILL`
- **Setup:** Spawn TWO stub child processes (each `detached: true`, each its
  own process group leader) representing two mission workers. Use the
  `startComputerProcess` function against a fake `bun` that runs a small
  `node -e "setInterval(()=>{}, 1000)"` script — so the child stays alive.
  Record each pgid.
- **Action:** "Cancel" Mission A by calling stop() on its RunningComputer.
- **Expected:** Mission A's pgid is no longer killable (ESRCH on
  `process.kill(-pgidA, 0)`); Mission B's pgid is still alive
  (`process.kill(-pgidB, 0)` succeeds).
- **Failure indicator:** Mission B's pgid is also gone (cross-termination) —
  would indicate the `process.kill(-pgid, signal)` is hitting a shared
  parent group rather than the per-worker group.
- **Real OpenBot needed?** No — uses `node` as a stand-in for `bun`/OpenBot.
  Validates the `detached: true` + group-kill invariant in
  computer-process.ts:193, 256–275.

### F-RECON-IT-10 — Idempotency key collision across callers (case #12)
- **Test name:** `ADVERSARIAL-IDEMPOTENCY-KEY-CROSS-CALLER-REJECTED`
- **Setup:** MissionService with stub runtime. CALLER_A and CALLER_B with
  different callerIds. Both submit with `idempotencyKey='shared-key-001'`.
- **Action:** `Promise.all([service.start({outcome:'A', idempotencyKey:'shared-key-001'}, CALLER_A), service.start({outcome:'B', idempotencyKey:'shared-key-001'}, CALLER_B)])` wrapped in try/catch.
- **Expected:** Exactly one submission succeeds (returns a missionId); the
  other throws `MissionAdmissionError('idempotency key already in use by another caller')`.
  The succeeding mission is owned by whichever caller won the race.
- **Failure indicator:** Both submissions return missionIds (collision) OR
  the second submission silently returns the first's missionId (cross-caller
  leak — would be a P0 isolation defect).
- **Real OpenBot needed?** No.

### F-RECON-IT-11 — Per-phase cancellation coverage (case #13, partial → full)
- **Test name:** `ADVERSARIAL-CANCEL-PER-PHASE`
- **Setup:** A `PhaseAwareReasoning` stub that exposes hooks for
  `{ start, reasoning, toolExec, verification, completion }` and pauses at
  each phase until released. Five sub-tests, one per phase.
- **Action:** Submit a mission, then call `service.cancel(missionId, CALLER)`
  while the orchestrator is paused in each phase.
- **Expected:**
  - cancel during `start`: mission reaches CANCELLED, no worker-started event.
  - cancel during `reasoning`: mission reaches CANCELLED or PARTIAL, worker
    retired via finally{}.
  - cancel during `toolExec`: in-flight writeFile either completes (PARTIAL)
    or is rolled back (CANCELLED); worker retired.
  - cancel during `verification`: verification loop short-circuits; final
    status CANCELLED (not SUCCEEDED even if artifacts exist).
  - cancel during `completion`: completion is abandoned; final status
    CANCELLED (NOT SUCCEEDED — this is the dangerous case where a
    half-finalized mission could be wrongly reported as success).
- **Failure indicator:** ANY of the per-phase cancels returns SUCCEEDED —
  would indicate the abort did not propagate to that phase (P0).
- **Real OpenBot needed?** No — phase-aware scripted reasoning.

### F-RECON-IT-12 — Duplicate terminal transition is rejected (case #15)
- **Test name:** `ADVERSARIAL-TERMINAL-STATE-MONOTONIC`
- **Setup:** Submit a mission; await completion (SUCCEEDED). Capture
  `rt.status` and `rt.finishedAt`.
- **Action:** Call `service.cancel(missionId, CALLER)` (already terminal);
  then call `service.shutdown(2_000)`.
- **Expected:** `cancel()` returns the existing SUCCEEDED status unchanged
  (mission-service.ts:745–748). `rt.status` remains SUCCEEDED;
  `rt.finishedAt` is unchanged. shutdown's perMission entry for this mission
  is NOT in the activeSnapshots list (it's terminal). No "phantom" second
  terminal transition.
- **Failure indicator:** rt.status flips from SUCCEEDED to CANCELLED after
  the late cancel — would indicate the state machine is non-monotonic (P1).
- **Real OpenBot needed?** No.

### F-RECON-IT-13 — Gateway restart loses in-process state (case #16)
- **Test name:** `ADVERSARIAL-RESTART-LOSES-STATE`
- **Setup:** Construct MissionService S1, submit one mission, await
  completion, capture `missionId`.
- **Action:** Construct a SECOND MissionService S2 (same options, fresh
  instance — simulating a process restart). Call `S2.get(missionId, CALLER)`.
- **Expected:** `S2.get` throws `MissionNotFoundError` — the in-memory
  registry does not survive a restart. Also assert `S2.health().totalMissions === 0`.
- **Failure indicator:** S2 returns the mission — would indicate the
  "no durability" contract is violated (state leaked via static/global
  references — P1).
- **Real OpenBot needed?** No.

---

## 6. Preliminary Findings

### F-RECON-001 — No global deadline enforcement on `MissionService.shutdown()`
- **Title:** `service.shutdown(deadlineMs)` does NOT enforce `deadlineMs` as a wall-clock cap; close() pass can block indefinitely.
- **Severity guess:** P1
- **Confidence:** HIGH
- **File:line:** `src/gateway/mission-service.ts:293–402` (especially the close() pass at 360–384 which has no per-runtime timeout)
- **Observation:** The per-mission drain (pass B) uses `Promise.race(runPromise, setTimeout(missionDeadline))`, so a single mission is bounded. But pass C — `await rt.runtime.close()` at line 370 — has NO timeout. If a runtime adapter's close() hangs (e.g., a stuck OpenBot process whose SIGKILL also fails), the gateway shutdown handler at main.ts:379 will block on `await service.shutdown(10_000)` for much longer than 10 s. Node's SIGTERM handler is single-threaded; a second signal cannot interrupt the await. main.ts:407 `process.exit(...)` is never reached. This means the operator's "10 s bound" is not actually enforced — it's an aspirational comment, not a guarantee. The `result.elapsedMs` field will be > 10 000 ms in this case but no test asserts the bound.
- **Test gap:** Case #8 (deadline expiration) is only tested with `stopWorkerDelayMs=10_000` and a 500 ms deadline — it never tests close() blocking past the deadline.

### F-RECON-002 — Exit-code-1 path is never exercised by any test
- **Title:** `main.ts:407` (`process.exit(result.clean ? 0 : 1)`) and `main.ts:411` (catch → exit 1) are dead code from a test-coverage standpoint.
- **Severity guess:** P2
- **Confidence:** HIGH
- **File:line:** `src/gateway/main.ts:407` and `src/gateway/main.ts:411`
- **Observation:** SHUTDOWN-10 in shutdown-lifecycle.test.ts only asserts `result.clean ? 0 : 1` *equals 0* — i.e., only the clean path. SHUTDOWN-05 produces `clean=false` but does not compute or assert exitCode=1. No test spawns the gateway, forces an unclean shutdown, and asserts the actual OS process exit code is 1. The catch-block `process.exit(1)` at line 411 is similarly never exercised. This is a Campaign D §10 case #9 GAP.

### F-RECON-003 — Idempotency guard race in main.ts shutdown handler
- **Title:** `if (shutdownInProgress) return;` at main.ts:368 silently drops the second signal without awaiting; potential for skipped exit if first shutdown sequence throws synchronously.
- **Severity guess:** P3
- **Confidence:** MEDIUM
- **File:line:** `src/gateway/main.ts:364–412`
- **Observation:** If the first SIGTERM triggers `service.shutdown()` which rejects, the catch at 408 sets `shutdownCompleted=true` and exits 1 — fine. But if `service.shutdown()` *resolves* but the `process.exit(result.clean ? 0 : 1)` call at line 407 is somehow delayed (e.g., still-flushing stdio), a second SIGINT received in that window hits `if (shutdownInProgress) return;` and exits silently. Node's default SIGINT handler is overridden, so the second signal cannot escalate. In practice this is a tiny window, but it's the kind of thing adversarial case #7 (repeated shutdown signals) is meant to probe. Worth an explicit IT-06 test.

### F-RECON-004 — `MissionService.shutdown()` iterates ALL missions for close() pass, including terminal ones
- **Title:** Pass C (lines 360–384) iterates `this.missions` (not just activeSnapshots), so terminal missions' runtimes are ALSO closed.
- **Severity guess:** P3
- **Confidence:** HIGH
- **File:line:** `src/gateway/mission-service.ts:360–364`
- **Observation:** This is mostly benign because the `seenRuntimes` Set deduplicates by instance, and terminal missions' runtimes are typically already closed by their orchestrator finally{}. BUT it means: (a) the same runtime instance might be in two Map entries (Mission A's terminal runtime + Mission B's active runtime, if a shared runtime was used — RB-2 forbids this but the code doesn't enforce it); (b) close() can be called on a runtime that was already closed by a previous mission's shutdown. OpenBotRuntimeAdapter.close() at adapter.ts:249–260 sets `this.closed=true` and clears the maps — calling it twice is safe. But a runtime whose close() is non-idempotent (e.g., throws on second call) would break the safety net. No test exercises this. Mild robustness gap.

### F-RECON-005 — Cancellation during shutdown (case #3) is undefined behavior
- **Title:** `service.cancel(missionId, CALLER)` racing with `service.shutdown(deadlineMs)` mutates `rt.canceled`/`rt.status` while shutdown's pass B is reading them.
- **Severity guess:** P2
- **Confidence:** MEDIUM
- **File:line:** `src/gateway/mission-service.ts:294–316` (shutdown) vs `743–753` (cancel)
- **Observation:** `shuttingDown` flag at line 294 prevents new submissions (start() at 478 throws) but does NOT prevent cancel(). If a client calls cancel() while shutdown's pass A is iterating `this.missions` and mutating `rt.canceled`/`rt.controller.abort()`, the cancel call would also mutate the same fields concurrently (JavaScript is single-threaded, so the mutations don't tear — but the second `controller.abort()` is a no-op on an already-aborted controller, and `rt.status = 'CANCELLATION_REQUESTED'` is set twice). The race is benign in practice but the mandate §10 case #3 ("cancellation during cleanup") explicitly calls this out — and there is no test for it. IT-02 above addresses this.

### F-RECON-006 — Idempotency-key cross-caller rejection is untested (case #12)
- **Title:** `mission-service.ts:500–511` rejects cross-caller idempotency-key reuse with `MissionAdmissionError`, but no test exercises this branch.
- **Severity guess:** P2
- **Confidence:** HIGH
- **File:line:** `src/gateway/mission-service.ts:500–511`
- **Observation:** The cross-caller idempotency check is a security-relevant invariant (one caller must not be able to "claim" another caller's mission by guessing their idempotency key). The fact that this is untested is a Campaign E §11 case #12 GAP. IT-10 above addresses this. Note: the check uses `existingMission.callerId === caller.callerId` — the comparison is by `callerId` string, not by API key, so two different API keys mapping to the same callerId would both succeed. That's a documented design choice but should be confirmed by a test.

### F-RECON-007 — No test for "worker ignoring SIGTERM" — the SIGKILL escalation is dead code from a test perspective
- **Title:** `computer-process.ts:266–275` (2 s SIGTERM→SIGKILL escalation) is never exercised by any test in the worktree.
- **Severity guess:** P2
- **Confidence:** HIGH
- **File:line:** `src/runtime/openbot/computer-process.ts:266–275`
- **Observation:** The mandate §10 case #4 ("a worker ignoring SIGTERM") is meant exactly to probe this. The shutdown-lifecycle tests use ControlledStubRuntime which has no concept of signal handling. The separate-process-e2e and clean-room-gateway tests SIGTERM the GATEWAY, not a worker. No test in the worktree spawns a worker process and asserts the 2-stage kill. IT-03 and IT-09 above address this.

### F-RECON-008 — Per-phase cancellation coverage is missing the verification phase (the dangerous one)
- **Title:** No test asserts that cancellation during the verification phase does NOT result in SUCCEEDED.
- **Severity guess:** P1
- **Confidence:** MEDIUM
- **File:line:** `src/mission/orchestrator.ts` verification loop (around the `finally` at 855; the abort hook at 371–374 fires during verification too).
- **Observation:** cancellation.test.ts CANCEL-01 cancels during the reasoning step (500 ms in). CANCEL-04 counts worker-started events. But the mandate §11 case #13 explicitly enumerates phases: "before/during/after start, reasoning, tool execution, verification, completion". The verification phase is the dangerous one — if verification has produced a `verificationEvent` with `ok=true` but the abort fires before `finishMission()` completes, the mission might be reported as SUCCEEDED despite being cancelled. No test probes this. IT-11 above addresses it.

### F-RECON-009 — Two-mission "process group" test uses in-process stubs, not real OS process groups (case #1)
- **Title:** SHUTDOWN-01/07/08 assert cross-mission isolation for in-process stubs but never for real OS process groups.
- **Severity guess:** P2
- **Confidence:** HIGH
- **File:line:** `tests/g6-08-r1/shutdown-lifecycle.test.ts:173–209, 312–336, 338–366`
- **Observation:** The mandate §10 case #1 specifically calls out "two independent worker **process groups**". The `detached: true` spawn at `computer-process.ts:193` and the `process.kill(-pgid, signal)` group-kill at `computer-process.ts:260, 265, 268` are NEVER exercised by shutdown-lifecycle tests. The clean-room-gateway test exercises group-kill for the gateway process but not for a worker process. IT-09 above addresses this.

### F-RECON-010 — `MemoryRuntime` does not implement `close()` — the safety net is a no-op in dev mode
- **Title:** `src/runtime/memory-computer.ts:91–146` `MemoryRuntime` class has no `close()` method; the `WorkerRuntime.close?()` optional method (computer.ts:184) defaults to a no-op.
- **Severity guess:** P3
- **Confidence:** HIGH
- **File:line:** `src/runtime/memory-computer.ts:91–146`, `src/runtime/computer.ts:184`
- **Observation:** mission-service.ts:368 checks `typeof rt.runtime.close === 'function'` and treats the absence of close() as success (`closed = true`). In dev mode (MemoryRuntime), the safety net therefore does nothing — but there's nothing to clean up, so this is correct. The OpenBotRuntimeAdapter DOES implement close() (adapter.ts:249–260). This is a documentation note, not a defect — but it means tests using MemoryRuntime cannot detect regressions in the close() safety net. Tests that exercise the safety net MUST use a runtime that implements close() (ControlledStubRuntime does — good).

---

## Appendix A — Existing test inventory relevant to shutdown/concurrency/cancellation/idempotency

| File | Line range | 1-line summary |
|------|------------|----------------|
| `tests/g6-08-r1/shutdown-lifecycle.test.ts` | 1–434 | 12 new tests for B-EXEC-FINDING-003 shutdown contract using ControlledStubRuntime (no real OS processes). |
| `tests/g6-08/rb2-concurrent-isolation.test.ts` | 1–295 | 4 tests for RB-2 fresh-per-mission runtime isolation: distinct instances, A-finish-doesn't-break-B, A-cancel-doesn't-kill-B, factory receives missionId. |
| `tests/g6-08/p3-bounded-resources.test.ts` | 1–271+ | RC-6 bounded registry: terminal missions evicted after retention; idempotency key reuse after eviction; flight recorder event cap; sweeper unref. |
| `tests/g6-08/p5-security-remediation.test.ts` | 1–202+ | P5-03 cross-caller cancelTask doesn't leak status; P5-08 shutdown command is blocked. |
| `tests/gateway/cancellation.test.ts` | 1–332 | CANCEL-01..04: cancel during reasoning; event history; repeated cancel; no further work after cancel. Real HTTP+service path. |
| `tests/gateway/isolation.test.ts` | 1–40 | ISO-01..04: cross-caller GET/events/artifacts/cancel all return 404 (not 403). |
| `tests/gateway/concurrent-a2a.test.ts` | 1–250 | CONCURRENT-01..05: A2A simultaneous submissions; cross-caller cancel rejected; repeated same-caller requests isolated. |
| `tests/gateway/http-api.test.ts` | 1–192 | API-10: cancel propagation; API-10b: idempotent terminal cancel; API-11: same-caller idempotency returns same missionId; API-12: oversized body rejected. |
| `tests/gateway/clean-room-gateway.test.ts` | 1–354 | GATEWAY-04: SIGTERM the (idle, dev-mode) gateway process group, port released, handler logged. GATEWAY-05: no orphan processes in the test's process group. |
| `tests/gateway/separate-process-e2e.test.ts` | (file exists, not read in detail) | Spawns gateway in own process group; SIGTERM via negative PID (line 156). |
| `tests/gateway/e2e.test.ts` | (file exists) | No matches for idempotency/cancel/concurrency/shutdown — likely basic happy-path coverage. |

---

## Appendix B — Code anchors quoted for the mandate

**`src/mission/orchestrator.ts` finally{} block (lines 855–868):**
```
855:    } finally {
856:      clearTimeout(timeout);
857:      this.options.signal?.removeEventListener('abort', onExternalAbort);
858:      // Temporary workers are always retired — stop keeps their durable
859:      // workspace files but ends their runtime presence.
860:      for (const { handle } of ensured) {
861:        try {
862:          await this.options.runtime.stopWorker(handle);
863:        } catch {
864:          // retirement is best-effort per worker; the mission result already
865:          // carries the real outcome
866:        }
867:      }
868:    }
```
The `ensured` array is built at line 380–381 (`const ensured: { handle: RuntimeHandle; genome: WorkerGenome }[] = []`) and appended to during worker spawn.

**`src/runtime/openbot/computer-process.ts` detached spawn (lines 173–194):**
```
173:  const child = spawn(config.bunPath ?? 'bun', ['src/index.ts'], {
174:    cwd: workingDir,
175:    env: {
...
181:      EGRESS_POLICY_REQUIRED: '0',
182:      ...config.extraEnv,
183:    },
184:    stdio: ['ignore', 'pipe', 'pipe'],
185:    // GROUP 3 fix, exposed by Experiment 002 evidence: a dedicated process
186:    // group lets stop() terminate EVERY process the computer spawned
...
193:    detached: true,
194:  }) as ChildProcess;
```

**Group-kill escalation (lines 256–289):**
```
256:    const pgid = child.pid;
257:    if (pgid !== undefined) {
258:      const killGroup = (signal: NodeJS.Signals): void => {
259:        try {
260:          process.kill(-pgid, signal);
261:        } catch { /* group already gone */ }
262:      };
265:      killGroup('SIGTERM');
266:      await new Promise<void>((resolve) => {
267:        const timer = setTimeout(() => {
268:          killGroup('SIGKILL');
...
275:      });
276:    }
278:    // Stage 2: processes still working inside this computer's directories.
...
286:      signalPids(escaped, 'SIGTERM');
287:      await new Promise((resolve) => setTimeout(resolve, 500));
288:      signalPids(escaped, 'SIGKILL');
```

---

*End of stage-4-recon report. The Independent Test Engineer did not modify any production source code or run any existing tests. New adversarial tests proposed in §5 should be implemented under `/home/z/my-project/genesis-audit/workspace/` for Campaign D/E qualification.*
