# 00-06 — Durable Task Runtime and Balance Master Stub

**Project:** The Balance | **GROUP:** 00 Foundation | **Status:** NOT STARTED | **Priority:** Sequential | **Authority:** Master Blueprint v2.0 + Roadmap v1.0 + prior verified mission handoff.

## Mission objective
Implement durable queued/running/completed/failed/review-needed task model; minimal router for build/observe/reform/continuity intents, typed task inputs and outputs; deterministic reference handler clearly labeled non-production. Make tasks resumable and idempotent; state persisted.

## Boundaries
- Do not build GROUP 01–04 engines in full or claim government deployment.
- Review current Git and tests before coding; preserve working features and prior approvals.
- Reuse established libraries and scaffolding instead of multiplying modules for their own sake.
- Work on `mayakilzy/The-Balance`, not the auxiliary documentation repository.
- Protect credentials, private data and tenant boundaries; label all simulated examples clearly.

## Required implementation and artifacts
Task store, dispatcher, APIs/CLI, restart test, trace samples

## Executable validation and acceptance
Restart restores pending task, duplicate request idempotent, failures truthful; missing tool capability yields unsupported and never invented answer; no hidden auto-execution.

## Evidence protocol
- Document exact branch, base and final SHA, paths touched, commands and exit statuses.
- Include unit/integration/E2E tests actually executed and evidence of negative paths.
- Clearly differentiate real API/database/service operations, simulated data, and untested dependencies.
- For changed contracts, include migration and compatibility impact and decision record.
- Store report `docs/mission-reports/G00/00-06_REPORT.md` and commit only after verifying it is safe.

## Definition of done
1. Feature(s) run in the actual project environment or explicitly marked PARTIAL.
2. Acceptance assertions demonstrated, including at least one negative/error case.
3. No unauthorized external writes, no secrets committed, test data clearly labeled.
4. Final report supplies NEXT_MISSION and reproducible commands.
5. All failure/limitations honestly disclosed; PASS is based on proof, not intention.
