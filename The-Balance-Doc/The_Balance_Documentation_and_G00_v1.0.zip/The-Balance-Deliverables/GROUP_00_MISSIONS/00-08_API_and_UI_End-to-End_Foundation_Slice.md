# 00-08 — API and UI End-to-End Foundation Slice

**Project:** The Balance | **GROUP:** 00 Foundation | **Status:** NOT STARTED | **Priority:** Sequential | **Authority:** Master Blueprint v2.0 + Roadmap v1.0 + prior verified mission handoff.

## Mission objective
Build minimal web UI (Arabic/English architecture capable) with tenant chooser, country baseline page, source/evidence inspector, strategy draft and observed event timeline, task status. Use real backend+DB, not hard-coded final-screen mocks. Demonstrate simplified cross-contract sequence.

## Boundaries
- Do not build GROUP 01–04 engines in full or claim government deployment.
- Review current Git and tests before coding; preserve working features and prior approvals.
- Reuse established libraries and scaffolding instead of multiplying modules for their own sake.
- Work on `mayakilzy/The-Balance`, not the auxiliary documentation repository.
- Protect credentials, private data and tenant boundaries; label all simulated examples clearly.

## Required implementation and artifacts
Frontend, API contract/OpenAPI, scripted smoke and optional browser screenshots

## Executable validation and acceptance
Input evidence -> create strategy draft -> append event -> observation -> draft recommendation -> view strategy history persists after refresh/restart. UI never claims generated plan is approved or implemented.

## Evidence protocol
- Document exact branch, base and final SHA, paths touched, commands and exit statuses.
- Include unit/integration/E2E tests actually executed and evidence of negative paths.
- Clearly differentiate real API/database/service operations, simulated data, and untested dependencies.
- For changed contracts, include migration and compatibility impact and decision record.
- Store report `docs/mission-reports/G00/00-08_REPORT.md` and commit only after verifying it is safe.

## Definition of done
1. Feature(s) run in the actual project environment or explicitly marked PARTIAL.
2. Acceptance assertions demonstrated, including at least one negative/error case.
3. No unauthorized external writes, no secrets committed, test data clearly labeled.
4. Final report supplies NEXT_MISSION and reproducible commands.
5. All failure/limitations honestly disclosed; PASS is based on proof, not intention.
