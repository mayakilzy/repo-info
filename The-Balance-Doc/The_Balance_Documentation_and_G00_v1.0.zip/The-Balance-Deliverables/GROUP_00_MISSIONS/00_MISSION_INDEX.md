# GROUP 00 — Mission Index

| ID | Mission | Core evidence |
|---|---|---|
| 00-00 | Repo Baseline & Architectural Recon | verified baseline and ADR |
| 00-01 | Dev Runtime and Project Skeleton | clean run and health API |
| 00-02 | Country & Tenant Data Model | migrations + unique country model |
| 00-03 | Identity Authorization & Isolation | negative cross-tenant tests |
| 00-04 | Evidence & Source Contract | dedup/provenance/counter evidence |
| 00-05 | National Strategy & Event Contracts | versioning and approvals guarded |
| 00-06 | Durable Tasks and Master Stub | resume/retry/idempotency |
| 00-07 | Expert/Tool Capability Registry | typed discovery + least privilege |
| 00-08 | API + UI Vertical Slice | real DB-backed workflow demo |
| 00-09 | Audit, Security and Observability | auditable decisions and safe telemetry |
| 00-10 | Integration, CI and Restore Drill | fresh install and E2E proof |
| 00-11 | Acceptance and Handoff | proof-backed group closure |

Do not consider phase 00 production release. The product remains a foundation for later engines.
