# 00-02 — Tenant Country and State Ontology

**Project:** The Balance | **GROUP:** 00 Foundation | **Status:** NOT STARTED | **Priority:** Sequential | **Authority:** Master Blueprint v2.0 + Roadmap v1.0 + prior verified mission handoff.

## Mission objective
Define tenant, country, admin unit, institution, role reference, source registry and basic spatial/time scope; stable UUIDs, foreign keys and versioned migrations. Seed one clearly fictional country fixture and optional empty Syria country configuration without asserting unverified facts.

## Boundaries
- Do not build GROUP 01–04 engines in full or claim government deployment.
- Review current Git and tests before coding; preserve working features and prior approvals.
- Reuse established libraries and scaffolding instead of multiplying modules for their own sake.
- Work on `mayakilzy/The-Balance`, not the auxiliary documentation repository.
- Protect credentials, private data and tenant boundaries; label all simulated examples clearly.

## Required implementation and artifacts
Migrations, typed entities, country schema, seed fixtures, test suite

## Executable validation and acceptance
FK and scoped queries enforced; duplicate collisions handled; schema migration round trip; no synthetic indicator mislabeled real.

## Evidence protocol
- Document exact branch, base and final SHA, paths touched, commands and exit statuses.
- Include unit/integration/E2E tests actually executed and evidence of negative paths.
- Clearly differentiate real API/database/service operations, simulated data, and untested dependencies.
- For changed contracts, include migration and compatibility impact and decision record.
- Store report `docs/mission-reports/G00/00-02_REPORT.md` and commit only after verifying it is safe.

## Definition of done
1. Feature(s) run in the actual project environment or explicitly marked PARTIAL.
2. Acceptance assertions demonstrated, including at least one negative/error case.
3. No unauthorized external writes, no secrets committed, test data clearly labeled.
4. Final report supplies NEXT_MISSION and reproducible commands.
5. All failure/limitations honestly disclosed; PASS is based on proof, not intention.
