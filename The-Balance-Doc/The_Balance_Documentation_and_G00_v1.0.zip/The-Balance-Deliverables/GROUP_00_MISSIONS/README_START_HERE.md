# The Balance — GROUP 00 Developer Start / Resume Guide

**MISSION PACK:** BALANCE-G00-v1.0 · **Target:** `https://github.com/mayakilzy/The-Balance.git` · **Status:** TASK SPECIFICATIONS ONLY — NOT EXECUTED.

## 1. ما هذه الحزمة؟

هذه مجموعة مهام **Foundation 00** فقط، وفق `01_The_Balance_Master_Blueprint_v2.0.md` و`02_The_Balance_Six_Group_Development_Roadmap_v1.0.md`. لا تنشئ State Builder أو Observatory أو Reform أو Continuity بالكامل الآن. الهدف إثبات أول vertical slice على قاعدة آمنة، ذات عقود متوافقة مع مستقبل المحركات الأربعة.

## 2. قواعد العمل الملزمة للنموذج المطور

1. افتح المستودع الرئيسي الحقيقي أولاً، وأبلغ بحالته والتزام البداية؛ لا تفترض أنه يحتوي على تطبيق قائم. لا تحذف ملفات موجودة أو تعيد تهيئة Git دون تدقيق.
2. استخدم هذه الوثائق مرجعية للهدف، لكن لا تدّع أن الملفات مرئية إذا لم تكن. اقرأ Master Blueprint وRoadmap ومصفوفة v0.3 قبل البدء.
3. حافظ على البساطة: كود صغير وقدرات حقيقية. لا تضف microservices وGraph DB منفصلة وواجهات كثيرة دون ضرورة أثبتتها.
4. استخدم Git بانتظام؛ لا تدفع مفاتيح أو بيانات شخصية حقيقية، حتى لو ظهرت في ملفات أو جلسات. تجاهل/اعزل أي سر مكتشف وأبلغ عن حاجته إلى التدوير.
5. لا تنفذ إجراء حكومياً حقيقياً، ولا تربط نظم مالية/إدارية، ولا تنشر معلومات حساسة؛ أي مصادر دولة تجريبية تكون synthetic معلَّمة بوضوح.
6. لا تعتبر mock أو latency simulation إثباتاً لاستخدام LLM/A2A/RAG حقيقي. إن كان غائباً صرّح بذلك بوضوح.
7. لا تضف حدوداً عشوائية للوقت/التوكن توقف التجارب بلا ضرورة؛ لكن طبّق سلامة البيانات والأمان والتكرار المشروع وفصل الصلاحيات.
8. بعد **كل مهمة**: اختبارات فعلية، تقرير قصير يشمل SHA وفشل/نجاح، ورفع commit للمستودع عند توفر صلاحيات وطلب التنفيذ؛ توقف عند قرار معماري جسيم لم تتناوله العقود.
9. لا تكتب GROUP 01 تفصيلياً قبل تقرير قبول GROUP 00.

## 3. تسلسل التنفيذ

`00-00 Audit → 00-01 Repository/Runtime → 00-02 Data Model → 00-03 Identity/Isolation → 00-04 Evidence → 00-05 Strategy/Events Contracts → 00-06 Master/Tasks → 00-07 Expert Registry → 00-08 API/UI Vertical Slice → 00-09 Security/Observability → 00-10 Integration/CI → 00-11 Acceptance/Handoff`.

ابدأ دائماً بالتحقق من commits ونتائج المهمات السابقة؛ لا تكرر مهمة مكتملة بلا سبب. مثال استئناف: إن كان آخر تقرير `00-05 PASS` على SHA محدد، اقرأ تقريره، تحقق من Git HEAD والعقود، وابدأ 00-06، ما لم يظهر خلل في التحقق.

## 4. الصيغ المطلوبة لكل تقرير

```text
PROJECT = THE_BALANCE
GROUP = 00
MISSION = 00-NN
BASE_SHA = <sha>
FINAL_SHA = <sha>
WORKTREE = clean|dirty (explain)
IMPLEMENTED = <concrete paths>
COMMANDS_RUN = <commands + exit codes>
TESTS = <numbers and raw evidence paths>
LIVE_VS_MOCK = <exact classification>
SECURITY = <checks performed>
CONTRACT_CHANGES = <versions and migrations>
DEFECTS = <severity and reproduction>
STATUS = PASS|PARTIAL|FAIL
NEXT_MISSION = <name>
```

حفظ التقارير ضمن `docs/mission-reports/G00/` في مستودع التطبيق. أدلة screenshots/requests/traces محددة المسار ولا ترفع أسرار. تقرير 00-11 يربط كل اختبار بعقد ومعيار نجاح.

## 5. الاستئناف في جلسة جديدة

**رسالة جاهزة للنموذج الجديد:**

> RESUME THE BALANCE GROUP 00. Read `docs/mission-reports/G00/` and the most recent authoritative handoff, then inspect the actual git branch/HEAD/worktree and working tests. Read the Master Blueprint v2.0, Six-Group Roadmap v1.0, and this mission ZIP. Do not trust conversation memory over persisted repository state. Determine LAST_ACCEPTED_MISSION and NEXT_MISSION. Do not re-run accepted work without evidence of regression; continue only the next uncompleted mission. Preserve the four future engine contracts, tenant isolation, evidence provenance, strategic versioning, and honest mock/live distinctions. Emit an evidence-backed report and commit SHA after each mission. Never reveal or commit secrets. Do not deploy to production or write to external government systems.

**حقول HANDOFF إلزامية:** repository URL, branch, exact HEAD SHA, group, passed missions, in-progress mission, next mission, test commands, failed checks, environment prerequisites, schema migrations, open defects, decisions needing confirmation, SHA of mission ZIP, known mocks.

## 6. شروط توقف مشروعة

Missing required credentials/environments; security-impacting architecture decision; data leakage or unauthorized write; irreconcilable schema change; inability to run tests or provide honest results. اعرض blocker ومقترح حل ولا تدّع PASS.

## 7. قبول المجموعة

تحتوي حزمة `00-11` النهائية على التقرير و`GROUP_00_ACCEPTANCE.md` و`NEXT_GROUP_01_HANDOFF.md` بعد فحص أدلة التشغيل. موافقة المؤسس على تقرير المجموعة شرط اعتماد كتابة مهام المجموعة 01.
