# AgentCraft Application Development Standard (AADS) v1.2

**Status:** Proposed consolidated standard for owner approval; includes SaaS Template and Toolkit policies  
**Applies to:** All new AgentCraft applications, adapted according to project risk and product type  
**Operating principle:** **Small in Code, Large in Capability** — working, verified end-to-end capability before premature complexity  
**Environment target:** Ubuntu Linux + Docker Compose + Nginx Proxy Manager (NPM)  
**Owner's canonical package catalog:** https://github.com/mayakilzy/repo-info  
**SaaS starter candidate:** https://github.com/mayakilzy/saas-template (**architecture documented in user-provided SaaS Template.md; live code not verified by connector**)

> **Scope and sourcing:** This standard integrates the owner's seven decisions, lessons from AgentCraft development, and additional engineering recommendations. `repo-info` directory structure was inspected through the connected GitHub integration. The `saas-template` README/specification was reviewed via the owner-provided `SaaS Template.md`, but the implementation was **not** accessible for inspection. The Toolkit operating guide was reviewed via the owner-provided `AgentCraft-Toolkit.md`; live repository access was not verified. No credential-bearing archive was downloaded, decrypted, or opened.

## 01 — Foundational decisions

1. **Deployment-first:** Design for Ubuntu + Docker Compose + Nginx Proxy Manager from day one. Development, staging, and production remain separate. Production secrets, volumes, backups, schema migrations, and restart behavior must be designed rather than retrofitted.
2. **SaaS starter reuse:** When an application is SaaS, inspect `mayakilzy/saas-template` before implementing identity, billing, subscription, multitenancy, admin, or other shared foundations. **Reuse only verified, suitable features** and maintain upgrade provenance. Never assume coverage before an audit.
3. **Stack chosen by product:** React + Vite for suitable client/SPAs; Next.js where server rendering, integrated routes, or full-stack patterns genuinely help; FastAPI and other backend technologies as appropriate. Database choice follows transactional, search, concurrency, and deployment requirements—not UI framework preference. Preserve existing architecture of mature projects.
4. **Live preview is compulsory:** Every UI milestone must run in a real browser, with actual responsive and locale checks. A successful build, VLM opinion, or static HTML alone does not count as a live preview.
5. **SaaS UX default:** English first (`en`, LTR); Arabic (`ar`, RTL) fully supported; other locales extensible. Accessible responsive layouts, user settings, functional navigation, account/profile management, role-aware dashboard, help, states, forms, and tables according to product needs.
6. **Approved images are specifications:** Version-controlled, owner-approved visual references are a binding part of requirements. Every approved image links to an implementation contract and responsive/locale/state variant. A visual comparison gate checks real browser screenshots against the references.
7. **Documented, grouped delivery:** Product spec + architecture + tests + approved images + numbered sequential task groups + acceptance gates packaged in a versioned ZIP and indexed under a project-named directory in `repo-info`. Source-code implementation lives in the application repository.
8. **Credential hygiene:** Never bundle plaintext or reversibly obfuscated tokens in public repositories, archives, logs, reports, or prompts. `GeneralGH/GeneralGH.zip` must **not** be treated as an approved secrets provider. Use a secure, private delivery channel/secret store or manually provision scoped credentials in the agent environment. Rotate exposed credentials and remove them from repository history when necessary; merely deleting the file at HEAD is insufficient.

## 02 — Project initiation: decision record

Before building, create `PROJECT-INTAKE.md` with:

- Product: name, mission, intended users, core workflows, measurable acceptance scenario, non-goals.
- Type: SaaS / private internal / desktop / education / data-processing / agent system.
- Hosting: public domain, staging subdomain, Ubuntu instance, external NPM network, resource baseline.
- SaaS starter suitability report: inspected commit SHA, features reused, gaps, incompatibilities, license, dependencies and security issues. If inaccessible, record **BLOCKED** and request access; do not claim audit complete.
- Stack ADR: frontend, backend, DB, auth, jobs, storage, ORM, observability, AI model/provider if needed, rationale.
- Data classification: public, private, financial, educational/minor, health or other sensitive; retention and deletion policy.
- UX: devices, locale scope, accessibility, account roles, approved visual reference IDs.
- Integrations: required APIs, real credentials provisioned outside repo, failure behavior, costs.
- Delivery risks: performance, concurrency, migration, compliance, vendor lock-in, external dependencies.

**Gate:** Owner accepts scope, core workflow, and deployment target before implementation groups begin.

## 03 — Architecture rules: keep code small, capability large

- Begin with a **verified vertical slice**: login/authorized access → core action → persisted data → UI confirmation → restart/persistence test.
- Prefer a modular monolith unless clear, tested requirements justify additional services. No swarm, microservice, event bus, graph DB, queue, or agent framework by default.
- Reuse proven infrastructure (Docker, browser tooling, Git, existing application libraries). Do not reimplement commodity tools.
- Distinguish requirements from optional future ideas. No scaffolding explosion, arbitrary folder trees, or large abstraction layers without need.
- Early experiments should not suffer artificial token/time budgets, fixed retry ceilings, or restrictive gates; maintain security, truthful results, and rollback ability.
- Record architectural decisions as short ADRs. Introduce complexity in response to measured constraints.
- Preserve accepted baseline and stop scope creep. No unrelated refactors in milestone fixes.

## 04 — SaaS baseline checklist (conditional, not all products need every item)

| Area | Mandatory for applicable SaaS | Evidence |
|---|---|---|
| Identity | Sign-in/out, secure sessions, reset/recovery, email verification where needed | End-to-end auth + negative tests |
| Tenants and roles | Server-side tenant isolation; RBAC; deny by default | Cross-tenant attack tests |
| Account & settings | Profile, locale, theme, notification/privacy preferences | Browser + persistence |
| Subscription | Trial/paid plan, entitlements, metering, payment reconciliation only if monetized | Provider sandbox + webhook idempotency |
| Admin | User/tenant management, limited support access, audit trail | Authorization tests |
| User lifecycle | Onboarding, invitations where applicable, data export/deletion, suspended accounts | Positive/negative scenarios |
| Product quality | Search/filter/sort/pagination for relevant data-heavy views, upload states, errors, undo/confirm | Browser scripts |
| Security | CSRF when relevant, SSRF, XSS, rate limits, scoped API access, credential separation | Security test summary |
| Reliability | Error monitoring, logging, backup/restore, migrations, health/readiness | Restore exercise |
| Communication | Consent, preferences, real delivery statuses; email/SMS only with provider | Delivery integration tests |

**Rule:** Never implement false UI controls (buttons, notification badges, fake billing, search fields) merely to resemble a mature SaaS.

## 05 — UI/UX design contract and approval images

A project must include a **Design System** and **Visual Reference Manifest**:

```text
design/
  README.md
  design-system.md
  responsive-and-i18n-contract.md
  approved/
    home/
      desktop-en-v1.png
      desktop-ar-v1.png
      tablet-en-v1.png
      tablet-ar-v1.png
      mobile-en-v1.png
      mobile-ar-v1.png
    ...
  manifest.json
  reviews/
```

For each approved reference, `manifest.json` records: `id`, `page`, `state`, `viewport`, `locale`, `version`, `approvedBy`, `approvedAt`, `sha256`, `specificationPath`, `status`. Only `status=approved` images are binding. The source of truth should be a pinned version/tag and should not be changed silently.

**Implementation contract:** Layout composition, spacing, typography, colors/tokens, component hierarchy, interactive behavior, loading/empty/error/filled states, desktop/tablet/mobile, RTL/LTR, low-performance fallbacks, asset license/source.

**Quality gates:**

- English default, Arabic complete; string catalogs; RTL/LTR direction per locale; locale-specific date/number formatting without corruption of money.
- Mobile 360/390, tablet 768/1024, desktop 1280/1440/1920 or project-adjusted test matrix; no horizontal overflow, no clipped essential text.
- WCAG 2.2 AA target; keyboard access, contrast, labeled controls, focus, reduced motion, screen readers.
- Screenshots taken with the running application; compare with approved reference, account for variable data and browser rendering. Document departures and get owner approval.
- Include preview URLs or reproducible local commands, screenshot bundle, E2E browser evidence and video for complex interactions when useful.
- Never mark visual approval from build success alone.

## 06 — Ubuntu Docker / Nginx Proxy Manager baseline

- Multi-stage image; non-root runtime where feasible; pinned dependency versions; minimal image with vulnerability scanning.
- `compose.yaml` with explicit persistent volumes, restart policy, healthchecks, and separation of internal services.
- External NPM proxy network; only public HTTP service reachable through proxy; DB/cache not published to public host ports.
- TLS managed at Nginx Proxy Manager, secure cookies/trusted proxy configuration, forwarded headers validated.
- `.env.example` documents configuration **without secrets**. Real environment values via protected deployment-side secret management.
- Per-environment DB and volumes; executable migration procedure tested against copies; **do not silently run destructive schema migrations on startup**.
- Health/readiness endpoints, logs without PII/tokens, resource limits/monitoring adapted to host.
- Document `deploy`, `update`, `backup`, `restore`, `rollback` commands and validate data preservation through restart/recreate.
- Produce an `UBUNTU-DOCKER-NPM-DEPLOYMENT.md` handoff. Production certification requires an actual deployment/restore smoke on the target type of environment; mocked tests are not sufficient.
- Consider a separate development server and production server where practical.

## 07 — Security, credentials, privacy

**Critical correction to the temporary GeneralGH approach:** If tokens are real or reversible, a public ZIP/obfuscated archive can expose credentials. A separate secret manager or preconfigured private agent environment is necessary. GLM/Codex should know only an **identifier** or environment variable name for a credential, not where to retrieve a secret from a public URL.

- Do not inspect, echo, translate, screenshot, attach, or commit credential material.
- Use short-lived, least-privilege, repository-scoped tokens; rotate any that may have appeared in public repository history.
- `.env`, token files, private keys and account exports ignored and excluded from archives and browser artifacts. Scanning with `gitleaks`/equivalent on working tree, commits and packaged ZIPs.
- Preflight: verify no secrets in Git history, reports, CI logs, downloadable zip, Docker image layers or screenshots.
- Tenant isolation, audit, consent, privacy-by-design, least privilege, dependency review, backups and deletion policy as appropriate to data sensitivity.
- If an external integration cannot be configured safely, mark **BLOCKED**, continue with safe mock mode when possible, and report the missing environment prerequisite. Do not circumvent security silently.

## 08 — Mission groups and checkpoint discipline

Each project receives a numbered, sequential implementation plan (`G01`, `G02`, etc.) with named tasks and explicit closure conditions. Group count follows *actual capability boundaries*, not a universal fixed number.

**Typical grouping, adapted per application:**

- **G01:** Verified baseline and vertical slice.
- **G02:** Identity, permissions, data isolation.
- **G03+ :** Core business workflows, storage, service interfaces.
- **UX group:** Design system, approved reference images, real-browser preview, accessibility/i18n.
- **Release group:** Integration, deployment, restore/rollback, acceptance.

Every task specifies: objective; baseline SHA; permitted scope; dependencies; implementation; test requirements; acceptance evidence; file list; known limitations; cost/external-service use; commit SHA; STOP/continue status.

**Gating:** Developer may implement one authorized group at a time. Reports do not self-approve. Independent review or owner approval authorizes next group. Differentiate `IMPLEMENTED`, `TESTED`, `VISUALLY_APPROVED`, `STAGING_VERIFIED`, and `PRODUCTION_READY`—these states are not interchangeable.

Preserve a canonical `CHECKPOINT.json` and a short recovery handoff so work can resume across GLM/Codex/ChatGPT sessions without retelling the history.

## 09 — Tests and acceptance: proof over claims

1. **Core correctness:** deterministic unit and integration tests, invalid input and negative paths; transaction and concurrency tests where applicable.
2. **Security:** authentication, tenant isolation, authorization, injection/SSRF where applicable; no credential leakage.
3. **UI:** actual browser smoke + meaningful E2E workflows, multiple devices and both locales; screenshots tied to commit SHA.
4. **Database:** migrate, seed sample data, actual target DB tests (PostgreSQL if used), data durability, rollback and backup/restore.
5. **Operations:** Docker build + run, healthchecks, proxy connectivity, restart, update, logs, failure recovery.
6. **Performance:** initial page load, basic responsiveness, expensive queries and memory profiling when risks justify them.
7. **Evidence:** exact commands, outputs, passing and skipped counts, dates, environment, final SHA, known risks. `SKIPPED` ≠ `PASS`.

**Acceptance scenarios:** (a) empty/new user; (b) typical user with representative safe seed data; (c) error/unauthorized flow; (d) mobile; (e) bilingual; (f) data survives restart; (g) upgrade/rollback where applicable.

## 10 — Package structure and repository ownership

`repo-info` contains canonical **instructions and artifacts**, while each application repo contains the **running code** and copied applicable standard references. Recommended:

```text
repo-info/
  Standards/
    AgentCraft_Application_Development_Standard_v1.0.md
  <ApplicationName>/
    <ApplicationName>_Master_Development_Package_v1.0.zip
    START-HERE.md
    manifest.sha256
```

**Master ZIP:**

```text
<ApplicationName>/
  00-INDEX.md
  01-PRODUCT-SPEC.md
  02-ARCHITECTURE.md
  03-DATA-SECURITY.md
  04-UX-DESIGN-CONTRACT.md
  05-OPERATIONS-DOCKER-NPM.md
  06-ACCEPTANCE-TESTS.md
  GLM/MASTER-INSTRUCTIONS.md
  GLM/groups/G01.md ...
  GLM/CHECKPOINT.json
  GLM/REPORT-TEMPLATE.md
  design/approved/...
  design/manifest.json
  manifest.sha256
```

**Keep package lean:** Do not duplicate existing docs inside every mission file; link to frozen specs; no dependencies, `.env`, private data or tokens in ZIP. Verify extraction and SHA-256 before handoff. Pin GitHub URLs/ref SHA, avoid drifting `main` where reproducibility matters.

## 11 — Completion and release certification

Release status must reflect verification evidence:

- `DEVELOPMENT_COMPLETE`: Authorized functional scope implemented and passing relevant tests.
- `VISUAL_APPROVED`: Owner approved actual browser screenshots against stored references.
- `STAGING_READY`: Deployment bundle and configuration prepared, not necessarily deployed.
- `STAGING_VERIFIED`: Actual Docker/NPM staging deployed and checked.
- `PRODUCTION_READY`: All release/security/data/backup/restore gates verified.
- `PRODUCTION_DEPLOYED`: Actual production service deployed, verified and monitored.

**Mandatory handoff:** README English + Arabic where appropriate; product purpose and use cases; environment variables names without values; deployment/updating/backup/restore; schema migrations; test evidence; known limits; owner acceptance; tags and versioned release. For public portfolio repos, maintain description, topics and screenshots; do not publish sensitive system details.

## 12 — Collaboration protocol for coding agents

- Read `AADS`, project `START-HERE`, latest `CHECKPOINT`, authorized group, and approved design manifest *before editing*.
- Inspect actual repo and verify clean baseline; do not assume files/tests exist.
- Implement in original repo/approved branch; stay within scope; commit changes frequently in meaningful units.
- Run real tests; don't invent results, visual evidence, billing or provider delivery claims.
- Stop if missing access or a critical mismatch; report exact blocker and feasible safe alternative.
- When a problem appears, fix the narrow proven defect first. Do not re-open accepted architecture unnecessarily.
- When a UI is involved, start a live preview at the earliest useful point and keep demonstrating against approved images.
- Report SHA, commands, screenshots, limits and risk; await owner acceptance before next group.

## 13 — Recommended one-page project initialization form

```yaml
application_name: ""
product_type: "saas | internal | education | agent | other"
repository: ""
repo_info_package_path: ""
standard_version: "AADS-v1.2"
saas_template:
  candidate: "https://github.com/mayakilzy/saas-template"
  inspected_sha: "PENDING"
  reuse_decision: "PENDING"
target:
  os: "Ubuntu"
  runtime: "Docker Compose"
  reverse_proxy: "Nginx Proxy Manager"
  database: "TBD by requirements"
frontend: "TBD: Vite+React, Next.js, or suitable alternative"
locales:
  default: "en"
  supported: ["en", "ar"]
  expandable: true
ux:
  screenshots_binding: true
  design_manifest: "design/manifest.json"
  real_browser_preview: true
  accessibility_target: "WCAG 2.2 AA"
security:
  secrets_in_repo_or_zip: false
  provision_via: "secure private environment or secret store"
execution:
  grouped_missions: true
  acceptance_before_next_group: true
  checkpoint: "GLM/CHECKPOINT.json"
  actual_test_evidence_required: true
release:
  stages: ["development", "staging", "production"]
  backup_restore_test_required: true
  no_automatic_production_claims: true
```

## 14 — Adoption plan (one small pilot, then standardize)

1. Verify access to `saas-template` and inspect a pinned commit; map reusable features and outstanding gaps without making unsupported claims.
2. Move any real GeneralGH tokens out of the public repo and rotate impacted secrets. Leave only credential **names and setup instructions**.
3. Approve AADS v1.2, add it under `repo-info/Standards/`, and link it from each new project `START-HERE.md`.
4. Pilot the standard on one new or narrowly scoped project; validate one end-to-end Docker/NPM preview, one mission group, and one owner-approved bilingual responsive screen.
5. Issue subsequent versions for demonstrated omissions. Maintain change log and avoid repetitive over-engineering.

---

**Verification note (2026-10-15):** Through GitHub integration, `mayakilzy/repo-info` was readable and included `AgentCraft WealthForge`, `Craft_EduBridge`, `GeneralGH/GeneralGH.zip`, and other project folders. The `mayakilzy/saas-template` code was not accessible through the connected GitHub integration; its owner-provided architecture document was reviewed, not verified against running code. The Toolkit owner-provided operating guide was reviewed; direct repository inspection returned 404. The archive `GeneralGH.zip` was **not opened** and its contents are unknown.


## 15 — SaaS Template: default reusable core (architecture documented, not audited)

Owner-provided `SaaS Template.md` describes a base-image strategy: reusable versioned backend/frontend Docker images extended with only product-specific AI routes, background tasks and workspace UI, orchestrated through PostgreSQL and Redis. Its documented stack is Next.js 15 + TypeScript + Tailwind CSS; FastAPI (Python 3.11); Celery/Redis; PostgreSQL 16 with pgvector; Alembic; JWT/OAuth/Resend; OpenRouter, streaming, and Lemon Squeezy/Paddle/Stripe options. Documented shared facilities include authentication, admin, usage-credit ledger, provider webhook/idempotency, backups, restoration, monitoring, and migration. These are **claims in the supplied documentation, not independently verified production guarantees**.

For each **new SaaS** project, developers MUST: (a) check and record the pinned template revision; (b) inspect and test each reusable feature needed by the product; (c) prefer extension of the stable base over copying/rebuilding foundations; (d) use product-specific adapters for billing/usage, credit semantics, tenants and roles; (e) avoid forcing the template onto non-SaaS apps or mature projects with sound existing architecture; and (f) test upstream template updates in isolation before adopting a new base-image tag. **A usage credits ledger is not a financial double-entry ledger**; do not reuse it for account balances or wealth accounting. If a capability is only documented but not proven in this application's environment, record it as UNVERIFIED.

## 16 — Protected shared capabilities: AgentCraft-Toolkit

**Mandatory companion contract:** `TOOLKIT_READ_ONLY_CONSUMER_POLICY.md` (ship alongside this AADS standard and link it in every project `START-HERE.md` and agent instructions).

Canonical URL: https://github.com/mayakilzy/AgentCraft-Toolkit/blob/main/README.md

The owner's Toolkit operating guide documents seven indexed kits: ToolKit, SkillKit, McpKit, ApiKeyKit, PromptKit, PluginKit and AgentKit, with the **index-is-the-contract** read protocol. Before writing a new utility, the developer MUST search the current indexes for a suitable `promoted` component, read its requirements, license and documentation, and use it from the **application's own** repository/runtime if compatible. Store source SHA and verification evidence. `candidate`, `staged` and `archive` items cannot be treated as ready-made tools; MCP registrations/API catalogs do not imply executable server code or working credentials.

**NON-NEGOTIABLE OWNERSHIP RULE:** For **every ordinary development agent (including GLM/Codex) and every consumer application**, AgentCraft-Toolkit is **read-only**. No upstream changes of any sort: not files, indexes, PRs, tags, commits, cleanup or history. Only the independent, explicitly owner-authorized Toolkit maintenance project can modify it under its own authority. The upstream README describes historical writer clients (Miner/Agentic-OS); that documentation must **never** be interpreted as write permission for a consumer project. Enforce least-privilege GitHub and filesystem permissions, not merely a written rule. Any proposed shared-tool enhancement goes to the owner/maintenance system, never directly upstream.

## 17 — Safe end-of-session security closure (owner-triggered only)

**Mandatory companion document:** `UNIVERSAL_SECURITY_CLEANUP_AND_SAFE_SESSION_CLOSURE.md`.

The closure procedure is **inactive during ordinary development**, including group completion and visual reviews. It becomes active **only after the owner explicitly announces that development in the current session is finished**. At that point cease development, identify **session-owned** temporary processes/files and potential ephemeral secret copies, remove only confirmed nonessential session-generated temporary secret copies, and stop only confirmed session-owned temporary services not shared with other users or projects. **Never touch application code, operational `.env`, databases, volumes, Git history, commits/tags, shared credentials, or unrelated processes; never push or deploy.** Report facts and any credentials needing owner-led rotation without displaying secret values, then stop the session. On uncertain ownership, preserve and report. Never claim conversation history can be erased.

Both companion documents must be included in project starter/mission ZIPs as referenced global policy documents or exact version-pinned copies, without embedding secrets.
