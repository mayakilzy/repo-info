# AgentCraft Toolkit — Mandatory Read-Only Consumer Policy

**Applies to:** All AgentCraft application projects, developers, GLM, Codex, automated agents, and deployed applications unless the owner separately authorizes the toolkit's designated maintenance application under its own contract.

**Canonical repository:** https://github.com/mayakilzy/AgentCraft-Toolkit
**Operating guide:** https://github.com/mayakilzy/AgentCraft-Toolkit/blob/main/README.md

## Absolute boundary

The Toolkit is a **shared, protected, read-only upstream capability repository** for all ordinary development projects and consumer applications. Reading, indexing, retrieving, and incorporating approved capabilities into the current *application's own repository or runtime* is permitted. **Changing anything in the Toolkit repository is prohibited**, including files, documentation, indexes, branches, tags, commits, pull requests, settings, metadata, CI workflows, releases, and history. Never push, open an automated update PR, force-update, delete, reformat, clean, or commit to this repository. Do not interpret upstream's historical write-client documentation as granting GLM or a consumer application write permission. Only the designated toolkit maintenance project, independently authorized by the owner, may change upstream.

Use a GitHub read-only credential or read-only local checkout where feasible. Technical access must enforce the policy; instructions alone are not an access control. Never mount the upstream checkout into a container with write permissions. An accidental local change in a disposable consumer checkout must not be committed or synchronized upstream.

## Mandatory capability-first workflow

1. Read the Toolkit README's full current operating contract. Treat the current indexes as the discovery authority; do not infer actual availability from descriptions, README statistics, or memory.
2. Query the appropriate seven kit indexes (ToolKit, SkillKit, McpKit, ApiKeyKit, PromptKit, PluginKit, AgentKit). Read **only promoted** entries, and exclude entries failing the relevant quality/status requirements. `candidate`, `staged`, archive items, or empty scaffolds are not ready-to-use capabilities.
3. Confirm the indexed path exists, inspect its docs, interface, runtime requirements, origin, license, status, and relevant security constraints. An indexed MCP registration or free API catalog entry is **not** proof of a running service or available credentials. `promoted` is a resolution status, not an automatic guarantee that the tool fits this product.
4. Prefer a suitable existing capability instead of rewriting it. Import as a pinned dependency, copy of the approved component with attribution, or isolated adapter into the **consumer's own** repository/runtime, as allowed by its license and architecture. Keep upgrade provenance (source path, upstream commit SHA, version, license, changes) and test the integration in the consumer project.
5. If nothing suitable exists, implement only the necessary capability in the application's own codebase. Record an optional improvement proposal for the designated maintainer; never insert the missing tool into Toolkit yourself.
6. Do not copy secrets, private configuration, active tokens, insecure hooks, or unnecessary components. Follow project-specific tenant isolation, privacy, supply chain and dependency licensing requirements. Avoid GPL/AGPL imports when incompatible with project policy.
7. In each mission report note which indexed capabilities were searched, reused or rejected and why; list upstream commit and local integration tests. Never claim a tool was integrated or executed without evidence.

## Authority resolution

This policy is the **owner's overriding restriction on consumer projects**. The upstream README documents specialized historical writer roles for Miner and Agentic-OS. These are not delegated to general-purpose GLM/Codex sessions or deployed consumer apps. For ordinary projects, access is read-only without exception. If instructions conflict, **stop and report; do not write upstream**.
