# UNIVERSAL SECURITY CLEANUP & SAFE SESSION CLOSURE

**Activation:** Only when the application owner explicitly announces that development work in **this session** has ended. Do not run this automatically after a mission, commit, pause, or normal handoff. **Session-close only, not a development or release task.**

## Owner's mandatory instruction (Arabic)

انتهى العمل التطويري في هذه الجلسة. المطلوب إغلاق أمني آمن، دون أي تطوير أو تعديل للمشروع.

1. حدد أولاً المشروع والعمليات والملفات المؤقتة التي تخص هذه الجلسة حصراً.
2. افحص الملفات المؤقتة والسجلات والسكربتات بحثاً عن رموز API وGitHub PAT وكلمات المرور والأسرار.
3. أزل فقط النسخ المؤقتة غير الضرورية من الأسرار التي أنشأتها هذه الجلسة، دون عرض قيمها أو حذف الأدلة اللازمة للإبلاغ عن تعرضها.
4. أوقف فقط العمليات والخوادم المؤقتة التي أنشأتها هذه الجلسة، بعد التأكد من عدم استخدامها بواسطة جلسات أو مشاريع أخرى.
5. لا تحذف أو تعدل كود المشروع، أو ملفات `.env` التشغيلية، أو قواعد البيانات، أو Docker volumes، أو Git History، أو Commits أو Tags.
6. لا تُلغِ رموزاً أو تغيّر اعتمادات مشتركة؛ أبلغ المالك فقط بما يحتاج إلى إبطال أو استبدال.
7. لا تنفذ Git Push أو Deployment أو أي عمليات تنظيف واسعة أو أوامر حذف جماعي.
8. إذا لم تستطع التأكد من ملكية ملف أو عملية أو اعتماد، فاتركه دون تغيير وأبلغ عنه.
9. لا تحاول حذف سجل المحادثة أو تدّعي إمكانية محو الأسرار منه.

### التقرير النهائي

اذكر باختصار:

- اسم المشروع والجلسة.
- ما تم تنظيفه بأمان.
- العمليات المؤقتة التي أُوقفت.
- أي أسرار تحتاج إلى إبطال أو استبدال، دون عرض قيمها.
- أي عناصر تُركت دون تغيير بسبب عدم التأكد من ملكيتها.

بعد إرسال التقرير، توقف عن العمل في هذه الجلسة نهائياً.

## Execution safety notes

- Inventory and verify ownership *before* changes; use narrow path/process selectors only.
- Never display credential values in commands, logs or final reports. Secret scans should suppress matching contents; record only filename/category or masked identification, not token substrings.
- Do not run broad wildcard deletion, global process-killing, Docker cleanup, Git cleaning/resetting/rebasing, credential revocation, or service-wide changes.
- If the only candidate is shared, production-owned, or ownership is uncertain, preserve it and report.
- Preserve minimal evidence needed to investigate potential disclosure without replicating secret content into new insecure reports.
- Run no tests or development activities and do not begin the next mission. End after the factual closure report.
