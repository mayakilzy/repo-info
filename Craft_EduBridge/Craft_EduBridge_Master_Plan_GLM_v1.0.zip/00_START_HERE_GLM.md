# Craft-EduBridge — GLM developer master handoff v1.0

Repository: https://github.com/mayakilzy/Craft-EduBridge.git
Product: multilingual family learning companion; first real pilot child Tawfiq, grade 5, Turkish-medium school, Arabic-speaking guardian. Do NOT hardcode pilot assumptions. Parent/child access roles and multiple children are mandatory at schema level.

## Executive instruction
You are the implementing GLM engineer. Read ALL files in this package before coding, in order: `01_PRODUCT_BLUEPRINT.md`, `02_ARCHITECTURE_AND_DATA.md`, `03_BEHAVIOR_AND_PEDAGOGY.md`, `04_SECURITY_QUALITY.md`, `05_EXECUTION_PROTOCOL.md`, `06_MISSION_INDEX.md`, contracts, then group G01. Implement groups sequentially; STOP after each group and submit its completion report for owner/architect review. Never start the following group without explicit approval. Do not assume unprovided secrets, curricula, API keys or Kitap Bölücü source code. Implement adapter and fixture; ask for source only if genuinely required in relevant group. Use synthetic demo child data, never invent real school events.

## Principle
Understand before building. Build only proven necessary complexity. One Python FastAPI backend, one responsive React/TypeScript frontend; modular monolith, not swarm. Small codebase, strong tests, complete evidence. Keep no raw child data in prompts unless needed; mock AI by default in tests.

## Boot sequence
1. Inspect repository and git status; report if not empty or divergent; do not erase files.
2. Copy/extract mission documents under `docs/project/` if not already committed. Preserve these as governing specification.
3. Establish G01 foundations only. After G01 report, await review. At every group confirm git SHA, tests, security, and actual features demonstrated.

## Priority of authorities
Safety/privacy/data isolation > acceptance tests > product blueprint > architecture > mission text > incidental suggestions. Resolve conflict in report; do not silently rewrite frozen contracts.

## Final product outcome
Guardian registers household and child profiles; records actual school work through child check-in, school messages and manual confirmation; imports lessons from Kitap Bölücü; provides Turkish-first adaptive teaching with Arabic bridge; measures mastery using evidence; plans spaced reviews; offers Arabic guardian dashboard, calendar, multi-child and remote access foundations. Grade/language/country must be configurable per enrollment.
