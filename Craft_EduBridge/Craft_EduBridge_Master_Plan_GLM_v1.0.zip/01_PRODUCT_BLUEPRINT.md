# Product blueprint v1.0 — Craft-EduBridge

## Mission and boundaries
A family-centered educational companion supporting any number of children per household and distinct countries, grades, curricula and languages. First pilot is Tawfiq (age 11, grade five, school in Turkish, parent Arabic/English). All user-facing branding remains general. Child profile data is private. Application does not claim integration to Turkish government education records, EBA, e-Okul or school systems unless such integration is actually implemented and permitted.

## Three cooperating responsibilities
1. Learner tutor: age-appropriate explanations, scaffolded questions, hints, no blind answer-dumping, error recovery and encouragement. Default teaching language matches instructional language; optional bridge language translates/explains without replacing Turkish assessment terminology.
2. Guardian assistant: multilingual summaries and translated school messages, grounded recommendations, parent-confirmed calendar actions and appropriately calibrated indicators. Never invent school events.
3. Curriculum and evidence core: course/unit/lesson/skill graph, source provenance, scheduled vs actual lessons, assessment attempts, spaced reviews, auditable explanation of mastery.

## Core journeys
- Guardian creates household, parent account, child profile, enrollment, school locale/timezone, instructional and guardian languages. Child and parent have separate sessions/access.
- At check-in child is asked: 'What did you study at school today?' (Turkish localized for Tawfiq). Record an unconfirmed account first, optionally corroborate via notebook/school message/guardian. Planned schedule is NEVER presented as actual teaching.
- Child describes subjects/lessons and homework; assistant asks only the minimum clarification; drafts entries then confirms before marking as actual.
- For each lesson, retrieve approved curriculum excerpt with book/page citation; coach, assess, store evidence, propose follow-up.
- Guardian sees what was reported vs confirmed, what was tested vs not tested, upcoming confirmed school deadlines, and suggested 10-minute home activities.
- Guardian submits Turkish school message; assistant returns Arabic translation, actionable extraction and confidence/ambiguity; manual confirmation precedes reminders.
- Learner profile may be geographically remote; authorization is by household membership and scoped roles, not IP or assumed co-location.

## Product promises / non-promises
No surveillance, hidden location tracking, pressure streaks, public rankings, diagnostic psychology, fabricated numeric certainty, autonomous sending to teacher or school. Never imply that AI evaluation equals official school grades. A parent can delete/export household data. Standard child safety filters and guardian control apply.

## Languages, locality, curricula
Store UI locale, caregiver locale, preferred child language, instructional language, assessment language separately. Unicode and RTL/LTR fully supported. Country, academic year, local time zone, school stage, grade labels and curriculum version are records, not constants. A child may have multiple enrollment periods with historical snapshots. Language translations are aids and validated on pedagogical terminology.

## Pilot acceptance
A single household with Tawfiq and a synthetic sibling demonstrates 2 distinct profiles, zero data leakage, different grades/languages, true-vs-planned lesson separation, functioning PDF lesson import adapter, two demonstrable tutoring paths, assessment history, guardian summary and schedule. Running fully with mock LLM and fixtures must require zero paid accounts.
