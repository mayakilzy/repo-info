# GLM execution protocol — frozen

## Mission discipline
Execute one group at a time (G01 -> G10). Each group has multiple numbered tasks, prerequisites, deliverables, tests and stop gate. No speculative feature expansion, no swarm, no new services merely for abstraction, no files generated for every class. Prefer minimal integrated implementations and tests. Before each group inspect actual repo. Never destroy previously passing behavior or remove data without migration. Keep temporary development secrets out of reports.

## Group workflow
PRE-FLIGHT: git status/head, completed group report, constraints and any blocking missing asset. IMPLEMENT: code, meaningful tests, migrations, docs. VALIDATE: run commands and capture actual results, cross-tenant tests, demo flow. COMMIT: one or few logical commits; push to user repo if configured, never assume connectivity. REPORT: fill `templates/GLM_GROUP_REPORT.md`; stop. The user forwards group report to architect for acceptance/correction; only then continue.

## Escalation rules
If Kitap Bölücü source missing, build import adapter to manifest contract and use fixtures; no need to block. If Turkish book PDF missing, synthetic lesson fixtures; explicitly mark content unverified. If OpenRouter unavailable, use mock adapter; do not claim model quality. If database or runtime mismatches, propose smallest justified alternative and record deviation, don't silently replace entire stack. Significant design/security ambiguity => stop and report BLOCKED with exact evidence and narrow decision.

## Fixed review semantics
PASS = verified with commands/evidence; CONDITIONAL = partial with enumerated deviations; FAIL = safety/acceptance gate failure; BLOCKED = external dependency genuinely prevents next required action. Do not describe tests as passed if they were not run. After G10, complete end-to-end handoff and release checklist but no public production launch without guardian privacy review.
