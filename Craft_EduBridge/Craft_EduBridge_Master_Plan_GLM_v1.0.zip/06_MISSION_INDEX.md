# Execution plan — 10 groups / 50 tasks

- **G01** — Repository foundation: Initialize minimal backend/frontend, documented commands, CI and sample environment; typed configuration, mock provider and health endpoint.
- **G02** — Identity and family permissions: Users, family membership, child profile, enrollment and guardian/child authorization; DB migrations; seed two families two children.
- **G03** — Curriculum and import: Course/unit/lesson/skill persistence; manifest schema validation; PDF ZIP safe import, checksums provenance, retry and duplicate behavior.
- **G04** — Reality check-in and calendars: Child daily question in configurable language; school planned-vs-actual events; check-in statuses; guardian confirmation of deadlines.
- **G05** — Assessment evidence engine: Question/rubric/attempt storage; pre/formative/post/retention test; mastery estimate, confidence and reasons; minimal rules evaluator.
- **G06** — Tutor and retrieval: Cited lesson retrieval and pedagogical coaching; Turkish instruction + optional Arabic bridge; mock and guarded OpenRouter provider.
- **G07** — Parent dashboard and reports: Guardian localized dashboard per child, actions, calendar, evidence views, school gaps; printable concise report.
- **G08** — School messages and homework: Upload/enter teacher notices, translation + extraction, unconfirmed suggestions, approve-calendar flow; homework assist via photo/text pipeline with manual fallback.
- **G09** — Adaptive reviews and product UX: Prerequisite links, spaced-review schedule, short practice, child-friendly accessible design; multi-child navigation, RTL/LTR.
- **G10** — Pilot hardening and release handoff: E2E Tawfiq pilot fixtures plus sibling/cross-language/remote guardian, backups/export/delete, privacy readiness, install guide, coverage and performance.

The order is binding. Explicit architect review after each group. For every group review the scoped acceptance gate in its own file.
