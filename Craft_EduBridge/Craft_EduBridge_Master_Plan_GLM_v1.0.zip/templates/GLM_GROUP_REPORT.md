# GLM GROUP REPORT — GXX
Status: PASS / CONDITIONAL / FAIL / BLOCKED
Group / Tasks:
Repository / branch / initial SHA / final SHA:
Changed source files count / new dependencies / migrations:
Implemented features (only demonstrated):
Acceptance gate evidence (case -> command -> outcome):
Tests (exact commands, passed/failed/skipped totals):
Lint / typecheck / migration checks:
Security / tenant-isolation tests:
Demo instructions and synthetic fixture:
Privacy / child safety check:
Known limitations / deviations / external blockers:
Next group (NOT STARTED):
Git push verification:
