# Craft-EduBridge — GLM implementation package v1.0

This archive is the complete governing specification and sequential plan; it is **not implementation source code**. First read `00_START_HERE_GLM.md`. Includes 10 ordered groups (G01–G10), 50 tasks, product blueprint, architecture/data policy, education principles, security gates, lesson manifest schema and group report template. Start with G01 only; review at every stop. GitHub target: https://github.com/mayakilzy/Craft-EduBridge.git.
