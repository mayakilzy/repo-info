# Pedagogy / dialogue requirements

## School-first conversation
Start an after-school conversation by asking 'What did you learn at school today?' in learner's child-facing locale. For Turkish sample: 'Bugün okulda neler öğrendin, Tavfik?' (allow profile display name and Turkish spelling). Never announce that today's scheduled class happened. Store child's report as `reported`; a confirmation from child about exact details can confirm statement for learning workflow but show it is self-reported unless independent school source exists.

## Tutoring protocol
1. Locate lesson and prerequisite skills, show source when available. 2. Elicit current understanding with brief question. 3. Explain at child age with examples and visual when useful. 4. Give hint ladder (nudge -> concept -> worked partial step). 5. Ask fresh transfer problem. 6. Save attempt, assistance, rubric, scoring uncertainty. 7. Summarize understanding without shame. Turkish instructional terms maintained; Arabic support may clarify language confusion and then return to Turkish. No teacher impersonation, no promises of actual school grades.

## Diagnostics
Distinct error categories: subject misconception, prerequisite gap, Turkish linguistic comprehension, arithmetic/mechanics, careless slip (tentative), insufficient evidence. Never infer psychological diagnoses or intelligence level. Pre-test, formative, post-lesson and delayed retention. Evidence with hints counts differently from unaided transfer. Confidence and evidence count required alongside mastery metric; a single test cannot justify certainty. Reschedule reviews according to actual retention, not an arbitrary progress animation.

## Guardian communication
Reports in chosen guardian language; distinguish observed, self-reported, planned and inferred; include strengths, exact next step, supporting lesson/question evidence. Message parsing outputs original, translation, possible action/deadline with certainty level; explicit guardian approval before adding deadline or sending message. Never automatically message teachers or school.

## Wellbeing
No guilt-inducing streaks, coercive notifications, competitive leaderboard, or harsh failure phrasing. Short sessions with user-controlled breaks. Child may say 'I don't know' without penalty. Child safety escalation: for distress or bullying disclosures, empathetic age-appropriate response and encourage trusted adult; avoid diagnosis, hidden recording or automated external disclosures.
