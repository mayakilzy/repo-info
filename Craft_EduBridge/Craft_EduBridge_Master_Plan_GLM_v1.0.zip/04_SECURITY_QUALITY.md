# Non-negotiable security, privacy, quality gates

- Security by default: protected login with safe hashing, session revocation/logout; CSRF mitigation if cookie auth; secure cookies where applicable; authorization before DB reads/writes; anti-IDOR tests; sanitized log output; no credentials in repo, docs, screenshots, fixtures or prompts.
- Local demo with synthetic children only. Minimize underage personal data. Guardian controls exports/deletion including associated study history, logs retention policy, account membership and access revocation. No public child profiles, tracking or targeted ads.
- AI safety: teacher documents and learner uploads are untrusted content; prompt injection defenses; hard bounded file size and page counts; no arbitrary user-supplied external fetch/SSRF; validation, virus scanning or quarantine strategy before public deployment; explicit limits for OpenRouter cost and rate.
- Privacy compliance: before general release assess GDPR and Turkey KVKK as applicable, child consent/parental authority, data processing purpose, cross-border subprocessors, retention and age-related controls with competent review. Do not claim compliance solely from this document.
- Accessibility: keyboard accessible interface, age-appropriate contrast/font, RTL and LTR, localization. Portable use on mobile/desktop.
- Quality: unit/integration/e2e, SQL migrations, fixtures, static lint/typecheck, dependency pin/lock, reproducible setup, tests offline with mock provider, no unverified PASS claims.
- No progress metrics without denominators; record unknown values as null. Never invent school attendance, exams, assignments or scores.
- Group-level minimum: all impacted tests PASS; lint/type check PASS; migration upgrade/down and fresh-install verification; no critical/high security findings; precise reproducible test commands; clean git status; short walkthrough and SHA.
- Performance budget pilot targets (not fabricated measurements): local healthy API response under 500ms p95 for DB-only endpoints on development sample; tutor provider latency displayed distinctly; generated PDFs/indexing in async jobs where needed, bounded queue.
