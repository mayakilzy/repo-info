# MANARA — Page 01 Implementation-Ready Design Reference

This package reproduces the approved 1536×1024 MANARA Investigation Home layout using HTML/CSS and two image fragments from the **owner-approved original image**. It is a **visual implementation reference**, not an application replacement and not yet owner-accepted as pixel-identical.

## Contents
- `index.html` — semantic page layout and component structure
- `styles.css` — layout, tokens, breakpoints, mobile and RTL styles
- `script.js` — reference-only input validation, sidebar and EN/AR demonstration
- `assets/approved-home.png` — untouched approved image, authoritative reference
- `assets/lighthouse-scene.png` — cropped original artwork, including originally composited overlay details
- `assets/mountain-scene.png` — cropped original mountain promo artwork

## View
Open `index.html` in a modern browser. Fonts load from Google Fonts when online; fallback system fonts are supplied. Alternatively run `python -m http.server 8000` in this directory and open http://localhost:8000.

## Important accuracy and integrity notes
- The original approved illustration is a *composite flattened screenshot*. The lighthouse and network labels have not been independently recreated as live DOM nodes. The crop preserves those visual details as artwork; it may include residual composited elements. GLM should avoid duplicating baked-in artwork labels.
- The mountain promo crop contains source-image text under its overlay. A clean original asset would improve fidelity. Do **not** present the crops as original isolated artwork or claim exact pixel-level equivalence.
- Approved design screenshot includes interactive features unsupported by current backend, such as global search, notifications, fake profile/role switch. In this reference they are decorative/inert; **do not ship inert controls as functioning UI**. Follow OPEN-01..10 owner decisions in React adaptation.
- Reference form is **not** an API integration. `script.js` displays an explanatory note rather than claiming to create investigations. GLM must connect to the *existing* `POST /mold-factory/compose` flow with real validation, states and response handling.
- The approved screenshot includes three language options beyond current EN/AR scope; this reference retains EN/AR only.
- The source screenshot has visual noise and AI-generated text inconsistencies. Preserve the visual hierarchy while using approved functional copy and real state.

## React porting rule
Preserve structure, geometry, typography, artwork and styles wherever possible. Port to React components and bind actual API; don't replace with generic cards. Verify screenshot side-by-side with `assets/approved-home.png` at 1536×1024. Also verify Arabic RTL + mobile and long research questions (up to 1000 chars).

## Scope
**PAGE 01 ONLY.** Do not begin Page 02 until owner accepts Page 01. No frontend or backend source in this bundle should be treated as canonically deployed.
