# MANARA Page 02 — Investigation Workspace — executable visual source v1.0

## Status
**Supervisor-produced visual reference, not yet owner-accepted.** This HTML/CSS/JS package is intended to reduce visual reinterpretation by GLM. It reproduces the principal layout and visual hierarchy of the approved Investigation Workspace concept using editable DOM, CSS, SVG and local sample-only content. It is **not** the existing React app, and it does not provide real API data or workflow actions.

## Canonical original visual specifications
The binding master is included as `assets/approved-workspace.png`, from `MANARA_02_Home_Investigation_Memory.zip` → `VISUAL_ASSETS/02_Investigation/a_clean_modern_ui_ux_dashboard_screenshot_for_a_r.png`. Supplemental accepted concepts are included in `assets/`.

## Run
`python -m http.server 8765` from this folder; visit `http://localhost:8765/`.

## Contents
- `index.html`: standalone semantic layout; light sidebar; header; question panel; 13-state grouped horizontal stepper; Observatory SVG knowledge flow; real sidebar regions; sources panel.
- `styles.css`: all styling, responsive breakpoints, typography, bilingual RTL.
- `script.js`: EN/AR toggle, step inspection (sample only), graph node selection (illustrative only), mobile drawer.
- `assets/approved-workspace.png`: exact original image for side-by-side verification, never used as a full-page static backdrop.
- `assets/workspace-supporting-*.png`: supporting direction for implementation.

## Critical integration rules
1. **Do not iframe the HTML or overlay live controls on a screenshot.** Port DOM/SVG/CSS to React components while preserving design structure and proportions.
2. Replace every sample investigation, identifier, graph edge/node, insight, state and provider placeholder with **real supported data**, or an honest empty/loading/error state. All sample records here are explicitly marked illustrative; none claim to be genuine findings.
3. The 13 real FSM states are grouped into five visually horizontal phases (`Discovery`, `Build`, `Acquire`, `Synthesize`, `Deliver`). Actual current states and timestamps must come from the existing workflow API. Do not model transitions by clicking demo state pills.
4. Graph must use real claim/evidence/source associations (not this illustrative flow). Render pan, zoom, selection, edge details and list fallback with the actual UI API contracts. Preserve Observatory visual appearance, use graph library only as an implementation mechanism.
5. Approved screenshot contains Edit Question, Pause, Share, Export and other unsupported actions: do **not** fabricate them. Here they are absent or clearly disabled; maintain visual balance without misleading affordances.
6. Source-provider cards are layout examples, not declarations of integration; show real connection status from backend. Do not fabricate arXiv, PubMed, OpenAlex or Crossref source counts.
7. Preserve the existing Page 01 shared shell and real EN/AR translations; do not overwrite Page 01 fixes. The header/sidebar here illustrate intended information architecture, not a mandate to regress the already accepted shell.
8. For full audit trail and bitemporal replay, render only what backend supports and keep workflow history distinguishable from audit decisions. Avoid arbitrary caps and fictitious percentages.
9. Test desktop 1536×1024, desktop AR RTL, tablet 768×1024, mobile 375×812 English+Arabic; include actual populated and empty investigation states.

## Known reference differences from original screenshot
- Original depicts seven process *illustration* stages. This implementation shows **all 13 real states** grouped in five phases per OPEN-01, not exactly the original seven.
- Original depicts a cinematic, globe-like celestial graph. This reference uses an original editable CSS/SVG celestial flow with luminous curved lines and nodes. It preserves the visual identity but is **not pixel identical**; a production React visualization must be verified visually.
- Original has counts and progress values. Here those numbers are omitted, replaced with explicit sample labels to avoid fictitious scientific data.
- Icons here use local glyphs rather than approved bespoke icon assets; GLM may substitute visually equivalent accessible icons.
- Original includes features not supported by backend; unsupported controls are omitted or described in README.

## Deliver acceptance evidence
Approved image → rendered standalone HTML → actual React screenshots (matched viewport). Document material differences, CSS specifics and runtime behavior. Do not claim pixel-perfect based on a VLM statement alone.
