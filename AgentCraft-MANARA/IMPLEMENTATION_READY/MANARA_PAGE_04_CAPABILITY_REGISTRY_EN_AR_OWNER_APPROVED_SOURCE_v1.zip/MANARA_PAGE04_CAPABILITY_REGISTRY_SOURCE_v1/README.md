# MANARA — Page 04: Capability Registry | Owner-approved visual source v1.0

## Files
- `en.html` — independent **English-only LTR** entry point.
- `ar.html` — independent **Arabic RTL** entry point, Tajawal.
- `index.html` — redirects to English.
- `styles.css`, `app.js` — shared visual and demonstration behavior.
- `assets/lighthouse.svg` — original standalone decorative vector (not a screenshot as UI).
- `assets/approved-en.png` — exact owner-approved English design reference.
- `assets/approved-ar.png` — exact owner-approved Arabic (fifth) design reference.
- `assets/approved-ar-reference-screenshot.png` — the owner's screenshot selecting the fifth design (includes browser chrome; **not** an implementation asset).

## Preview
Open `en.html` or `ar.html` in a browser. For reliable local behavior use `python3 -m http.server 8080` and navigate to `/en.html` and `/ar.html`. No build dependencies.

## Visual integration rules
- Preserve page-level three-panel layout: Registry list, selected capability details, Capability Ecosystem relationship visual. Arabic mirrors the panel order through native CSS direction, sidebar on right; English sidebar on left.
- At <=760px, use true single-column stacking and a mobile navigation drawer.
- Fonts: Inter / Source Serif for English where appropriate, **Tajawal** for Arabic; Arabic direction native RTL; graph remains LTR spatially, its labels localized.
- This package is a **hand-authored HTML/CSS approximation** of the approved screenshots. It was not proven pixel-for-pixel identical with the approved artwork. Correct observable differences against `assets/approved-*.png` before React integration; do not change owner-approved composition.

## Fixture / truthful functionality boundary
All six capabilities, metadata, descriptions, versions, integrations, dependencies, and relationship nodes in `app.js` are **illustrative synthetic data**, NOT actual verified MANARA capabilities or live integrations. Functional local demo: search, category/status/domain filters, capability selection, details tabs, zoom, language switch, mobile drawer. Buttons for new capability, unrelated navigation and dependency links display a notice; they DO NOT invoke real services. The header and project are demo-only. Do not publish fixture statuses (e.g. “Connected”) as operational truth.

## GLM integration requirements
1. Inspect existing MANARA Capability Registry APIs and actual contracts. Replace fixtures with real capabilities, their types, tags, availability, configuration, dependencies, owners and revisions if exposed.
2. Preserve current app shell, routes, i18n system, and existing design tokens. **Do not duplicate the standalone shell** in React.
3. Only enable `New Capability` and activation actions if backend supports them and authorization exists. Never fake tool runs.
4. Wire graph edges to real relationships. Handle empty, loading, error, permission-limited and unavailable data explicitly. Any source-inventory or provider integrations must be truthfully represented.
5. Test 1536×1024 EN/AR; 768×1024 EN/AR; 375×812 EN/AR, scrolling, RTL, drawer, and graph labels. Desktop references are authoritative for exact visual alignment.
6. No automatic merge, no deployment, no modifications to previously accepted Pages 01–03 without owner approval.
