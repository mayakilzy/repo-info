# MANARA — Page 04 Visual Source Correction v2

Two **independent executable pages**, `en.html` and `ar.html`, with a shared visual stylesheet and functionality layer.

## Reference authority and scope

- `assets/approved-en.png` and `assets/approved-ar.png` are the **owner-approved visual designs** and always outrank the earlier v1 source.
- v2 is a new CSS/HTML/SVG implementation of the layouts, not a screenshot-as-UI. The lighthouse crops are purely decorative raster assets sourced from the approved screens; all cards, columns, forms, labels and graph objects are DOM/SVG.
- Some small stylistic differences between browser output and image-generation output may remain: review browser screenshots before claiming exact pixel parity. In particular, decorative art is partially cropped and fonts depend on Google Fonts availability.
- The standalone pages use **synthetic fixture content** so that visual review has populated sections. Do not ship fixture records as real registry data.

## Run

Open `en.html` and `ar.html` in a browser, or host this directory with `python -m http.server 8080` and visit `/en.html` and `/ar.html`.

## STRICT integration instructions for GLM

1. Reuse the HTML structure and CSS *unchanged*. Treat this package as presentation-layer source of truth, not a suggestion for recreating components.
2. Reuse the existing MANARA application shell without duplicating header/sidebar. If the shell is shared, remove only redundant outer wrapper and preserve the exact inner markup/classes and measurements.
3. Replace fixture data only via the documented adapter contract. Do not rewrite card/graph templates or replace SVG shapes with a different component library.
4. Add `window.MANARA_PAGE04_ADAPTER.listCapabilities()` (async) to provide real backend capabilities or call `MANARA_PAGE04.setCapabilities(items)` from the React host bridge. Keep fixture use limited to standalone visual review.
5. Map backend statuses honestly (active, beta, unavailable) and supply true relationships, versions, tests, integrations. Missing values show honest empty states rather than generated data.
6. Never assume `listCapabilities()` returned a record's relationships. The adapter should map real Graph complement/specialize/replaces/conflicts records to `relationships: [{id,name_en,name_ar,symbol,color}]` with semantically true labels. If unavailable return [] and show no invented graph relationships.
7. Arabic must be fully RTL with Tajawal and sidebar RIGHT. English fully LTR with sidebar LEFT. Do not mirror photographic artwork.
8. Test desktop 1536×1024 and small viewports 768×1024, 390×844, 375×812. Assert no horizontal overflow or clipped content in either language.
9. If a visual detail cannot be reproduced, report the precise delta. Do not call PASS without screenshot comparison.

## Data shape

```js
{
 id:'cap-id', name_en:'...', name_ar:'...', description_en:'...', description_ar:'...',
 type:'research', type_ar:'بحث', icon:'▤', status:'active',
 version:'v1.0.0', domain_en:'...', domain_ar:'...', updated:'2026-10-23',
 features_en:['...'], features_ar:['...'],
 relationships:[{id:'related-cap-id',name_en:'...',name_ar:'...',symbol:'▤',color:'#4c9bf0'}],
 versions:[{name:'v1.0.0',sub:'release date',tag:'Current'}],
 tests:[{name:'...',tag:'Passed'}], integrations:[{name:'...'}]
}
```

`window.MANARA_PAGE04.setCapabilities(items)` is the only required data injection API. Do not use sample content in production.
