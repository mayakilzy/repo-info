# MANARA — Page 03 Memory Explorer — Owner-Approved Visual Source v1.0

## What this is
A standalone responsive HTML/CSS/JavaScript visual reproduction of the MANARA Memory Explorer screenshot approved by the owner on 2026-10-22. It is a **reference implementation for pixel-comparison and React integration**, not a deployed MANARA application.

## Files
- `index.html`: accessible semantic regions matching the screenshot's navigation, evidence browser, celestial knowledge graph, selected item inspector, timeline and related topics.
- `styles.css`: English editorial layout, responsive breakpoints, Arabic RTL with **Tajawal**, cards, states, graph and typography.
- `script.js`: local, explicitly illustrative data for browsing and UI behaviors (no API); SVG graph panning, zooming and node selection.
- `assets/approved-memory-explorer.png`: immutable exact owner-approved generated 1536×1024 visual master; **never use as page background**.
- `assets/*.png`: small demonstration thumbnails cropped from the approved screenshot; not scientific images or verified source media.

## Run
From this folder: `python -m http.server 8765`, then visit `http://127.0.0.1:8765`.
Use the EN/AR switcher for a Tajawal RTL layout. Some controls are visual-only placeholders; they must not be presented as real live functionality in production.

## Integration contract for GLM
1. Read the project's universal delivery standard and final owner decisions first.
2. Start the standalone reference, capture the *same 1536×1024 viewport* and compare with `assets/approved-memory-explorer.png` **before altering React**. The source is a high-fidelity implementation attempt, not a guarantee of pixel-perfect matching; resolve meaningful gaps.
3. Preserve the screenshot's sidebar/topbar, title, left Evidence browser, center Knowledge Graph, right Selected Item with claims, bottom Timeline and Related Topics. Do not substitute generic dashboard cards.
4. Keep the live MANARA shell and navigation from approved Pages 01–02; make changes locally scoped to Page 03 and avoid regressions.
5. **Remove the fixture data**, including made-up evidence counts, source names, ratings, scores, graph topology, and chronology. Bind real `/memory/...` evidence/claims/relationships/decisions APIs and honest missing-data states. Do not assume the screenshot's Ocean Plastic Pollution story is scientifically factual or has been verified by external sources.
6. The graph nodes/edges and thumbnails in the reference are decorative illustrative fixtures. Connect graph selection, pan, zoom, list fallback to actual investigation-bound backend relations and identifiers; use accessible HTML fallback.
7. Implement bitemporal replay using documented `POST /memory/investigations/{id}/at-cutoff`, real user-set timestamp, and explicit cutoff semantics. The illustration's Timeline is not itself a verified bitemporal replay implementation. Never simulate history or animate false intermediate states.
8. Do not add fake global search, notifications, user profiles, provider health, authenticity labels, source rating/confidence percentages or unsupported CRUD. Use real backend operations only. Page 03 must respect single-tenant demo mode.
9. Ensure responsive EN/AR (Tajawal for Arabic), including desktop 1536×1024, tablet 768×1024, mobile 375×812. Do not mirror the entire SVG, image or graph artwork with `scaleX(-1)`.
10. Present the three-way visual evidence: owner-approved image → standalone HTML → actual React. Publish code in `mayakilzy/AgentCraft-MANARA` work branch and review reports/screenshots in `repo-info/AgentCraft-MANARA/IMPLEMENTATION_REVIEWS/`.

## Critical honesty note
The static reference includes invented names, years, counts, statuses, meters and relationships for **visual positioning only**. Nothing here should be cited as genuine science, a production result, or a verified source connection. When records are absent, use informative empty states rather than fabricated cards.

## Source notes
Exact visual master is the image generated/approved in the project conversation for the third page. Older original memory catalog and claim examination references remain supporting historical references, but this image is now the most recent owner-approved visual layout.
