# MANARA — Design System and Page Handoff (Review Draft)

## Authority and precedence
1. Source-of-truth functional specification: [MANARA_UI_UX_DESIGN_FOUNDATION.md](https://github.com/mayakilzy/repo-info/blob/main/AgentCraft-MANARA/UI_UX_DESIGN/MANARA_UI_UX_DESIGN_FOUNDATION.md); backend source and tests prevail over prose if inconsistent.
2. `MANARA_COMPONENT_API_BINDING_CLOSURE_v1.md` maps actions to the documented API.
3. `MANARA_VISUAL_FUNCTIONAL_RECONCILIATION_v1.md` flags visual-only, supported, future, remove and verify elements.
4. Visual images in this package determine aesthetic direction **only** and must never authorize undocumented features.

## Global approved direction
- Modern Knowledge Studio (light, editorial, lighthouse icon), with dark Intelligence Observatory panels.
- English default LTR, Arabic optional RTL, extensible translation keys. Original evidence remains unaltered.
- Palette guidance: Porcelain #F7F8F6, Ink #19334A, Teal #2C7380, Brass #BB9362, Mist #E8EFF1. Verify accessibility contrast.
- Desktop / tablet / mobile, keyboard, semantic labeling, reduced motion, focus states, accessible graph list fallback, target WCAG 2.2 AA.
- Fonts proposed: Source Serif 4 headings; Inter English UI; IBM Plex Sans Arabic UI (verify weights, layout and licensing).
- No real user settings, notifications, account avatar, billing, universal search, share or PDF export while current backend lacks these APIs.

## Page-specific aesthetic sources
- P01 Home: `VISUAL_ASSETS/01_Home/` lighthouse-based research question hero.
- P02 Workspace: `VISUAL_ASSETS/02_Investigation/` Studio / Observatory, actual FSM state must be shown.
- P03 Memory: `VISUAL_ASSETS/03_Memory/` contested evidence triad, timeline and bitemporal replay.
- P04 Registry: `VISUAL_ASSETS/04_Capabilities/` cards and relation detail; actual relationships only.
- P05 Foundry: `VISUAL_ASSETS/05_Foundry/` present-day three candidate sources; future connector wizard is backlog-only.
- P06 Mold Factory: `VISUAL_ASSETS/06_Molds/mold_factory_blueprint_dashboard.png` is preferred main design (prominent blue blueprint).
- P07 Agents: `VISUAL_ASSETS/07_Agents/` recipe catalog, session log and persistent MOCK labeling.
- P08 Foresight: `VISUAL_ASSETS/08_Foresight/` chart layout only when evidence permits; no invented probability distributions.
- P09 Publishing: `VISUAL_ASSETS/09_Publishing/` Concept 02 + Concept 01 reader; downloads MD/JSON/Text gated by `downloadable`.

## Core truthful UI rules
- Coverage is `NONE`, `CATALOG`, `OPERATIONAL`, or `VERIFIED` per need; never conflate catalog listing with operational verification.
- `is_mock=true` must have prominent permanent MOCK warning and output treatment.
- `method=insufficient_evidence` must not display a quantitative probability forecast.
- `leakage_detected=true` must show leaked evidence IDs and a failed backtest warning.
- `quality_gate_passed=false` shows `quality_gate_issues[]`, disable download if `downloadable=false`.
- `coverage_blocker_report` is a gap document, not a verified research dossier.
- Source Foundry only has OpenAlex connector path; Crossref and arXiv catalog-only under existing backend.

## Outstanding acceptance gates
1. Source-review unresolved `GET` vs `POST` workflow state read; confirm source implementation and response.
2. Validate graph read-side availability: only render API-backed nodes/edges, otherwise accessible lists.
3. Confirm mold-blueprint relation availability and display graceful fallback.
4. Test actual navigation/state links for absent accounts/roles and unsupported features.
5. Complete screenshot-level validation of mobile, tablet, RTL, partial-data, source-outage and failed quality gate.
6. Execute API schema contract and live browser end-to-end tests after implementation authorization, not during design.
7. Obtain explicit owner approval of final manifest, exclusions and remaining backlog before writing React or assigning GLM implementation.
