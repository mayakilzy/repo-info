# MANARA — Visual-to-Functional Reconciliation v1.0

**Date:** 2026-10-20  
**Status:** Design reconciliation draft for owner approval. **Not an authorization to implement.**  
**Scope:** All nine approved page directions; Studio and Observatory; English-default LTR and Arabic RTL; desktop/tablet/mobile.  
**Basis:** `MANARA_UI_UX_DESIGN_FOUNDATION.md` sections 5–12 (GitHub), `MANARA_COMPONENT_API_BINDING_CLOSURE_v1.md`, and the approved visual concepts in this conversation. **The actual API routes have not been exercised in a running deployment.**

## 1. Classification contract

| Code | Decision | Binding rule |
|---|---|---|
| **A — Implement now** | Supported in foundation's API mapping | Use named endpoint and real returned fields; include loading/error/empty/permission-confirmation as applicable. |
| **V — Visual/local only** | Pure presentation, navigation, local view mode or locale | No implied server persistence, search, user identity or live event. |
| **F — Future/backend expansion** | Valuable requested SaaS capability without current supporting API | Document in enhancement backlog; no working control or misleading demo. |
| **X — Remove/replace** | Mockup element misleading, unsafe, contradicted or not supported | Remove, or replace with a supported element specified below. |
| **Q — Verify** | Foundation ambiguity or missing read contract | Keep design concept; block specific action until endpoint/payload validated against actual source. |

**Visual preservation rule:** maintain the approved lighthouse mark, soft porcelain canvas, navy/teal/gold palette, calm editorial cards and dark Observatory panels. Never change these to solve a missing API; change the relevant affordance instead.

## 2. Global shell and design-system reconciliation

| Mockup element | Class | Correct treatment |
|---|---|---|
| MANARA logo / lighthouse artwork / tasteful ambient network illustration | V | Preserve from approved home; illustrations must not be confused with graph data. |
| Collapsible left sidebar, breadcrumb, drawers, tabs, local filters of already-loaded data | V | Responsive and keyboard accessible; role grouping for navigation, NOT authorization. |
| English/Arabic toggle | V | **English default** explicitly overrides foundation's browser-language suggestion; Arabic RTL; original evidence content untranslated. |
| Studio/Observatory mode | V + Q | Switch between representations of *the same* verified payload; no fabricated nodes/edges; list alternative for accessibility. |
| `GET /status` indicator / `tenant_demo` environment disclosure | A | Nonintrusive and honest; show build/capability limits only from real payload. |
| Global search bar promising search across everything (`Ctrl+K`) | F/X | Remove universal-search promise; use page-scoped search only where endpoint exists (registry), or explicit local list filter. |
| Personal profile/avatar, account panel, login, role permissions, tenant switcher | F/X | Current backend has no multi-tenant auth; do not present working account controls. |
| Notification bell, sharing link, subscription/billing | F/X | Not live; reserve backlog only. |
| Accessibility / focus / error states / reduced motion | V | Ship as frontend design behavior without inventing data. |
| Summary counters, global quality percentages, speed charts, timestamps in generated images | X | Replace with real result fields or explicit SAMPLE DATA labels in design docs only. |

## 3. Page-by-page decision register

### P01 — Investigation Home — Home Concept 01

| ID | UI element | Class | Decision and binding |
|---|---|---|---|
| H-01 | Hero lighthouse and editorial composition | V | Preserve exactly as visual inspiration; decorative network is not evidence. |
| H-02 | Question textarea / clear / character guard | V | 10–1000 characters; validation in client; keyboard submit safely. |
| H-03 | Start Investigation | A | `POST /mold-factory/compose`, then navigate with returned `investigation_id`; display returned coverage/gaps. |
| H-04 | Introductory workflow explanation | V | Static copy: analyze needs → check coverage → create investigative mold. |
| H-05 | Synthetic discovery example | A | `GET /discovery`; must explicitly state **SYNTHETIC**. |
| H-06 | Recent investigations/personalized suggestions/universal search | F/X | No supported list of investigations or live personalized prompts established. |
| H-07 | Search failure/partial coverage | A | `is_complete`, `is_catalog_complete`, `is_unknown_domain`, `deliverable_type`, `gaps[]`; preserve query on retry. |

### P02 — Investigation Workspace — Observatory Concept 02 + graph concept 01

| ID | UI element | Class | Decision and binding |
|---|---|---|---|
| IW-01 | Question/title, 13-state workflow (not 7/12 visual shortcuts) | A | `GET /mold-factory/investigations/{id}/workflow`; user-triggered `POST /.../transition` only; show `blocker` when rejected. |
| IW-02 | Workflow POST read variant | Q | Foundation lists both POST and GET `/.../workflow`; verify handler signatures and usage, default to documented GET read only after code validation. |
| IW-03 | Evidence list and attachment | A | `GET /memory/investigations/{id}/evidence`, `POST /memory/evidence`, `POST /memory/evidence/{id}/claims`. |
| IW-04 | Prior evidence search, decisions | A | `POST /memory/investigations/{id}/search-prior`, `GET /memory/investigations/{id}/decisions`; real freshness/audit. |
| IW-05 | Agent session and tool events | A | `POST /agents/resolve`, `POST /agents/sessions`, `POST /agents/sessions/{id}/execute`, `GET /agents/sessions/{id}`; display `is_mock`, `granted_tools`, invocation statuses. |
| IW-06 | Dark knowledge network | Q | Only draw API-supported, associated evidence/claim/support relationships; do not imply arbitrary graph traversal endpoint exists. Offer list/table fallback. |
| IW-07 | Source/result counts, confidence, progress percentages | X | Only derive from real enumerated records; no simulated progress or confidence. |
| IW-08 | Share, PDF export, edit investigation question, pause workflow | F/X | Remove unless specific supported API later exists; true agent termination remains available in agent session. |
| IW-09 | Complete and download | A | `deliverable_ready` is not enough: publication `downloadable=true` required; formats markdown/json/text. |

### P03 — Capability Registry — Concept 01

| ID | UI element | Class | Decision and binding |
|---|---|---|---|
| CR-01 | Cards/details/status and domain filters | A | `GET /registry/capabilities`, `GET /registry/capabilities/{id}`; show candidate/approved/rejected and missing connectors. |
| CR-02 | Semantic search / coverage needs matrix | A | `GET /registry/search?q=...`, `GET /registry/search/coverage?q=...`. |
| CR-03 | New capability, seed 8 | A | `POST /registry/capabilities`, `POST /registry/capabilities/seed` (seed action dev/admin only). |
| CR-04 | Promote, delete, reindex | A | `PATCH /registry/capabilities/{id}/promote`, `DELETE /registry/capabilities/{id}`, `POST /registry/capabilities/{id}/reindex`. |
| CR-05 | Evaluations and relationship detail | A | `GET`/`POST /registry/capabilities/{id}/evaluations`; `GET`/`POST /registry/capabilities/{id}/relationships`. |
| CR-06 | Large prepopulated catalog, scores, universal “use in agent” | X/F | Display only actual catalog and links; no direct invocation absent API. |
| CR-07 | Interactive relationship diagram | A/Q | Only stored relationships retrieved for selected capabilities; avoid pretending global graph endpoint exists. |

### P04 — Source Foundry — Concept 01 plus lifecycle Concept 02

| ID | UI element | Class | Decision and binding |
|---|---|---|---|
| SF-01 | Source candidate list and details | A | `GET /foundry/candidates`, `GET /foundry/candidates/{id}`. |
| SF-02 | Discover / Assess / Register Connector / Test / Approve / Quarantine | A | Corresponding `POST /foundry/candidates/{id}/{discover,assess,register-connector,sandbox-test,approve,quarantine}`. |
| SF-03 | OpenAlex test | A | Only supported connector in baseline; label live **not live-tested**; handle 429/rate limits and SSRF exceptions. |
| SF-04 | Crossref and arXiv | A (catalog), X (test) | PLANNED, disable register/test actions until connector code exists. |
| SF-05 | API key, OAuth, paid subscription, institutional and custom connector wizard | F | **Owner-approved product requirement**; write backend design specification first; no active wizard in current build. |
| SF-06 | Extra providers and connected flags in visual mockups | X | Do not imply PubMed, Scopus, World Bank or others are already wired. |
| SF-07 | Rights/license, allowed hosts, data geography/language | A | Read from candidate metadata; no fabricated usage budgets or quality percentages. |

### P05 — Memory Explorer — first visual + claim examination concept

| ID | UI element | Class | Decision and binding |
|---|---|---|---|
| ME-01 | Investigation-scoped evidence/claim list | A | `GET /memory/investigations/{id}/evidence`, `GET /memory/investigations/{id}/claims?verdict=...`; keep search scope explicit. |
| ME-02 | Full evidence detail | A | `GET /memory/evidence/{id}`; `stored_at_ref` is opaque reference, not browser URL. |
| ME-03 | Supporting / refuting / qualifying evidence display | A/Q | Support links can be added via `POST /memory/claims/{id}/support`; **verify relationship read payload** to ensure all three columns can be populated without guessing. |
| ME-04 | Verdict update | A | `PATCH /memory/claims/{id}/verdict`, confirmation and audit context. |
| ME-05 | Prior reuse, snapshots, replay, audit | A | `POST /memory/investigations/{id}/search-prior`, `/reuse`, `/memory/snapshots`, `/at-cutoff`, `GET /decisions`; proper bitemporal semantics. |
| ME-06 | “Global knowledge explorer” universal search, confidence 92%, cross-investigation metrics | F/X | No general memory full-text search endpoint confirmed; avoid inflated certainty. |
| ME-07 | Observatory evidence graph | Q | Use actual nodes and returned edges or scope view to available relationships; accessible tabular alternative. |

### P06 — Mold Factory — **Approved Concept 02 dark blue blueprint**

| ID | UI element | Class | Decision and binding |
|---|---|---|---|
| MF-01 | Mold library with state/domain filters | A | `GET /mold-factory/molds`, `GET /mold-factory/molds/{id}`; temporary/reusable/maintained/archived. |
| MF-02 | Promote/archive | A | `PATCH /mold-factory/molds/{id}/promote`, `POST /mold-factory/molds/{id}/archive`; confirmation. |
| MF-03 | Gap analysis | A | `GET /mold-factory/molds/{id}/gaps`, render NONE/CATALOG/OPERATIONAL/VERIFIED accurately where present. |
| MF-04 | Dark blueprint connected needs/capabilities | A/Q | Build only from selected mold's actual capability IDs and gap details; **verify read contract contains complete need→capability links**. |
| MF-05 | Arbitrary mold editor / clone / version rollback | F/X | Not in current endpoints; remove action despite mockup controls. |
| MF-06 | Add paid source to close gap | F | Link to documented backlog, not a currently executable button. |

### P07 — Agent Registry — Concept 02 detail + Concept 01 Observatory

| ID | UI element | Class | Decision and binding |
|---|---|---|---|
| AR-01 | Agent recipe list/detail | A | `GET /agents/recipes`, `GET /agents/recipes/{id}`. |
| AR-02 | Load seed generalist/clinical recipes | A | `POST /agents/recipes/seed-generalist`, `POST /agents/recipes/seed-clinical`; do not fabricate 8 working agents. |
| AR-03 | Resolve, instantiate, execute, terminate, evaluate | A | `POST /agents/resolve`, `POST /agents/sessions`, `/execute`, `/terminate`, `/evaluate`; session via `GET /agents/sessions/{id}`. |
| AR-04 | Mock watermark and invocation outcomes | A | Always show `MOCK EXECUTION` when `is_mock=true`; exact statuses from result. |
| AR-05 | Promote recipe, edit, clone, export configuration, success rate dashboard | X/F | No promote endpoint; performance stats only if actual exposed data. |
| AR-06 | Tool permissions | A | Use `granted_tools` on each session; recipe `allowed_tools` is not same as granted permissions. |

### P08 — Foresight — Hybrid Concepts 01 + 02

| ID | UI element | Class | Decision and binding |
|---|---|---|---|
| FO-01 | Assess evidence first | A | `POST /foresight/assess`; if `recommended_method="insufficient_evidence"`, show reason and hide quantitative controls. |
| FO-02 | Draft/publish/revise/detail | A | `POST /foresight/forecasts`, `/publish`, `/revise`; `GET /foresight/forecasts/{id}`; published immutable. |
| FO-03 | Backtest figures | A | `POST /foresight/backtest`; only real MAE/RMSE/baseline improvement; negative improvement clearly highlighted. |
| FO-04 | Temporal leakage | A | `leakage_detected=true` is blocking warning; display `leaked_evidence_ids[]` and cutoff outcome. |
| FO-05 | Probability doughnuts and scenario lines | A/Q | Render only if returned distribution/scenario fields justify; NEVER on `insufficient_evidence`. |
| FO-06 | Global forecast list, arbitrarily many scenarios, PDF/chart downloads, scenario editor | F/X | No forecast list API in foundation's foresight router; avoid globally browsable forecast catalog promise. |
| FO-07 | “Try Modify” regression demo | A (dev only) | Not an ordinary edit control; omit from researcher production experience. |

### P09 — Publishing — **Concept 02 plus Concept 01 reader**

| ID | UI element | Class | Decision and binding |
|---|---|---|---|
| PU-01 | Publication library and details | A | `GET /publishing/publications`, `GET /publishing/publications/{id}`. |
| PU-02 | Create dossier / presenter / storyboard | A | `POST /publishing/publications` with supported output types; show content structure by type. |
| PU-03 | Quality gate status, issues, preview | A | From `GET /publishing/publications/{id}`; not from nonexistent standalone quality gate endpoint. |
| PU-04 | Download | A | `GET /publishing/publications/{id}/download?format=markdown|json|text` **only when `downloadable=true`**. |
| PU-05 | Coverage blocker report | A | Clearly label `deliverable_type="coverage_blocker_report"`; even if downloadable, not a research result. |
| PU-06 | Rights warning on storyboard | A | Display `rights_status` and `disclosure_text`; unknown/restricted must be conspicuous. |
| PU-07 | PDF, public share, online collaborative editor, versions, teleprompter playback | F/X | Current backend doesn't establish these; supported presenter cue sheet remains readable data. |

## 4. Cross-cutting cases that MUST be shown in delivery mockups

1. Loading, empty, success, server/network error, partially fulfilled coverage, source unavailable, approval confirmation, insufficient evidence, investigation complete.
2. `is_mock=true` visible as yellow banner AND clearly marked output (no implied live LLM).
3. `quality_gate_passed=false` with **verbatim** `quality_gate_issues[]`; disable download if `downloadable=false`.
4. `deliverable_type=coverage_blocker_report`, visually distinct from research dossier; respect `downloadable` field.
5. `rights_status=unknown|restricted`, `leakage_detected=true`, `transitioned=false` and `blocker`.
6. Evidence verdict `candidate|supported|contested|refuted|superseded`; preserve conflicting sources.
7. Arabic RTL on data-rich page; ensure source IDs, DOI, API tokens and original source paragraphs remain bidirectionally stable.
8. Mobile investigation, tablet mold blueprint, Arabic memory evidence; no functional controls clipped by viewport.

## 5. Open verification blockers before GLM implementation

| Code | Severity | Verification target | Safe provisional treatment |
|---|---|---|---|
| Q01 | HIGH | `GET` vs `POST /mold-factory/investigations/{id}/workflow` semantics and request/response models | Use GET for read display only after source verification. |
| Q02 | HIGH | Evidence-support relationship read shape for claim detail and graph | Draw three evidence groups only when read payload contains these relations. |
| Q03 | HIGH | Need→capability edge data for Mold Blueprint | Show verified rows/matrix if full graph input cannot be retrieved. |
| Q04 | HIGH | Actual graph node/edge read capacity in Registry and Memory | Use scope-limited diagrams and list fallback. |
| Q05 | HIGH | Exact publication download enum and handling of blocker reports | Map formats to actual contract; gate solely by `downloadable`. |
| Q06 | MEDIUM | `GET /status` payload, deployment mode and role UI conventions | Environment badge, no faux authenticated profile. |
| Q07 | MEDIUM | Query filters and pagination availability by route | Local filtering only where all loaded data; never pretend server paging. |
| Q08 | HIGH | Source/provider licensing/permissions and future paid integrations | Future requirements only; do not store keys in browser. |
| Q09 | MEDIUM | Current visual references and filename/source-of-truth selection | Create asset manifest for each approved image, record original paths and approval notes. |
| Q10 | MEDIUM | State set on every page and keyboard/mobile behavior | Record per-page visual QA, use 7-state baseline where applicable. |

## 6. Explicit owner-approved future SaaS backlog (NOT a frontend implementation request)

- Extensible source connectors: free API, API keys, OAuth, licensed subscription and institutional access, with secret vault, rights, quotas, usage billing and isolation.
- Proper multi-tenant sign-in, real roles, user profile/preferences persistence and auditable authorization.
- Notifications and user dashboard if supported by new APIs; cross-resource search where separately specified.
- Rich publishing exports (PDF), sharing, and publication editing only through later scoped features.
- Expanded agent management (create/edit/clone/promote) only following an approved backend feature proposal.

## 7. Handoff acceptance checklist

- [x] Reconciliation classes established.
- [x] Nine-page actionable decision register drafted.
- [x] Existing vs future functional boundaries identified.
- [ ] Actual repository route signatures independently checked against running code.
- [ ] Full approved visual asset manifest with image checksums created.
- [ ] Every action traced to request model + response field + error UI state.
- [ ] Graph read contracts Q02–Q04 verified, fallback approved.
- [ ] Per-device/locale visual mockups inspected and final approved.
- [ ] Owner approval of this reconciliation and final design package.

**Release gate:** Reconciliation approval is a DESIGN milestone. It must not be interpreted as authorization to code React or expand the backend until the owner expressly authorizes the implementation phase.
