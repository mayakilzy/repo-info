# MANARA — Visual Design Handoff Assembly v1.0

**STATUS: REVIEW PACKAGE / NOT READY FOR GLM IMPLEMENTATION.**

This is a consolidated visual reference bundle, not source code. It includes actual inspected image files from the current session, three prior design-audit markdown documents, image SHA-256 manifest, design rules and handoff checklist.

## How to use
- Start with `DESIGN_SYSTEM_AND_PAGES.md` for visual authority and design guardrails.
- Open `VISUAL_ASSET_MANIFEST.md` to identify each image and its approval class.
- Use the approved images as compositional/aesthetic references only; do not reproduce fabricated sample numbers and controls.
- Use `MANARA_COMPONENT_API_BINDING_CLOSURE_v1.md` and `MANARA_VISUAL_FUNCTIONAL_RECONCILIATION_v1.md` to decide whether each interactive control is actually supported.
- Backend foundational document: https://github.com/mayakilzy/repo-info/blob/main/AgentCraft-MANARA/UI_UX_DESIGN/MANARA_UI_UX_DESIGN_FOUNDATION.md
- Backend verification folder: https://github.com/mayakilzy/repo-info/tree/main/AgentCraft-MANARA/BACKEND_VERIFICATION_01

## Key limitations
Images are conceptual and contain fictitious datasets, labels, and actions. Some essential screen states remain to be finalized. Backend routing descriptions are not a substitute for testing live source. Paid-source integration and full SaaS accounts remain **future enhancements**.

## Deliverable status
- Asset collation and manifest: complete.
- Core directions and mapping: documented.
- Final owner approval: pending.
- Runtime/API contract verification and pixel-perfect/state-image closure: pending.
- GLM coding authorization: **not granted**.
