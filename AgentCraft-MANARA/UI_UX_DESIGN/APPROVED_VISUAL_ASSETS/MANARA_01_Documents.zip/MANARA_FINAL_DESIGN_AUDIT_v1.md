# MANARA — Final Design Audit & Handoff Preparation v1.0

**Date:** 2026-10-20  
**Phase:** Design audit, before GLM implementation  
**Decision authority:** Project owner  
**Status:** Preliminary audit prepared; functional sign-off and final asset inventory pending.

## 1. Approved visual baseline
- Home: Modern Knowledge Studio, original lighthouse concept 01.
- Investigation Workspace: Studio plus Observatory investigation-flow concept 02; graphical relationships from concept 01, only where grounded in real data.
- Memory Explorer: evidence-oriented studio; Claim Examination, supporting/refuting/qualifying evidence, temporal replay; Observatory where supported by returned records.
- Capability Registry: card catalog plus detailed capability view, state/readiness and grounded relationships.
- Source Foundry: concept 01 layout with lifecycle visualization from concept 02.
- Mold Factory: concept 02, large dark-blue blueprint panel.
- Agent Registry: concept 02 card/details layout combined with concept 01 Observatory styling.
- Foresight: hybrid concepts 01/02; backtest/insufficient evidence/leakage states remain to finish.
- Publishing: concept 02 framework plus concept 01 report reader; quality gate and blocker report distinction must be finalised.
- Visual theme: Modern Knowledge Studio (primary), Intelligence Observatory (analysis surfaces), original lighthouse logo; cream, navy, teal, understated gold.
- Languages: English default (explicit owner decision supersedes foundation browser-locale suggestion), Arabic second, full RTL/LTR; future i18n extensibility.
- Devices: desktop, tablet, phone; keyboard accessibility, target WCAG 2.2 AA.

## 2. Source-of-truth hierarchy
1. Backend source and verified API reference for actual capabilities and response fields.
2. `MANARA_UI_UX_DESIGN_FOUNDATION.md` for page map, honest data indicators and design contract, unless contradicted by code.
3. Owner-approved visual concepts for appearance only.
4. This audit for exclusions, gates and open verification questions.

## 3. Page audit matrix
| Page | Primary content | Required honest states | Implementation caution |
|---|---|---|---|
| InvestigationHome | Question (10–1000 chars); POST /mold-factory/compose | unknown domain, partial coverage, blocker report | Not a chatbot, no generic search engine or user profile |
| InvestigationWorkspace | 13 FSM states, needs, sources, evidence, sessions, publications | mock, blocked transition, coverage, failed source, gate | Never auto-advance states or invent progress percentages |
| RegistryBrowser | capability cards/search/coverage/evaluations/relationships | candidate/approved/rejected, no connector | No unsupported update endpoint; no invented connectors |
| FoundryBrowser | candidate lifecycle, licenses, rights, sandbox tests | planned, quarantined, rate-limited, SSRF | OpenAlex only assessable live candidate; Crossref/arXiv catalog only |
| MemoryExplorer | evidence, claims, opposition edges, bitemporal replay, decisions | contested/refuted, provenance, dedupe/freshness | No universal credibility score, graph edge or search mode without grounding |
| MoldFactoryView | recipes, state, domain, capabilities, gap analyses | NONE/CATALOG/OPERATIONAL/VERIFIED | Lifecycle is temporary/reusable/maintained/archived, not agent templates |
| AgentRegistry | recipes, resolve, seed, sessions, execute, evaluate, terminate | is_mock, tool invocation statuses | No agent recipe promotion/edit/clone unless a real endpoint exists |
| ForesightView | assess, drafts/publish/revise, backtest | insufficient evidence, leakage, worse than baseline | No fabricated probabilities or timelines; published forecast immutable |
| PublishingView | research dossier, presenter edition, storyboard, downloads | coverage blocker, quality gate, rights restrictions | Markdown/JSON/Text only; use downloadable flag; no PDF or share API |

## 4. Explicit functional exclusions in current build
- No signup/login/account/profile/real RBAC or authenticated user dashboard; `tenant_demo` single-tenant mode.
- No persistent user-linked preferences, billing, paid source subscription administration, or notification service.
- No general upload API, rich text publication editor, share links, or PDF export.
- No universal agent builder/recipe promote endpoint (`PATCH /agents/recipes/{id}/promote` absent).
- No `GET /publishing/publications/{id}/quality-gate`; quality fields are read from publication detail.
- No UI claim that live Z.AI execution was verified or that Crossref/arXiv source tests are implemented.
- No global success rates, source scores, confidence probabilities, source counts or fabricated relationships solely because they appear in illustrative images.

## 5. Data truthfulness checks (must bind to real response fields)
- `is_mock`, `execution_mode`; tool status: `executed`, `denied_not_in_granted_set`, `not_implemented`, `error`.
- `coverage_level`: NONE/CATALOG/OPERATIONAL/VERIFIED; `is_complete`, `is_catalog_complete`, `gaps[]`.
- `claim.verdict`: candidate/supported/contested/refuted/superseded. Preserve supporting/refuting/qualifying edges, no artificial consensus.
- `evidence`: source ID, checksum, `observed_at`, `published_at`, `ingested_at`; temporal replay via at-cutoff API.
- `forecast`: insufficient_evidence outcome, leakage_detected, data_cutoff_verified, baseline comparison, version chain.
- `publication`: deliverable_type, quality_gate_passed, quality_gate_issues, downloadable, storyboard scene rights_status.
- `workflow`: current state, transitioned, blocker; no invented background execution progress.

## 6. SaaS design quality gates
- Responsive breakpoints are guidelines; validate layout at representative narrow mobile, broad mobile, tablet portrait/landscape, laptop, desktop, 200% zoom and reduced motion.
- Navigation: desktop sidebar, tablet drawer/compact, mobile drawer or bottom navigation only for supported destinations.
- English default; Arabic full RTL via logical CSS; preserve direction of DOI, URLs, source text, ID strings, code, numeric axes and chronological timelines.
- Every UI string i18n-keyed; fallback to English for future missing locale strings; display source content untranslated unless explicitly supported.
- Keyboard navigation/focus rings, screen reader names, color-independent statuses, contrast, text resizing, 44px minimum target aim where practicable.
- Error response: retain investigation ID/context, render user-safe error message and expandable trace_id, retry the correct operation without duplicate side effects where possible.
- Loading, empty, success, partial, error, source unavailable, approval/confirmation, insufficient evidence, mock, complete, gate failure, coverage blocker all need named UI examples.
- Poll agents/workflow via HTTP, no fabricated WebSocket; no percent progress without measurable source.

## 7. Known conflicts/verification items
1. Foundation AC says 36 capabilities, section 5.2 enumerates 36 rows but §5.3 displays '32 catalogued + 4 cross-cutting' and totals its tier table to 32; audit against functional catalog and actual source before publication.
2. Foundation says 67 API endpoints across 10 routers; this should be source-verified before final handoff.
3. Foundation §12 recommends browser-language default; explicit owner approval overrides: English default, Arabic optional.
4. `coverage_blocker_report` suggested download enabled in some text, but rendering must obey actual `downloadable` field and quality gate status.
5. In some mockups the source registry and agent tools appear vastly larger than the known seed inventory; all placeholders must be marked as illustrative or replaced with valid fixture data.
6. Graph visualizations may imply backend graph queries not present. Verify data available from specific list/detail endpoints or mark view a local visualization of returned edges only.
7. Source subscription/API key onboarding is approved as future enhancement, not existing API behavior. Add separate backend scope and security requirements.
8. Verify whether UI's extra role-switcher can be visual-only without suggesting real authorization; avoid pseudo-account/profile.

## 8. Final handoff package structure (planned; not yet complete)
```
MANARA_UI_UX_FINAL_HANDOFF/
  00_README_AND_APPROVAL_STATUS.md
  01_DESIGN_SYSTEM.md
  02_PAGE_SPECIFICATIONS.md
  03_COMPONENT_LIBRARY.md
  04_INTERACTION_STATES.md
  05_API_BINDING_MATRIX.md
  06_RESPONSIVE_AND_I18N.md
  07_TRUTHFULNESS_AND_LIMITATIONS.md
  08_BACKEND_ENHANCEMENT_BACKLOG.md
  09_VISUAL_ASSET_MANIFEST.md
  10_GLM_IMPLEMENTATION_ACCEPTANCE.md
  visual_references/
```

## 9. Status and next closing work
**Approved as visual direction:** nine pages, theme, preferred concepts, responsive and localization direction, status design language.

**Not yet approved as final runnable spec:** all exact components, empty/error/rights/gate scenarios, source-bound graph data, all pages at 3 device sizes, comprehensive API binding matrix, authoritative image inventory.

**Implementation gate:** No React implementation, no GLM engineering assignment until owner signs off visual and functional handoff. 
