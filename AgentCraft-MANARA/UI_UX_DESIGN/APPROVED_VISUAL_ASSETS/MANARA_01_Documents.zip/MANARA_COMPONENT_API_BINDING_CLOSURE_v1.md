# MANARA — Component & API Binding Closure v1.0

**Status:** Design-to-backend mapping draft — review required, NOT an implementation authorization.  
**Date:** 2026-10-20  
**Authoring basis:** MANARA_UI_UX_DESIGN_FOUNDATION.md (GitHub, sections 0–14); approved visual direction in design discussion.  
**Visual authority:** Home Concept 01 (Modern Knowledge Studio); Investigation Observatory Concept 02; Mold Factory Concept 02 (dark-blue blueprint); Publishing Concept 02 + Reader Concept 01; other page-level approved directions.

## 0. Non-negotiable guardrails

- **No frontend implementation yet.** This is a specification for owner review and later GLM handoff.
- A visual mockup never authorizes a backend capability. Only implemented, explicitly mapped API routes are active.
- Demo/seed data must be tagged `SAMPLE DATA` in design previews, never represented as live research.
- Preserve truthful `is_mock`, `coverage_level`, `quality_gate_passed`, `quality_gate_issues`, `downloadable`, `rights_status`, `leakage_detected`, `deduplicated`, `freshness`, and workflow `blocker` indicators.
- Default UI locale is **English (LTR)**; Arabic (RTL) is second. This is the latest owner decision, superseding the foundation's browser-locale suggestion. Content remains in its original language unless an actual translation capability is added.
- The current backend is **single-tenant demo**, `tenant_demo`; no authentication, real user profile, billing, notification center, or role-based authorization. A role switcher (if retained) is explanatory UI only.
- Download formats are **Markdown, JSON, Text**, not PDF. Only enable downloads when `downloadable === true`.

## 1. Shared component → data/event contract

| Component | Source / action | States / contract | Boundary |
|---|---|---|---|
| AppShell / Sidebar | Client routing among 9 defined pages | Collapsible desktop; tablet drawer; mobile drawer; English LTR / Arabic RTL | No invented account dashboard |
| ServiceStatus | `GET /status` | Show service availability and honest limitations; non-blocking unless unusable | `/health` is monitoring-only |
| LanguageSwitcher | Client i18n state | English default; Arabic RTL; extensible locale keys; preserve evidence strings | No server-synced preferences currently |
| StudioObservatorySwitch | Local view state | Same source records, no altered analysis or workflow | No fabricated graph links |
| StateBadge | Entity status fields | Icon + text + semantic color, consistent light/dark | Do not equate APPROVED with VERIFIED |
| CoverageBadge | `coverage[].coverage_level` | NONE / CATALOG / OPERATIONAL / VERIFIED | Display per research need, not fictional global percentage |
| APIErrorNotice | HTTP error envelope | User-safe message; optional trace_id details; retry when safe | Never disclose internal secrets |
| AsyncRegion | Request lifecycle | Skeleton; action spinner; screen-reader announcement | Do not fabricate percent progress |
| ConfirmationDialog | Admin transitions, publish, archive, terminate | Explain irreversible/risky action and effect | Confirmation UI is not RBAC |
| EvidenceReference | Evidence/claim identifiers and timestamps | Provenance, checksum, freshness, verdict; selectable item | Never invent confidence ratings |
| GraphCanvas | Only known source/capability/evidence relationships | Accessible list alternative, node details, touch zoom | Aesthetic ambient nodes must be visibly decorative |

## 2. Per-page component/API binding matrix

### P01 — Investigation Home (Researcher)
| UI part / user action | Exact endpoint | Response/state mapping |
|---|---|---|
| Service notice | `GET /status` | Service status and limitations |
| Synthetic capability example | `GET /discovery` | Clearly label SYNTHETIC |
| Research question input | Local validation | 10–1000 characters; Submit disabled outside bounds |
| Start Investigation | `POST /mold-factory/compose` | Returns `investigation_id`, `mold_recipe_id`, `is_unknown_domain`, `is_complete`, `is_catalog_complete`, `coverage[]`, `gaps[]`, `deliverable_type`; navigate to P02 only after successful response |
| Clear | Local only | Empty input |
**Required states:** idle, invalid input, composing, success, partial coverage, coverage blocker, network/API failure. No chat or general search-results page.

### P02 — Investigation Workspace (Researcher / Investigation Manager)
| UI part / user action | Exact endpoint | Response/state mapping |
|---|---|---|
| 13-state workflow and history | `GET /mold-factory/investigations/{id}/workflow` | Current state, transitions, blocker; track transitions accurately; route POST variation requires contract verification |
| Advance state | `POST /mold-factory/investigations/{id}/transition` | `transitioned=false` => show `blocker`; never auto-advance |
| Evidence list and prior reuse | `GET /memory/investigations/{id}/evidence`; `POST /memory/investigations/{id}/search-prior` | Evidence records; freshness markers |
| Ingest evidence | `POST /memory/evidence` | Evidence contract; `deduplicated` visible |
| Claim attachment / edge / verdict | `POST /memory/evidence/{id}/claims`; `POST /memory/claims/{id}/support`; `PATCH /memory/claims/{id}/verdict` | Keep supports/refutes/qualifies distinct |
| Resolve and run specialist | `POST /agents/resolve`; `POST /agents/sessions`; `POST /agents/sessions/{id}/execute`; `GET /agents/sessions/{id}` | Show `granted_tools`, `tool_invocations`, `is_mock`, execution result and status |
| Foresight and publication | `POST /foresight/assess`; `POST /foresight/backtest`; `POST /publishing/publications` | Cross-link to P08/P09; do not synthesize results |
| Audit timeline | `GET /memory/investigations/{id}/decisions` | Chronological decisions |
**Required states:** all seven foundation states plus `is_mock`, blocked transition, leak detection, coverage blocker; preserved investigation ID on retry. Current states are `received`, `scoped`, `coverage_checked`, `building_capabilities`, `mold_ready`, `acquiring`, `normalizing`, `evidencing`, `forecasting_or_scenarios`, `drafting`, `verification`, `deliverable_ready`, `archived`. `blocked/failed/terminated` are NOT extra investigation FSM states.

### P03 — Capability Registry (Factory Manager)
| UI part / user action | Exact endpoint | Response/state mapping |
|---|---|---|
| Browse/filter/detail | `GET /registry/capabilities`; `GET /registry/capabilities/{id}` | Candidate/approved/rejected; `connector_ids` empty -> NO CONNECTOR |
| Semantic/coverage search | `GET /registry/search?q=...`; `GET /registry/search/coverage?q=...` | Use actual scoring/coverage data, no invented quality figures |
| Create / seed | `POST /registry/capabilities`; `POST /registry/capabilities/seed` | Seed 8 cards; dev-only helper clearly signaled |
| Promote / delete / reindex | `PATCH /registry/capabilities/{id}/promote`; `DELETE /registry/capabilities/{id}`; `POST /registry/capabilities/{id}/reindex` | Confirm destructive/admin actions |
| Evaluations | `GET /registry/capabilities/{id}/evaluations`; `POST /registry/capabilities/{id}/evaluations` | Recorded actual measurements only |
| Relationships | `GET /registry/capabilities/{id}/relationships`; `POST /registry/capabilities/{id}/relationships` | Only real relationship edges |
**Exclude:** arbitrary PATCH edit capability; universal preinstalled web/document/agent capability cards fabricated by images.

### P04 — Source Foundry (Factory Manager)
| UI part / user action | Exact endpoint | Response/state mapping |
|---|---|---|
| Browse and inspect candidates | `GET /foundry/candidates`; `GET /foundry/candidates/{id}` | OpenAlex is assessable; Crossref/arXiv catalog-only with PLANNED marker |
| Discover / assess | `POST /foundry/candidates/{id}/discover`; `POST /foundry/candidates/{id}/assess` | Real lifecycle transitions |
| Register connector / sandbox test | `POST /foundry/candidates/{id}/register-connector`; `POST /foundry/candidates/{id}/sandbox-test` | OpenAlex only; Crossref/arXiv actions disabled; show provenance or error (`rate_limited_after_retries`, `ssrf_violation:*`) |
| Approve / quarantine | `POST /foundry/candidates/{id}/approve`; `POST /foundry/candidates/{id}/quarantine` | Confirmation and state changes |
**Future design-only:** custom source addition, paid subscription/API key/OAuth/institutional access, secret vault, billing limits, access-rights management. Do not display as active in current implementation.

### P05 — Memory Explorer (Investigation Manager)
| UI part / user action | Exact endpoint | Response/state mapping |
|---|---|---|
| Evidence and detail | `GET /memory/investigations/{id}/evidence`; `GET /memory/evidence/{id}` | Source, kind, observed_at, ingested_at, published_at (when available), checksum, stored_at_ref as text |
| Claims filter | `GET /memory/investigations/{id}/claims?verdict=...` | candidate/supported/contested/refuted/superseded |
| Claim evidence links | `POST /memory/claims/{id}/support` (write) | Display supporting/refuting/qualifying relations from documented claim/evidence read payloads; confirm exact retrieval shape before interactive graph |
| Prior memory and reuse | `POST /memory/investigations/{id}/search-prior`; `POST /memory/investigations/{id}/reuse` | freshness and original investigation reference |
| Bitemporal replay | `POST /memory/investigations/{id}/at-cutoff` | Date/time cutoff; use server response, not client-filtered published dates |
| Audit / snapshot | `GET /memory/investigations/{id}/decisions`; `POST /memory/snapshots` | Decision rationale, actor, time; snapshot advanced action |
**Watch:** global full-text search, arbitrary knowledge graph/entity explorer, quality scores, share/save buttons are not confirmed endpoints. Treat as enhancement unless verified.

### P06 — Mold Factory (Factory Manager)
| UI part / user action | Exact endpoint | Response/state mapping |
|---|---|---|
| Mold library and detail | `GET /mold-factory/molds`; `GET /mold-factory/molds/{id}` | temporary/reusable/maintained/archived; domain/version/origin/capability_ids/last_piloted_at |
| Promote / archive | `PATCH /mold-factory/molds/{id}/promote`; `POST /mold-factory/molds/{id}/archive` | Confirm state progression and archive |
| Gap analysis | `GET /mold-factory/molds/{id}/gaps` | Need, status, resolution_notes, candidate_capability_ids, foundry_candidate_id |
| Compose mold as part of investigation | `POST /mold-factory/compose` | Entry point on Home, not an invented independent arbitrary mold editor |
**Visual baseline:** approved Concept 02 with dark-blue Mold Recipe Blueprint. Graph edges can only represent relationships returned by existing mold/gap/capability records. No custom drag/drop recipe editor.

### P07 — Agent Registry (Factory Manager)
| UI part / user action | Exact endpoint | Response/state mapping |
|---|---|---|
| Recipes list / detail | `GET /agents/recipes`; `GET /agents/recipes/{id}` | on_demand/recipe_saved/tested/maintained/retired |
| Seed two recipes | `POST /agents/recipes/seed-clinical`; `POST /agents/recipes/seed-generalist` | Clinical Prosthetics Reviewer; General Analyst only |
| Resolve/create/execute session | `POST /agents/resolve`; `POST /agents/sessions`; `POST /agents/sessions/{id}/execute` | Granted tools, status, mock/live indicator, output |
| Read/terminate/evaluate session | `GET /agents/sessions/{id}`; `POST /agents/sessions/{id}/terminate`; `POST /agents/sessions/{id}/evaluate` | Tool invocation statuses: executed / denied_not_in_granted_set / not_implemented / error |
**Exclude:** `PATCH /agents/recipes/{id}/promote`, Clone/Edit/General Register Agent and fabricated agents/performance percentages. MOCK warning cannot be hidden.

### P08 — Foresight (Investigation Manager)
| UI part / user action | Exact endpoint | Response/state mapping |
|---|---|---|
| Sufficiency assessment | `POST /foresight/assess` | `recommended_method=insufficient_evidence`: explanation and hide quantitative forecast UI |
| Create/detail | `POST /foresight/forecasts`; `GET /foresight/forecasts/{id}` | Actual method, target, metric, unit, point_estimate, dates, assumptions/scenarios if present |
| Publish / revise | `POST /foresight/forecasts/{id}/publish`; `POST /foresight/forecasts/{id}/revise` | Published immutable, revision linked, confirmations |
| Historical backtest | `POST /foresight/backtest` | MAE/RMSE/baseline MAE/improvement; `leakage_detected` / `leaked_evidence_ids` / `data_cutoff_verified` |
| Immutability demo | `POST /foresight/forecasts/{id}/try-modify` | Developer/test-only, not primary UI |
**Exclude:** confidence donuts, fabricated forecast datasets, generic map overlays or chart exports unless derived from actual API data.

### P09 — Publishing Studio (Researcher / Investigation Manager)
| UI part / user action | Exact endpoint | Response/state mapping |
|---|---|---|
| Publication list/detail | `GET /publishing/publications`; `GET /publishing/publications/{id}` | Display content_json and honest gate/type state |
| Create publication | `POST /publishing/publications` | Research dossier / presenter edition / visual storyboard; title and documented contract |
| Download | `GET /publishing/publications/{id}/download?format=json\|markdown\|text` | Only if `downloadable=true`; gate issues shown on failure |
**Special states:** coverage_blocker_report must be explicitly NOT A RESEARCH DELIVERABLE; rights_status unknown/restricted blocks publication where applicable; storyboard fictional scenes must show disclosures. `GET /publishing/publications/{id}/quality-gate` DOES NOT EXIST; gate read from detail response. No PDF, file editor, share link or per-user publication versions without added backend.

## 3. Cross-page state and feedback matrix

| State | Trigger from actual data | Expected UI behavior |
|---|---|---|
| Loading | In-flight request | Skeleton/spinner, no fake percentages |
| Empty | Successful empty result | Clear empty message and only valid next action |
| Success | 2xx with payload | Display result and honest flags |
| API/Network failure | 4xx/5xx/connection | User-safe error, trace ID details, retry where safe |
| Partial coverage | `is_complete=false` or per-need coverage shortfall | Visible unmet needs and gaps |
| Insufficient evidence | `recommended_method=insufficient_evidence` | Show `assessment_reasoning`, no probability chart |
| Source unavailable | Foundry sandbox test `success=false` | Error cause and retry guidance; rest of UI usable |
| Blocked transition | `transitioned=false` | Show backend `blocker` without inventing role permissions |
| Mock | `is_mock=true` | Prominent persistent banner + visible response watermark |
| Quality gate failed | `quality_gate_passed=false` | Render issues and disable downloads if `downloadable=false` |
| Coverage blocker | `deliverable_type=coverage_blocker_report` | Separate visual, not research dossier; download only when allowed |
| Leakage | `leakage_detected=true` | Prominent banner and leaked evidence IDs |
| Rights uncleared | `rights_status=unknown/restricted` | Mark affected scenes and gate restrictions |
| Investigation ready/archived | Workflow state | Distinct complete/archive treatment; gate still determines download |

## 4. Responsive / i18n / accessibility closure

- **Desktop:** sidebar + rich content + details. **Tablet:** drawer/collapsible sidebar + adaptive columns. **Mobile:** primary content first, bottom/drawer navigation; full-screen detail, readable graph alternative.
- Default language `en`; alternate `ar`; i18n keys per string, not concatenated translations; ready for additional locales.
- Use logical direction and isolate technical identifiers/URLs/DOIs. Graph time axis should preserve chronology regardless of RTL.
- WCAG 2.2 AA target; keyboard navigation, visible focus, accessible names, minimum practical touch targets, reduced motion, 200% zoom, text truncation with accessible full value.
- Poll agent session with `GET /agents/sessions/{id}` and workflow with `GET /mold-factory/investigations/{id}/workflow`; no WebSocket. Do not imply that the UI has a realtime server push.
- Never hardcode visually plausible output as a factual result. Developer fixtures must be isolated from production UI.

## 5. Exceptions and conflicts requiring verification before coding

1. **Workflow fetch method discrepancy:** Foundation §9 lists both `POST /mold-factory/investigations/{id}/workflow` and `GET /mold-factory/investigations/{id}/workflow` while other sections describe GET. Validate real OpenAPI/router methods; use GET for read/poll only if confirmed; do not ship unsupported POST.
2. **Coverage flag wording:** `VERIFIED` reflects passed sandbox testing per contract, **not a generic guarantee of production readiness or scientific truth**. Do not reuse optimistic sample tooltip from design as a stronger claim.
3. **Publication downloadable rule:** Foundational sections sometimes narrate `status=published` as downloadable but gating says the authoritative switch is `downloadable`, with `quality_gate_passed` and nonempty content. Use `downloadable` as the UI control.
4. **Knowledge Graph feasibility:** capability relationships exist, claim/support edges can be created, but a universal graph query endpoint is not listed. Define client graph only from existing explicitly retrieved relationships; if required relation reads are missing, mark those visual subviews future/limited.
5. **UI state design vs real authentication:** role labels are illustrative; authorization not implemented. Never claim permissions are enforced.
6. **Agent live execution:** current tested path is MockProvider; live Z.AI is not exercised. Never label result real unless backend reports verified live path and flags.
7. **SaaS enhancements:** generic source provisioning, secret credentials, billing, accounts and preferences sync are proposed scope changes. Require separate owner-approved backend architecture and endpoints.
8. **Inventory roll-up:** document says 36 capabilities but summarizes 22+1+2+1+2+3+1=32 headline classes; reconcile the classification before marking functional inventory cross-check complete.
9. **Header search / recent investigations:** no global search or general investigation-list endpoint is documented in this reference. These are not automatically available because the mockups display them.
10. **Mockup content scope:** fake source names, references, dates, statistics, confidence and charts are illustration-only; replace with true API values or explicit empty state.

## 6. Acceptance criteria for this closure

- [x] Every required page has a component-to-route outline.
- [x] Shared honest flags and failure states are mapped.
- [x] Major unsupported visual actions are documented.
- [x] Latest English-default and RTL decisions are captured.
- [ ] All endpoint methods and request/response schemas independently verified against active backend OpenAPI/source.
- [ ] Every UI mockup element individually tagged: IMPLEMENT / PRESENTATIONAL / FUTURE / REMOVE.
- [ ] Graph data contracts and relationship retrieval validated.
- [ ] All required page/state combinations have final approved visual references.
- [ ] Owner approves final GLM handoff package.

**Handoff decision:** NOT READY FOR IMPLEMENTATION. This file is an actionable draft mapping, not final certification of backend compatibility.

**References:** https://github.com/mayakilzy/repo-info/blob/main/AgentCraft-MANARA/UI_UX_DESIGN/MANARA_UI_UX_DESIGN_FOUNDATION.md  
https://github.com/mayakilzy/repo-info/tree/main/AgentCraft-MANARA/BACKEND_VERIFICATION_01
