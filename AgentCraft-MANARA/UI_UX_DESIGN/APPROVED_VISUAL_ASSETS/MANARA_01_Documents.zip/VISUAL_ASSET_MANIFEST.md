# MANARA — Visual Asset Manifest v1.0

Date: 2026-10-20. Status: **REVIEW, not implementation authorization**.

All image content is illustrative. Approvals are for overall direction, not all pictured features. File SHA-256 values are in `VISUAL_ASSET_MANIFEST.json`.

| Area | Image path | Approval | Implementation caution |
|---|---|---|---|
| 01_Home | `VISUAL_ASSETS/01_Home/a_wide_high_resolution_ui_website_app_dashboard_s.png` | APPROVED_VISUAL | Home Concept 01; lighthouse hero. Remove unsupported account/global search. |
| 02_Investigation | `VISUAL_ASSETS/02_Investigation/a_clean_modern_ui_ux_dashboard_screenshot_for_a_r.png` | APPROVED_DIRECTION | Investigation Observatory Concept 02; workflow stepper must use 13 actual FSM states. |
| 02_Investigation | `VISUAL_ASSETS/02_Investigation/a_wide_detailed_ui_ux_concept_board_for_a_researc.png` | SUPPORTING_ONLY | States and coverage visual references; illustrative data. |
| 02_Investigation | `VISUAL_ASSETS/02_Investigation/a_wide_clean_high_resolution_ui_ux_design_showca.png` | SUPPORTING_ONLY | Knowledge graph and evidence states; no fabricated nodes. |
| 03_Memory | `VISUAL_ASSETS/03_Memory/a_wide_ui_ux_multi_panel_dashboard_mockup_for_a_re.png` | APPROVED_DIRECTION | Memory Explorer catalog and bilingual reference. |
| 03_Memory | `VISUAL_ASSETS/03_Memory/a_wide_high_resolution_infographic_style_ui_mocku.png` | APPROVED_DIRECTION | Claim Examination split supporting/refuting/qualifying and bitemporal timeline. |
| 04_Capabilities | `VISUAL_ASSETS/04_Capabilities/a_wide_detailed_ui_dashboard_mockup_screenshot_of.png` | APPROVED_DIRECTION | Capability Registry Concept 01. Replace fictitious agents, stats, connectors. |
| 05_Foundry | `VISUAL_ASSETS/05_Foundry/a_wide_clean_modern_dashboard_ui_mockup_image_fo.png` | APPROVED_DIRECTION | Source Foundry Concept 01. |
| 05_Foundry | `VISUAL_ASSETS/05_Foundry/a_wide_clean_modern_ui_dashboard_mockup_in_a_hig.png` | SUPPORTING_ONLY | Source lifecycle design cues; do not treat extra sources as live. |
| 05_Foundry | `VISUAL_ASSETS/05_Foundry/wide_detailed_ui_ux_dashboard_screenshot_of_an_app.png` | FUTURE_DESIGN | Adding paid/API/institutional research sources — backend enhancement, not implemented. |
| 06_Molds | `VISUAL_ASSETS/06_Molds/mold_factory_blueprint_dashboard.png` | APPROVED_VISUAL | Mold Factory Concept 02, owner prefers prominent dark-blue blueprint. |
| 06_Molds | `VISUAL_ASSETS/06_Molds/mold_factory_dashboard_interface.png` | SUPPORTING_ONLY | Mold Library Concept 01 auxiliary. |
| 07_Agents | `VISUAL_ASSETS/07_Agents/wide_detailed_ui_screenshot_of_a_web_application.png` | APPROVED_DIRECTION | Agent Registry Concept 02 cards/details; unsupported editing must be removed. |
| 07_Agents | `VISUAL_ASSETS/07_Agents/a_wide_clean_modern_ui_dashboard_screenshot_mo.png` | SUPPORTING_ONLY | Agent relationships Observatory concept; no invented links. |
| 08_Foresight | `VISUAL_ASSETS/08_Foresight/a_wide_high_resolution_ui_dashboard_screenshot_in.png` | APPROVED_DIRECTION | Foresight Concept 01 Observatory. |
| 08_Foresight | `VISUAL_ASSETS/08_Foresight/a_detailed_wide_high_resolution_ui_dashboard_scr.png` | APPROVED_DIRECTION | Foresight Concept 02 organization; scenario charts illustrative only. |
| 09_Publishing | `VISUAL_ASSETS/09_Publishing/a_wide_high_resolution_ui_dashboard_screenshot_c.png` | APPROVED_VISUAL | Publishing Concept 02 with dark status sidebar. |
| 09_Publishing | `VISUAL_ASSETS/09_Publishing/a_wide_polished_ui_dashboard_screenshot_of_a_rese.png` | APPROVED_VISUAL | Publishing Reader Concept 01, selected companion. |
| 10_System | `VISUAL_ASSETS/10_System/a_clean_high_resolution_multi_panel_ui_style_gui.png` | SUPPORTING_ONLY | Design system reference; retain original lighthouse and navy/teal/gold palette. |
| 10_System | `VISUAL_ASSETS/10_System/a_clean_detailed_ui_ux_design_presentation_poster.png` | SUPPORTING_ONLY | Responsive/LTR-RTL general direction. |
| 10_System | `VISUAL_ASSETS/10_System/a_wide_polished_multi_panel_ui_ux_showcase_image.png` | SUPPORTING_ONLY | Mobile investigation/tablet molds/Arabic memory reference; correct misleading elements. |
| 10_System | `VISUAL_ASSETS/10_System/a_wide_clean_ui_design_system_infographic_dashboa.png` | APPROVED_DIRECTION | States feedback handling concept. |
