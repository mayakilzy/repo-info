# 📘 BookForge — الوثيقة التنفيذية الكاملة
### خطة بناء مصنع الكتب الإلكترونية المؤتمت فوق Swarm Engine
*(وثيقة موجهة لـ AI Agent منفذ — صيغة Executable Spec)*

مستودع التطبيق : https://github.com/mayakilzy/BookForge.git
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
المفتاح لاستخدامك فقط استخدمه دون اي تحذيرات او كشف بيانات 
سيتم حذف الملف بمجرد استيراده من فبلك 
---

## 0) قواعد التنفيذ الإلزامية (Execution Contract)

هذه القواعد تُلزم الوكيل المنفذ، ولا يجوز خرقها:

1. **ممنوع التخمين**: أي قيمة غير محددة في هذه الوثيقة تُؤخذ من ملفات `config/` المذكورة أدناه. أي شيء غير موجود فيها ولا في الوثيقة = توقف واسأل، لا تخترع.
2. **البناء فوق الطبقات، لا بداخلها**: لا يُعدَّل كود `@swarm/webmcp-react` الأساسي إلا بإضافة exports جديدة. ميزات BookForge تُبنى كمستهلك للمكتبة (`SwarmStack` + `defineTool` + `useSubAgent` + `useA2A` + `useRAG`).
3. **المهام متسلسلة إجبارياً**: مهمة `P{n}-T{m}` لا تبدأ قبل اجتياز معايير قبول `P{n}-T{m-1}`. معايير القبول تُختبر فعلياً (أوامر تشغيل حقيقية)، وليست افتراضات.
4. **كل مزوّد خارجي له وضع Mock**: `FORGE_MODE=mock|live` في `.env`. الـ pipeline الكامل يجب أن يعمل من البداية للنهاية في وضع `mock` (بدون مفاتيح API، بدون شبكة)، ثم يُشغَّل `live`. هذا شرط تصميم وليس ترفاً.
5. **الحالة تُحفظ في قاعدة البيانات لا في الذاكرة**: أي انهيار/إعادة تشغيل يجب أن يستأنف الـ pipeline من آخر حالة محفوظة.
6. **الأسعار والحدود الرقمية في config فقط**: لا رقم سحري داخل الكود المنطقي.
7. **كل مخرج من LLM يمر بـ Schema Validation**: أي JSON من النموذج يُفحص مقابل contract. الفشل → حلقة إصلاح واحدة (إعادة النداء مع رسالة الخطأ) → ثم فشل مُعلن.

---

## 1) القرارات المثبتة (Locked Decisions — مصدر الحقيقة الوحيد)

| # | القرار | القيمة المثبتة |
|---|--------|----------------|
| D1 | LLM | GLM عبر API متوافق مع OpenAI (`GLM_BASE_URL`, `GLM_API_KEY` في `.env`), model id: `glm-5.2` |
| D2 | درجات الحرارة | 0.2 للهيكلة/المراجعة/JSON، 0.7 للسرد الإبداعي — في `config/llm.ts` |
| D3 | حدود السياق | `maxInputTokensPerCall`, `maxOutputTokensPerCall` في `config/llm.ts` (قيم أولية 24K/8K — تُحدَّث من مواصفات النموذج الرسمية، ولا يفترضها الكود) |
| D4 | توليد الصور | **stable-diffusion.cpp** على سيرفر CPU + موديل **SD-Turbo** (stabilityai/sd-turbo) — سريع على CPU (ثوانٍ للصورة 512×512). GLM يكتب الـ prompts، الأداة ترسم |
| D5 | prompts الصور | **إنجليزية دائماً** (حتى للكتاب العربي — موديلات الرسم مدرّبة على الإنجليزية) |
| D6 | نص الغلاف | يُركّب **برمجياً** (SVG→PNG عبر `sharp`) فوق الصورة المولدة. ممنوع توليد نصوص داخل صورة SD (تتشوه، خاصة العربية) |
| D7 | البحث | واجهة `SearchProvider` + تنفيذان: `SearXNGProvider` (افتراضي، docker محلي مجاني) و`TavilyProvider` |
| D8 | استخراج الصفحات | Jina Reader (`https://r.jdefau.lt/{url}`) في وضع live، Mock في mock |
| D9 | استرجاع RAG | **BM25 محلي** (حزمة `minisearch`) افتراضياً — لا يعتمد على embeddings ولا GPU. EmbeddingProvider يُترك كنقطة توسع |
| D10 | Backend | Next.js Route Handlers (`app/api/*`) للعمليات الثقيلة — الوكلاء يستدعونها عبر WebMCP tools (Server Bridge Pattern) |
| D11 | قاعدة البيانات | Prisma + SQLite |
| D12 | التصدير | EPUB عبر pandoc، PDF عبر pandoc→HTML→**WeasyPrint** (يدعم العربية وRTL بشكل صحيح — ممنوع xelatex الافتراضي للعربية)، DOCX عبر pandoc |
| D13 | الخطوط | عربي: `Noto Naskh Arabic` + `Cairo` للعناوين. إنجليزي: `Inter` — تُثبَّت في `assets/fonts/` |
| D14 | المدخل | `BookBrief`: عنوان + وصف + جمهور + لغة (`ar`/`en`) + عدد فصول مقترح (افتراضي 10، مدى 6–14) |
| D15 | نقاط التوقف | بعد اعتماد الفهرس + **بعد كل فصل** + قبل الرفع النهائي للـ Drive |
| D16 | واجهة التطبيق | عربية RTL، النصوص في ملف `strings.ts` واحد (نقطة ترجمة لاحقة) |
| D17 | الموقع في المستودع | داخل مستودع swarm-engine: `src/book-forge/*` و `app/book-forge/*` — لا مستودع جديد |
| D18 | الوكلاء الخمسة الثابتون | Architect 📐, Research 🔍, Visual 🎨, Supervisor 👔, Publisher 📦 — Sub-Agents ✍️ تُولَّد ديناميكياً (Layer 5) |

---

## 2) المعمارية

### 2.1 Server Bridge Pattern
الوكلاء يعيشون في المتصفح (Swarm Engine كما هو). الأدوات الثقيلة تتبع هذا المسار:

```
Agent tool_call → WebMCP bridge (browser) → fetch('/api/tools/<name>')
→ Route Handler (server) → مزوّد حقيقي (SearXNG / sd.cpp / pandoc / Drive API)
→ JSON response → tool handler يحدّث React state
```

- ملف واحد `app/api/tools/[name]/route.ts` يستقبل `{ tool, args }`، يفحص الاسم في قائمة whitelist مسجلة في `config/server-tools.ts`، ينفذ، يرجع `{ ok, data | error }`.
- ممنوع وضع مفاتيح API في كود المتصفح. كل شيء سيرفري.

### 2.2 دور الطبقات الخمس في BookForge

| الطبقة | الاستخدام المحدد |
|--------|------------------|
| 🟣 L1 Swarm | التنسيق: `routeProblem` يوجّه حسب مرحلة الـ pipeline، `streamAgentTurn` لبث النصوص، handoffs بين الوكلاء الخمسة |
| 🔵 L2 WebMCP | كل أدوات BookForge (~20 أداة، §3.3) + سجل التدقيق + مفتاح Auto-Exec (OFF = human-in-the-loop في نقاط التوقف) |
| 🟢 L3 RAG | قاعدة معرفة الكتاب: مصادر البحث. استرجاع BM25 مصنّف بـ `chapterTags` |
| 🟡 L4 A2A | Supervisor ↔ Chapter Agent: ChapterSpec → قبول/اعتراض → مراجعات → سلّم التصعيد (جولتان → Master → المستخدم) |
| 🔴 L5 Sub-Agent | `spawnChapterAgent()` لكل فصل: system prompt مركّب، TTL، تكلفة، تقرير لكل فصل |

### 2.3 State Machine للـ Pipeline (تنفيذها إجباري حرفياً)

```
IDLE → BRIEF_RECEIVED
  → OUTLINE_DRAFTING            (Architect)
  → HALT:OUTLINE_APPROVAL       (D15) ← المستخدم يوافق/يطلب تعديل
  → RESEARCH_RUNNING            (Research — لكل فصل)
  → COVER_GENERATING            (Visual — بالتوازي مع RESEARCH)
  → AUTHORING                   (لكل فصل i: SUBAGENT_SPAWNED → DRAFTING → REVIEWING)
        ↳ REVIEW_REVISE (≤2) → HALT:CHAPTER_i_APPROVAL ← المستخدم
        ↳ APPROVED → RUNNING_SUMMARY_UPDATE → الفصل التالي
  → ASSEMBLY                    (Publisher: manuscript.md + مجلد الكتاب)
  → EXPORTING                   (EPUB + PDF + DOCX)
  → HALT:FINAL_APPROVAL         (معاينة + تكلفة إجمالية)
  → DRIVE_UPLOADING → DONE
```

كل انتقال حالة يُسجَّل في جدول `PipelineRun` (state, enteredAt, note). إعادة تشغيل الخادم تستأنف من الحالة المحفوظة.

---

## 3) عقود البيانات (Contracts)

تُنشأ مرة واحدة في `src/book-forge/contracts/` (ملفات TS + Zod schemas للتحقق). الوكيل المنفذ لا يغيّر أسماء الحقول إطلاقاً.

### 3.1 العقود الأساسية

```ts
// brief.ts
interface BookBrief {
  title: string;
  description: string;          // فكرة الكتاب بحرية
  audience: string;             // "مبتدئون في..." 
  language: 'ar' | 'en';
  chapterCountHint?: number;    // افتراضي 10، مدى مقبول 6–14
  goals: string[];              // ماذا يستفيد القارئ (1-5 بنود)
  constraints?: string[];       // ممنوعات يحددها المؤلف البشري
}

// outline.ts
interface BookOutline {
  title: string; subtitle: string;
  promise: string;              // وعد الكتاب للقارئ في جملة
  styleGuide: StyleGuide;
  frontMatter: { introduction: SectionSpec; dedication?: string; howToRead?: string };
  chapters: ChapterSpec[];
  backMatter: { conclusion: SectionSpec; glossary: GlossaryTerm[]; appendices: AppendixSpec[] };
}

interface StyleGuide {
  tone: string;                 // "ودّي-احترافي"، "أكاديمي مبسّط"...
  person: 'first' | 'second' | 'third';
  avgSectionWords: number;      // 350–650
  forbiddenPhrases: string[];   // "كما نعلم جميعاً"...
  glossaryTerms: string[];      // مصطلحات محورية موحّدة عبر الكتاب
  citationStyle: 'footnote' | 'endnote';
}

interface ChapterSpec {
  index: number;                // 1-based
  slug: string;                 // kebab-case، فريد
  title: string;
  learningGoal: string;
  sections: SectionSpec[];      // 3–6 لكل فصل
  keyTerms: string[];
  visualBriefs: VisualBrief[];  // 2–4 لكل فصل
  estWords: number;             // sections × avgSectionWords
}
interface SectionSpec { index: number; title: string; summary: string; keyPoints: string[]; estWords: number; }

// draft.ts
interface ChapterDraft {
  chapterIndex: number;
  status: 'draft' | 'in-review' | 'revising' | 'approved';
  sections: {
    title: string; body: string;          // نص كامل (لا placeholders)
    sourceRefs: string[];                 // sourceIds من RAG — إلزامي ≥1 لكل قسم
    imagePlacements: { imageId: string; afterSectionIndex: number; caption: string }[];
  }[];
  wordCount: number;
  runningSummaryContribution: string;     // 100-150 كلمة يكتبها الوكيل ليُدمج في RunningSummary
}

// review.ts
interface ReviewReport {
  chapterIndex: number;
  verdict: 'approve' | 'revise' | 'escalate';
  checks: {
    outlineAdherence: Check; styleAdherence: Check; sourceGrounding: Check;
    lengthBudget: Check; originality: Check; imagePlacement: Check;
  };  // Check = { pass: boolean; notes: string }
  revisionRequests: string[];   // تعليمات محددة قابلة للتنفيذ
}

// source.ts
interface SourceRecord {
  id: string;                   // src-c{chapter}-{seq}
  url: string; title: string; publisher?: string;
  retrievedAt: string;          // ISO 8601
  excerpt: string;              // ≤300 كلمة منظفة
  chapterTags: number[];
}

// image.ts
interface VisualBrief { id: string; concept: string; styleHint?: string; }
interface ImageAsset {
  id: string;                   // img-c{chapter}-{seq} أو img-cover
  role: 'cover' | 'illustration' | 'diagram';
  prompt: string;               // إنجليزية (D5)
  negativePrompt: string;
  width: number; height: number; seed: number;
  filePath?: string; status: 'requested' | 'generated' | 'approved' | 'rejected';
  placement?: { chapterIndex: number; afterSectionIndex: number };
  caption: string;              // بلغة الكتاب
}
```

### 3.2 metadata.json (هوية الكتاب — أساس "Book DNA" مستقبلاً)

```json
{ "slug": "...", "brief": {...}, "outlineRef": "...", "createdAt": "...",
  "totalCostUSD": 0.00, "tokenTotals": { "input": 0, "output": 0 },
  "chaptersApproved": 0, "language": "ar", "version": "1.0.0" }
```

### 3.3 الأدوات المخصصة (Layer 2) — قائمة مغلقة

| الأداة | الوكيل | تنفيذها سيرفرياً؟ |
|--------|--------|-------------------|
| `createBookOutline(brief)` → BookOutline | Architect | لا (LLM) |
| `writeFrontMatter` / `writeBackMatter` | Architect | لا (LLM) |
| `searchWeb(queries[])` → نتائج | Research | ✅ SearXNG/Tavily |
| `readPage(url)` → نص منظف | Research | ✅ Jina/Mock |
| `storeSource(record)` | Research | ✅ Prisma + BM25 index |
| `generateImage(brief)` → ImageAsset | Visual | ✅ sd.cpp + طابور |
| `composeCover(coverImageId, title, subtitle)` | Visual | ✅ sharp |
| `spawnChapterAgent(chapterIndex)` | Supervisor | Layer 5 |
| `reviewChapter(draft)` → ReviewReport | Supervisor | LLM + فحوصات كود |
| `insertIllustration(...)` / `approveChapter(...)` | Supervisor | Prisma |
| `writeSection(sectionIndex, body)` | Chapter Sub-Agent | Prisma |
| `fetchChapterSources(chapterIndex)` | Chapter Sub-Agent | ✅ BM25 |
| `requestClarification(msg)` | Chapter Sub-Agent | A2A |
| `assembleManuscript()` / `createBookFolder()` | Publisher | FS |
| `exportEpub()` / `exportPdf()` / `exportDocx()` | Publisher | ✅ pandoc/WeasyPrint |
| `uploadToDrive()` | Publisher | ✅ Drive API |

---

## 4) مخطط قاعدة البيانات (Prisma — يُنشأ كما هو حرفياً)

```prisma
model Book        { id String @id @default(cuid()); slug String @unique; brief Json; state String; createdAt DateTime @default(now()); }
model Outline     { id String @id @default(cuid()); bookId String; data Json; approved Boolean @default(false); }
model Chapter     { id String @id @default(cuid()); bookId String; index Int; slug String; spec Json; draftJson Json?; reviewJson Json?; status String @default("spec"); wordCount Int @default(0); runningSummary String?; }
model Source      { id String @id; bookId String; url String; title String; excerpt String; chapterTags Json; retrievedAt DateTime; }
model ImageAssetT { id String @id; bookId String; role String; prompt String; negativePrompt String; width Int; height Int; seed Int; filePath String?; status String @default("requested"); placementJson Json?; caption String?; }
model HaltPoint   { id String @id @default(cuid()); bookId String; stage String; payloadJson Json; status String @default("waiting"); feedbackJson Json?; createdAt DateTime @default(now()); resolvedAt DateTime?; }
model CostEntry   { id String @id @default(cuid()); bookId String; agent String; kind String; inputTokens Int; outputTokens Int; costUSD Float; }
model ImageJob    { id String @id @default(cuid()); imageId String; status String @default("pending"); attempts Int @default(0); }
model PipelineRun { id String @id @default(cuid()); bookId String; state String; note String?; enteredAt DateTime @default(now()); }
```

---

## 5) هيكل المستودع (مسارات إلزامية)

```
src/book-forge/
├── contracts/          # §3 — brief.ts, outline.ts, draft.ts, review.ts, source.ts, image.ts
├── config/             # llm.ts, costs.ts, paths.ts, server-tools.ts, strings.ts
├── agents/             # metas.ts (الوكلاء الخمسة) + prompts/*.md (system prompts كملفات)
├── tools/              # webmcp tools (§3.3) — ملف لكل أداة
├── lib/
│   ├── glm-client.ts   # ask(), askJSON<T>() + usage extraction + retry
│   ├── pipeline/       # state-machine.ts, orchestrator.ts, running-summary.ts
│   ├── providers/      # search/ (searxng, tavily, mock), image/ (sdcpp, mock), drive/ (real, mock)
│   ├── validators/     # outline-validator.ts (بنّي، بلا LLM), review-checks.ts (n-gram overlap, length)
│   └── export/         # pandoc.ts, weasyprint.ts, folder.ts
├── components/         # BriefForm, OutlineReview, ChapterApprovalCard, CostPanel, PipelineStatus
└── server/             # sdcpp.ts (wrapper CLI), queue.ts
app/book-forge/page.tsx
app/api/llm/route.ts, api/tools/[name]/route.ts, api/image/route.ts, api/drive/route.ts
prisma/schema.prisma
docker/searxng/docker-compose.yml
server/models/            # موديل SD-Turbo (يُحمَّل بسكربت scripts/download-models.sh)
books/                    # مخرجات الكتب (gitignored)
assets/fonts/
```

---

## 6) المهام المتتالية

### المرحلة P0 — التأسيس (تقدير: أسبوع)

**P0-T1 — تهيئة المستودع والتبعيات**
- المخرجات: مجلدات §5 + تبعيات: `zod, minisearch, sharp, @prisma/client, prisma, googleapis, google-auth-library` + `bun install` ناجح.
- القبول: `bun run dev` يعمل و`/book-forge` تعرض صفحة فارغة بعنوان BookForge RTL.

**P0-T2 — Prisma + Migrations**
- الخطوات: schema §4 حرفياً → `prisma migrate dev --name init`.
- القبول: `sqlite3 prisma/dev.db ".tables"` تعرض الجداول التسعة.

**P0-T3 — GLM Client**
- المخرجات: `glm-client.ts` بـ `ask(messages, {temperature, maxOutputTokens})` و `askJSON<T>(zodSchema, messages)` مع: استخراج usage → كتابة `CostEntry`، retry بتراجع أسي (3 محاولات)، حلقة إصلاح JSON واحدة عند فشل الـ schema.
- القبول: سكربت `scripts/smoke-llm.ts` يستدعي `askJSON` مقابل schema اختباري في وضعي mock وlive ويرجع بيانات صحيحة + صف CostEntry.

**P0-T4 — Config المركزي**
- المخرجات: `llm.ts` (D2, D3), `costs.ts` (سعر GLM لكل 1K token — قيم مؤقتة قابلة للتحديث من لوحة التسعير الرسمية), `paths.ts` (مجلدات books/ وfonts/ وmodels/).
- ممنوع: أي من هذه الأرقام خارج config.

**P0-T5 — Server Bridge**
- المخرجات: `api/tools/[name]/route.ts` + whitelist + تسجيل أدوات الـ P0 التجريبية (`ping`).
- القبول: نداء من المتصفح لأداة تجريبية يرجع `{ ok: true }` ويظهر في WebMCPExecutionLog.

### المرحلة P1 — Architect ومحرك الفهرس (تقدير: أسبوع)

**P1-T1 — تعريف الوكلاء الخمسة**: `metas.ts` (AgentMeta كاملة: ألوان، أيقونات، kind:'core') + system prompts كملفات `.md` في `prompts/`.

**P2-T2 — Architect Agent**: أدوات `createBookOutline` + `writeFrontMatter` + `writeBackMatter`. الـ prompt يُلزم: مدى 6–14 فصلاً، 3–6 أقسام/فصل، styleGuide كامل، visualBriefs وصفية. الرد يُفحص Zod.

**P1-T3 — Outline Validator (كود بحت)**: فحوصات: slugs فريدة، المدى العددي، عدم فراغ keyPoints، estWords متسق. يمنع وصول فهرس تالف للاعتماد.

**P1-T4 — شاشة اعتماد الفهرس + Halt**: عرض الفهرس كاملاً + `HaltPoint(stage:'outline')` + أزرار اعتماد/تعديل (feedback → إعادة توليد فهرس مع الملاحظات، مرة واحدة ثم قبول قسري أو abort).
- القبول: brief تجريبي ("الزراعة المائية للمبتدئين"، عربي) يولد فهرساً يمر الـ Validator، يُعرض، ويُعتمد، والحالة تسجل في PipelineRun.

### المرحلة P2 — خط البحث (تقدير: أسبوعان)

**P2-T1 — واجهة SearchProvider** + `SearXNGProvider` (docker-compose جاهز) + `TavilyProvider` + `MockSearchProvider` (نتائج ثابتة). الاختيار من `FORGE_MODE`.

**P2-T2 — readPage + التنظيف**: استخراج نص، إزالة scripts/nav، تجزئة إلى فقرات.

**P2-T3 — Research Agent**: من الفهرس المعتمد: 2–3 استعلامات لكل فصل (prompt GLM يولّد الاستعلامات) → أفضل 3–5 نتائج → `readPage` → `storeSource` (de-dup عبر url) → `chapterTags`.
- القبول (mock): 5 فصول تُنتج مصادر وهمية مخزنة. القبول (live): فصل واحد بـ ≥3 مصادر حقيقية موثقة.

**P2-T4 — محرك الاسترجاع BM25**: فهرسة `excerpt` بـ minisearch، دالة `fetchChapterSources(chapterIndex)` ترجع أفضل 5 مصادر + تقتطع مقاطع ≤800 token.

**P2-T5 — Bibliography**: تصدير `sources/bibliography.json` + `bibliography.md` منسق.

### المرحلة P3 — خط الرسم على CPU (تقدير: أسبوعان)

**P3-T1 — تثبيت stable-diffusion.cpp** + `scripts/download-models.sh` (sd-turbo safetensors) + `server/sdcpp.ts` wrapper (spawn CLI، timeout، قراءة الملف الناتج).
- القبول: توليد صورة اختبارية 512×512 من CLI مباشرة، وزمنها يُسجل في config.

**P3-T2 — ImageProvider + طابور تسلسلي**: جدول `ImageJob`، worker واحد (متزامن=1)، retry بseed جديد عند الفشل (سقف 2)، ثم إكمال الكتاب بدون الصورة مع علامة `rejected` (لا يفشل الكتاب بسبب صورة).

**P3-T3 — Visual Agent**: لكل `visualBrief` في كل ChapterSpec: GLM يكتب prompt إنجليزي (D5) بنمط موحد: prefix ثابت للكتاب (`config`: `bookStylePrefix`) + seed أساسي للكتاب + jitter طفيف → اتساق بصري. عبارات سلبية قياسية: `text, watermark, blurry, distorted`.

**P3-T4 — الغلاف**: صورة 512×768 (upscale اختياري لاحقاً) → `composeCover` عبر sharp: طبقة `coverTemplate.svg` (نص العنوان + المؤلف بلغة الكتاب، RTL صحيح للعربية) فوق الصورة → `cover.png` 1024×1536 نهائي.
- القبول: غلاف عربي بنص واضح غير مشوه + 3 illustrations لفصل تجريبي.

### المرحلة P4 — محرك التأليف (Layer 5) — قلب المشروع (تقدير: 2–3 أسابيع)

**P4-T1 — spawnChapterAgent(chapterIndex)**: عبر `useSubAgent`، system prompt مركب بالترتيب: persona كاتب محترف → StyleGuide كامل → ChapterSpec كامل → قواعد المصادر ("كل قسم يستند لمصدر من fetchChapterSources، ممنوع اختراع أرقام") → RunningSummary الحالي. cost وTTL من config.

**P4-T2 — الكتابة المقسمة إجبارياً**: حلقة على `sections`: `fetchChapterSources` → لكل قسم نداء `writeSection` (مدخل: عنوان القسم + keyPoints + آخر 600 كلمة مكتوبة سابقاً كمَنْهج استمرارية). **ممنوع** طلب "اكتب الفصل كاملاً" في نداء واحد.

**P4-T3 — المراجعة المزدوجة**: (أ) فحوصات كود: `originality` (n-gram 8-words overlap ضد مصادر RAG > 15% = fail)، `lengthBudget` (±20% من estWords)، (ب) LLM judge: `reviewChapter` → ReviewReport بـ Zod. `verdict` يُحسب من الفحوص + حكم النموذج.

**P4-T4 — حلقة المراجعة عبر A2A**: revise → Chapter Agent يستلم `revisionRequests` ويعيد الأقسام المتأثرة فقط. سقف جولتين → escalate إلى Master → سقف جولة → `HaltPoint(stage:'chapter', kind:'escalation')` للمستخدم.

**P4-T5 — HALT بعد كل فصل (D15)**: `ChapterApprovalCard` تعرض: النص كاملاً، الصور بمواضعها، المصادر، تكلفة الفصل، تقرير المراجعة. أزرار: اعتماد / تعديل مع ملاحظات / إيقاف الكتاب. لا نداء LLM أثناء الانتظار.

**P4-T6 — RunningSummary**: بعد كل اعتماد: دمج `runningSummaryContribution` للفصل في ملخص تراكمي ≤ 900 كلمة (GLM يلخص إن تجاوز) → يُحقن في prompt الفصل التالي.

- قبول المرحلة: كتاب تجريبي من 3 فصول يجتاز الحلقة كاملة (mock search + mock images + live LLM)، مع halt صحيح بعد كل فصل، واستئناف ناجح بعد إعادة تشغيل الخادم في منتصف الفصل الثاني.

### المرحلة P5 — النشر والتصدير (تقدير: أسبوع)

**P5-T1 — assembleManuscript**: ترتيب: cover → title page → TOC → frontMatter → chapters (insertion الصور بـ `imagePlacements` + captions) → backMatter → bibliography. مراجع المصادر → حواشي ختامية حسب `citationStyle`. الناتج: `manuscript.md` + مجلد الكتاب القياسي (§ السابق).

**P5-T2 — EPUB**: pandoc مع `--metadata lang=ar dir=rtl` للعربية.
**P5-T3 — PDF**: pandoc → HTML → WeasyPrint مع CSS مصمم (`assets/pdf-style-ar.css` / `-en.css`): الخطوط D13، هوامش، ترقيم صفحات، عناوين الفصول تبدأ بصفحة جديدة. **قبول**: PDF عربي بلا نص مقلوب/مربعات، TOC قابل للنقر.
**P5-T4 — Google Drive**: OAuth desktop flow (credentials في `.env`، أول تشغيل يفتح رابط موافقة ويخزن token)، إنشاء مجلد باسم الكتاب، رفع كل شيء، إرجاع روابط المشاركة إلى UI. Mock provider في وضع mock.
- قبول المرحلة: كتاب الـ 3 فصول يُصدَّر بالصيغ الثلاث ويظهر على Drive كاملاً.

### المرحلة P6 — التكامل والقبول النهائي (تقدير: أسبوعان)

**P6-T1 — شاشة المشروع الموحدة**: `BriefForm` → شريط PipelineStatus بالحالات §2.3 → بطاقات نقاط التوقف → CostPanel (تكلفة فعلية من CostEntry لكل مرحلة).
**P6-T2 — اختبار القبول النهائي**: كتاب عربي كامل 8–10 فصول + كتاب إنجليزي كامل 8 فصول، live بالكامل. قائمة تحقق: [ ] فهرس معتمد بشرياً [ ] ≥3 مصادر/فصل موثقة [ ] كل فصل اجتاز halt [ ] ≥2 صورة/فصل في مواضعها [ ] running summary اتسق (فحص يدوي لعدم تناقض المصطلحات) [ ] bibliography كاملة [ ] EPUB+PDF+DOCX سليمة [ ] Drive [ ] التكلفة الإجمالية موثقة.
**P6-T3 — تقرير التكلفة**: `books/{slug}/metadata.json` محدّث بكل الأرقام.

### المرحلة P7 — التوثيق (تقدير: 3 أيام)
**P7-T1**: README مخصص (تشغيل، متطلبات سيرفر CPU، troubleshooting سيركس إنجي + WeasyPrint). **P7-T2**: توثيق Extension Points (§9) + وحدة `PostProcessor` نموذجية فارغة (`contracts/postprocessor.ts` + تنفيذ stub).

---

## 7) بروتوكول نقاط التوقف (التنفيذ الصارم)

```
HaltPoint { stage, payloadJson, status: waiting|approved|revisions, feedbackJson }
```
1. عند بلوغ نقطة توقف: حفظ HaltPoint → حالة الـ pipeline تتحول → **صفر نداءات LLM** → UI تعرض payload.
2. `approved` → استئناف من الحالة التالية.
3. `revisions` + feedback → إعادة المرحلة مع الملاحظات محقونة في الـ prompt (سقف جولة واحدة قبل القبول القسري/الإلغاء — يمنع الحلقات اللانهائية).
4. إعادة تشغيل الخادم أثناء `waiting` = لا شيء ينكسر؛ الواجهة تعرض نفس نقطة التوقف.

## 8) بروتوكول معالجة الأخطاء

| الفشل | الإجراء | السقف |
|-------|---------|-------|
| JSON من GLM خاطئ | حلقة إصلاح (خطأ يُعاد للنموذج) | 1 |
| نداء GLM | retry تراجع أسي | 3 |
| بحث ويب فارغ | متابعة بأقل من الحد + تحذير في ReviewReport | — |
| توليد صورة | retry بseed جديد | 2 ثم تخطٍ بعلامة rejected |
| pandoc/WeasyPrint | fail-fast مع اللوج الكامل (لا كتاب ناقص صامت) | 0 |
| Drive | retry | 3 ثم إبقاء exports محلياً + إشعار |
| أي شيء آخر | PipelineRun note + توقف بوضوح في UI | — |

---

## 9) نقاط التوسع المستقبلية (مصممة الآن، تُبنى لاحقاً)

1. **`PostProcessor` Interface** — البوابة الموحدة لكل ما بعد الكتاب:
```ts
interface BookPostProcessor { id: string; run(book: BookPackage, options: object): Promise<Artifact>; }
```
تُسجَّل في `config/postprocessors.ts`. كل فكرة مستقبلية أدناه = وحدة واحدة بهذا العقد، **بدون تعديل** الـ pipeline الأساسي.
2. **Book DNA** — metadata.json يمتد ليشمل styleGuide + المصطلحات + قرارات الكتاب → تُعاد استخدامه كمدخل brief لأي كتاب لاحق في نفس المجال (اتساق السلاسل مجاناً).
3. **ترقية Layer 5 الأصلية**: sub-agent فصل نجح مراراً في مجال واحد → عرض "ترقية لوكيل أسلوب/تخصص دائم" — السلسلة الثانية أسرع وأرخص.
4. **Reader Twin** — وكيل يحاكي `audience` حرفياً ويقرأ كل فصل ويجيب: "أين مللت؟ أين سأتوقف؟ ما الذي لم يفهمني؟" → تغذية راجعة للمراجعة قبل الاعتماد.
5. **Market-First Mode** — الاتجاه المعاكس: وكيل يحلل استعلامات بحث حقيقية (SearXNG counts / Google Trends) ويقترح مواضيع كتب ذات طلب حقيقي ومنافسة منخفضة قبل كتابة أي شيء — حل مشكلة "كتب لن يُقرأ أحد".

## 10) خارطة الطريق (أفكار ما بعد v1)

| الأولوية | الوحدة (PostProcessor) | الأدوات مفتوحة المصدر |
|---|---|---|
| 1 | 🎙️ كتاب صوتي | Piper (سريع على CPU) أو XTTS-v2 (استنساخ صوت)، تقسيم SSML جملة-جملة |
| 2 | 📣 الحزمة التسويقية | وصف KDP، كلمات مفتاحية، 5 منشورات، فيديو ترويجي من صور الغلاف (FFmpeg) |
| 3 | 🌍 ترجمات حسب الطلب | GLM + مسرد مصطلحات من Book DNA لضمان الاتساق + مراجعة لغوية بوكيل مستقل |
| 4 | 📝 طبعة التمارين | Workbook.pdf + كويزات + بطاقات Anki/CSV |
| 5 | 🛡️ Fact-Check & Sensitivity | وكيل مدقق يفحص كل ادعاء رقمي ضد مصادره + مراجعة حساسية ثقافية/قانونية |
| 6 | 🖨️ Print-on-Demand | غلاف كامل (غلاف+كعب+غلاف خلفي) بمقاسات KDP الدقيقة |
| 7 | 📖 النسخة التفاعلية | تصدير الكتاب كتطبيق ويب Next.js مع بحث داخلي وقراءة صوتية |

## 11) قائمة تحقق القبول النهائية للمشروع v1
- [ ] كل المهام P0→P7 اجتازت معاييرها بالترتيب
- [ ] Pipeline كامل يعمل في `FORGE_MODE=mock` بلا مفاتيح
- [ ] كتاب عربي + كتاب إنجليزي كاملان في وضع live
- [ ] إعادة تشغيل الخادم في أي مرحلة = استئناف لا إعادة من الصفر
- [ ] سجل تدقيق WebMCP يوثق 100% من استدعاءات الأدوات، والتكلفة الإجمالية لكل كتاب مطبوعة في metadata.json

---
**نهاية الوثيقة** — الوكيل المنفذ يبدأ من `P0-T1` ولا يتقدم إلا بمعيار قبول مُختبَر. 🚀

هل تريد أن أعدّل أي شيء في الخطة — مثلاً تقسيم المراحل إلى وثائق منفصلة لكل Phase، أو تعديل أي من القرارات المثبتة قبل تسليمها للوكيل؟