# WealthForge UI reference package

## Precedence
1. `01_OWNER_PRIMARY_HOME.png` is the primary visual reference for the Arabic desktop home page and mentor presentation.
2. `02_SECONDARY_DESKTOP_FINANCE.jpg` provides auxiliary finance dashboard ideas only.
3. `03_SECONDARY_MOBILE_FINANCE.jpg` provides auxiliary mobile patterns only.
4. `04_OPTIONAL_GENERATED_VARIANT.png` is a generated experiment, **NOT APPROVED**, and may not supersede reference 01.

These are visual design references, not functioning implementation evidence or exact financial data requirements. Text, charts and sample financial figures are illustrative. Do not reuse apparent identifiable portraits as actual user identities.

## Implementation
Do not redesign all pages at once. First integrate into `design/approved/` (put proposal 04 instead in `design/proposed/`), update project `design/manifest.json` with hashes, build home page, capture real screenshots in AR and EN at desktop and mobile viewports, present owner comparison, and wait for approval. Preserve existing business logic, routes, data isolation and auth.

The primary image sets visual identity only; do not assume an actual 3D avatar, backend chat or voice capabilities exist.
