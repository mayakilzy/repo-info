# License decision pending
No software license is granted by this planning pack. Owner must choose the commercial or open-source licensing model before publishing implementation. Repo visibility is not the same as a license.
