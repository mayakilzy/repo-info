# AgentCraft-WealthForge

**Personal Wealth Intelligence Companion** — a proactive, evidence-grounded economic intelligence companion that helps users understand their financial position, skills, relationships, and market opportunities, then plan, act, and learn over years.

**Status:** Approved product specification and staged implementation mission pack (planning only; no application implementation has been completed).

## Start here
1. Read `docs/00-INDEX.md` and `docs/01-PRODUCT-SPEC-AR.md`.
2. Read `docs/02-ARCHITECTURE.md`, `docs/03-DATA-AND-FINANCE.md`, and `docs/04-TRUST-COST-QUALITY.md`.
3. Give GLM `GLM/MASTER-INSTRUCTIONS.md`, then only `GLM/groups/G01.md`.
4. Examine the group report against its acceptance gate before issuing the next group.
5. Never mark a group PASS without test evidence and commit identifiers.

Repository: https://github.com/mayakilzy/AgentCraft-WealthForge

> Financial insights are informational decision support, not guaranteed returns or a substitute for licensed professional advice. No automatic trade, sale, banking operation, or third-party outreach by default.
