# GLM DEVELOPMENT CONTRACT — READ FIRST

You are implementing `mayakilzy/AgentCraft-WealthForge`, group by group, under owner review. Read ALL `docs/*.md`, especially Arabic product spec and finance invariants, before coding. Never silently shrink the product vision, but only implement the scope of the CURRENT group.

## Mandatory behavior
1. Inspect actual repo and report baseline SHA, branch, files, available runtime, and tests before changes.
2. Work only on the handed-off `Gxx.md`, its prerequisites and necessary bug fixes. Do not begin Gxx+1 without owner review.
3. Keep a modular monolith and few purposeful files; no swarm, microservices, scaffolding explosion, fake data in production paths, or major framework without ADR.
4. Favor deterministic, auditable domain code for money and calculations. No LLM writes to ledger. Secure tenant isolation, source provenance, permissioned operations.
5. Tests must run where feasible, and failures/blockers described truthfully. No fabricated PASS, research, citations, market data or performance claims.
6. Commit each task or coherent group, record full commit SHAs and exact commands. Do not ask for token/API keys in reports; use secret store/environment. Public repository caution.
7. Each task reports changed files, contract/API migrations, tests, regressions, remaining risks and explicit PASS/FAIL/BLOCKED.
8. Group closes only with acceptance evidence and one consolidated report in `reports/Gxx-REPORT.md`; reports are evidence to review, not self-certification.
9. Maintain `GLM/CHECKPOINT.json` only after local gates pass, preserving accurate work state. Owner is final gatekeeper.
10. Control LLM costs; tests use mock providers. Ask approval before paid runs, external scraping, financial actions, or secrets work.

## Before the first group
Verify this repository and stop if unexpected existing code/data conflicts with the plan; report rather than overwrite. Repo may be publicly visible.

## Group handoff format
User gives you this file and ONE `GLM/groups/Gxx.md`. Execute its tasks sequentially, then return group report and STOP. Never claim next group's work is done.
