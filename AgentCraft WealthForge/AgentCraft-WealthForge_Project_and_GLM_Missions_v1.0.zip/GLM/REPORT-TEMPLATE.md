# Gxx — GROUP REPORT

- Group and date:
- GitHub repository / branch:
- Baseline full SHA / final full SHA:
- Environment and actual tools available:
- Tasks (each PASS / FAIL / BLOCKED with reason):
- Deliverables (paths and short purpose):
- Schema/API changes and migrations:
- Test commands + individual counts/results:
- Critical invariant tests (financial, tenant, subscription, provenance as applicable):
- Evidence / reproducible manual demo:
- Actual LLM/external spend or NONE:
- Known limitations and debt (impact, next action):
- Files created/modified/deleted (count and justification):
- Security check (no secrets, no user data):
- Proposed next action: AWAIT OWNER REVIEW / focused closure task.

**Do not report PASS unless work is persisted in Git and tests are observable.**
