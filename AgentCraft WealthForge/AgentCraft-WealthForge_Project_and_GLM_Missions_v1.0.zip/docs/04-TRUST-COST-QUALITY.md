# Trust, cost and quality policies

## Finance risk safeguards
No promises of wealth, certain price appreciation, safe profit or buy/sell guarantees. Do not prescribe borrowing, asset sales or investing emergency funds without risk analysis. For low liquidity, prioritize survival and safety. Show assumptions, downside, break-even, scenarios, costs, evidence freshness and next verification before suggesting trades. Sensitive investment/regulatory/tax topics require appropriately qualified guidance. Public market statistics or product rules should be sourced and dated.

## Data trust
Every extracted fact: origin, source type, timestamp, confidence, user-confirmed flag; distinguish fact/inference/third-party assertion. Consent ledger, least privilege, isolation, export/delete, redaction, secure logging, secrets only environment/secret store. Separate production financial data and synthetic demo fixtures.

## Subscription safeguards
Paid-only, 7-day low-cost PAID trial with budget and fair-use caps, no silent upgrade to full plan, explain trial charges and expiry. Server-verified payment state; no frontend trust. Token and non-token bill of materials: LLM input/output, retrieval, search/crawl, TTS/STT, avatar rendering/stream, CPU/DB/storage, messaging, provider fees, refunds, payment processing. Enforce soft warning and hard service quotas, graceful fallback. Never imply trial covers users whose resource cost exceeds price unless measured.

## Engineering quality
Required tests: deterministic unit + integration + tenant authorization + migration + web e2e smoke + finance invariants + cost caps + evidence fabrication rejection + adverse-market scenarios + subscription trial transition. Persist CI outputs and report actual commands, pass/fail, duration, commit SHA and blockers. No inflated PASS claims.

## Scope boundaries
No nonessential network scraping, no automatic purchases, transfers or outbound messages. Respect legal jurisdictions and privacy. Avoid invasive user profiling. Accessibility and Arabic RTL are first-class.
