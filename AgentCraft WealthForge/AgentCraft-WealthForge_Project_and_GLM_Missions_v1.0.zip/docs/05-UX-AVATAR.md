# UX and intelligent 3D avatar

## Mandatory navigation
Home / Financial Center / Wealth Advisor / Wealth Plan Builder / Opportunity Radar / Wealth Mentor / Abundance Energy Generator / Daily Wealth Messages; auxiliary Progress / Settings.

## Financial Center first screen
Top: Savings Fund progress (emergency, long-term, deployable buckets) and liquid cash, then assets, obligations, income/spending, operating capital, trade pipeline and Capital Journey timeline. Show valuation confidence; no mock numbers without DEMO label. Financial states: healthy, attention, emergency; no manipulative visual panic. WCAG-oriented keyboard/screenreader, color+text indicators, mobile and RTL.

## Avatar identity
Distinctive mature wise friendly 3D male character with silver hair, elegant eyeglasses, calm appearance; avoid impersonating an actual financial expert. Brand palette navy/teal/subtle gold. User-selected mode: full avatar voice, traditional chat, hybrid mini avatar overlay. Single brain/context; lip-sync; interruptions; text transcript; no compulsory microphone. Progressive enhancement: static/animated lightweight fallback if device/network constrained. Avoid expensive photoreal real-time video in MVP. Disclose AI status.

## Key screens
Onboarding with short progressively disclosed questions and skip controls; consent and finance imports; dashboard; financial journal and savings; asset valuations; opportunities (evidence/assumptions/risk/next validation); scenario comparison; plan tasks; mentorship; message preferences; subscription quotas/usage; profile corrections/export.
