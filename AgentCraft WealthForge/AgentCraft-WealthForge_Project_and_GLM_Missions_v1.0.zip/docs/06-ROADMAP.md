# Delivery roadmap — controlled GLM groups

**Workflow:** deliver one group to GLM, receive report, verify evidence/commit/tests, approve or request focused closure, then send the next group. Each group has 3–5 tasks with a narrow definition of done. Total 12 groups / 46 tasks. Group output is NOT automatically PASS because GLM says so.

| Group | Outcome | Prerequisites |
|---|---|---|
| G01 | Repository and technical choices, executable skeleton | None |
| G02 | Auth, tenant security, profile, consent | G01 |
| G03 | Financial ledger and savings | G02 |
| G04 | Assets, valuations, liabilities, cashflow, net worth | G03 |
| G05 | Trades, inventories, Capital Journey, guardrails | G04 |
| G06 | Personal capital graph, relationships and long memory | G02–G05 |
| G07 | Knowledge ingestion, evidence, market research | G06 |
| G08 | Opportunity discovery, questioning, validation | G07 |
| G09 | Planner, simulator, guardian, follow-up | G08 |
| G10 | Sidebar UX, Arabic RTL, educator and messages | G09 |
| G11 | 3D avatar voice modes, subscription and metering | G10 |
| G12 | End-to-end hardening, adversarial QA, release readiness | G11 |

**Early demo gate:** At G05, a user can track money, savings, asset disposal and a trade lifecycle without AI. **Intelligence demo gate:** At G08, a verifiable personalized opportunity is derived from actual graph/market evidence, not hardcoded prose. **Release gate:** G12 meets privacy and financial invariants with measured costs.

Schedule/tech/platform/provider remain contingent on ADR and evidence. Explicitly avoid file explosion and infra that cannot be justified by acceptance tests.
