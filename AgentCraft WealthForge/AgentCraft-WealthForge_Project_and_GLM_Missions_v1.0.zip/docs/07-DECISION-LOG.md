# Decision log

## Locked
- Product name: **AgentCraft-WealthForge**; repository `mayakilzy/AgentCraft-WealthForge`.
- Wealth discovery is the intellectual core; work + relationships + financial intelligence.
- Independent **Financial Center** in sidebar, prominent Savings Fund and Capital Journey.
- Six original sections retained, plus Home/Financial Center and auxiliary navigation.
- Wise friendly male 3D avatar, optional Chat/Avatar/Hybrid; one reasoning core.
- Paid-only; **7-day discounted paid trial**, controlled usage, no automatic surprise upgrade.
- Evidence-backed uncertainty and human authorization; no guarantee of riches.
- GLM performs development group by group; each group's report reviewed before continuation.
- Lean, modular, minimal file count; no unapproved swarm/microservices.

## Not yet locked
Exact subscription price, LLM providers, deployment region, frontend/mobile framework, audio/avatar service, persistent graph technology, bank integration, payment provider, actual market feeds. Record final selection and rationale in ADRs with measurements.

## Security observation
Repository was public when preparation began. Never store user finance, secrets, proprietary credentials or live customer content in this repo. Reconsider visibility before shipping commercial implementation.
