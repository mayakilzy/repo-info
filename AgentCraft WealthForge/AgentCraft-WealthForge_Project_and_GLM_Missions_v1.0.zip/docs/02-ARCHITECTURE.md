# Lean reference architecture v1.0 (provisional)

## Principles
Modular monolith first, vertical slices, explicit boundaries and typed contracts, deployable local stack. One reasoning core behind six services and the avatar. Avoid premature swarm, microservices, agent platform, separate graph DB, complex orchestration and broad framework generation. Respect user-approved public repository: commit no credentials or user data.

## Logical components
`web/mobile responsive UI + optional avatar` → `API/auth/billing/entitlements` → `domain services` → `data/evidence/memory`.

Domain modules: financial-ledger; savings; assets-and-liabilities; trades-and-capital-journey; personal-profile; relationships; economic-knowledge; discovery/relevance; evidence; planning/execution; mentoring/messages; model-gateway/costs; observability.

## Storage decision
Start with Postgres for normalized structured entities, pgvector if semantic retrieval proves useful, and relational edges for graph traversal. Object storage for user media. Introduce specialized graph DB only if measured queries justify it. Source of truth: deterministic finance ledger; LLM outputs cannot directly mutate balances.

## Model gateway
Provider-agnostic adapter with structured-output contracts, retries, request trace IDs, metering input/output/cached tokens and external search/TTS consumption; deterministic fake provider in CI. GLM may be the development assistant, but the product runtime provider is a separate, open decision.

## Graph & discovery
Persist typed nodes/edges with source, confidence, temporal validity, tenant scope; retrieval ranks candidate relations then LLM generates falsifiable opportunity hypotheses. Verify evidence and risks before user presentation. Disallow synthetic evidence and impossible certainty.

## User operations
All write operations authenticated and tenant-isolated; sensitive actions require explicit user confirmation. Separate background jobs for allowed notifications/refreshes. No unsolicited external outreach or transaction execution.

## Delivery
Start with one API, one web UI, one DB, a lightweight queue only if required, and a reproducible local demo. Avoid more than necessary repository files. No tech stack declared frozen until G01 ADR; use mainstream maintained frameworks.
