# Data and finance contracts v1.0

## Financial accounting invariants
1. **Never infer account balances from the LLM.** Balances are calculated from persisted transactions or explicitly valued snapshots with reconciliation metadata.
2. Every monetary amount uses decimal, ISO currency, precision and transaction date; conversions use timestamped rates and provenance; no naive cross-currency sums.
3. Journal postings obey balanced debit/credit or equivalent provable conservation; no duplicate postings on retry; corrections append reversals, not destructive edits.
4. Savings buckets are allocations of existing funds, **not additional assets**. Transfers between own accounts/buckets must not create wealth or profits.
5. Trade inventory is valued separately, with quantities, units, conversion yield, shrinkage, shipping, packaging, storage, tax/duty and gross/net margin. Unsold stock is not realized cash profit.
6. Debts owed to user = receivables (risk-weighted, not necessarily liquid); user debts = liabilities. Valuations include date, confidence and estimate range; capital gains remain unrealized until disposal.
7. Liquidity, cash flow, net worth, available operating capital, realized and unrealized P&L are separate computed metrics.
8. Confidential financial records always tenant-scoped; audit trail on changes, delete/export policy, backups and restore drills.

## Minimum entities
User, ConsentGrant, EconomicProfile, Skill, Goal, Resource, Contact, RelationshipEdge, Account, SavingsBucket, Asset, AssetValuation, Liability, Receivable, Transaction, Posting, CashFlowCategory, Trade, TradeLot, InventoryMovement, TradeCost, TradeSale, CapitalAllocation, Opportunity, OpportunityEvidence, OpportunityAssumption, MarketObservation, Experiment, Plan, Task, FollowUp, KnowledgeConcept, KnowledgeRelationship, Source, AgentRun, ModelUsage, Subscription, Trial, Entitlement, Notification.

## Capital Journey
Lineage links incoming cash (income, receivable settled, asset disposal, trade proceeds) to a transaction and permitted allocation, then to next trade investment and return. Report lineage as a **fund-flow explanation** with explicit allocation rules, avoiding claim that fungible dollars can always be uniquely identified. Reconcile allocations with double-entry source data.

## Illustrative FIG trade (not a guaranteed strategy)
Purchase 1,000 kg fresh figs at $1/kg; fresh-to-dried yield 25% (assumption) => 250 kg dried figs. If drying/packaging/labor/storage/transport sum $350, cost before selling fees = $1,350 or $5.40/kg. A quoted sale at $8/kg gives $2,000 gross proceeds and $650 margin BEFORE additional commissions/tax/duties/spoilage. Under scenarios of yields, pricing and shipping, net profit may vary or become loss. Verify food safety, regulations, seasonality and buyers before advising.

## Seasonal OLIVE-OIL hypothesis
Treat supply forecasts, demand, storage, spoilage, capital lockup and alternative returns as uncertain. Claims like "price certainly rises 40%" must be rejected and replaced with evidence-backed range of outcomes.

## Graph nodes and relations
PERSON HAS_SKILL SKILL; PERSON OWNS ASSET; PERSON KNOWS CONTACT; CONTACT WORKS_IN SECTOR; SECTOR HAS_PROBLEM PROBLEM; SOLUTION ADDRESSES PROBLEM; SKILL ENABLES SOLUTION; MARKET HAS_DEMAND SOLUTION; OPPORTUNITY REQUIRES RESOURCE; OPPORTUNITY SUPPORTED_BY SOURCE; OPPORTUNITY FITS_PROFILE PERSON. Each edge source/time/confidence/type and tenant boundaries.

## Opportunity state machine
HYPOTHESIS → NEEDS_DATA → VERIFYING → VALIDATED_FOR_TEST → EXPERIMENTING → EXECUTED / REJECTED / PAUSED. Financial recommendations are decisions support; user confirms action. Evidence freshness and contradictions affect rank.
