# WealthForge documentation map

- `01-PRODUCT-SPEC-AR.md` — authoritative Arabic product specification.
- `02-ARCHITECTURE.md` — lean target architecture and boundaries.
- `03-DATA-AND-FINANCE.md` — financial ledger, graph, opportunity and trade logic.
- `04-TRUST-COST-QUALITY.md` — privacy, financial safety, subscription costs, quality gates.
- `05-UX-AVATAR.md` — navigation, finance center, 3D mentor and accessibility.
- `06-ROADMAP.md` — build groups, dependencies and acceptance.
- `07-DECISION-LOG.md` — frozen vs open decisions.
- `08-TEST-SCENARIOS.md` — end-to-end scenario fixtures.
- `GLM/MASTER-INSTRUCTIONS.md` — immutable handoff contract.
- `GLM/groups/G01.md` ... `G12.md` — executable group missions.
- `GLM/REPORT-TEMPLATE.md` — report format.
- `GLM/CHECKPOINT.json` — initial machine-readable progress state.

Specification status: **baseline accepted, implementation choices provisional**.
