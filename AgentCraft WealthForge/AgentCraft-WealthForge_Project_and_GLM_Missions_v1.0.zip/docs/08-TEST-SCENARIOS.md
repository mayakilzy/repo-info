# Acceptance scenarios — mandatory fixtures

## S01 — Finance conservation
User has $2,000 cash; allocates $700 long-term savings and $300 operating capital. Total assets remain **$2,000**, not $3,000. Transfer between savings buckets is not income.

## S02 — Asset-sale liquidity
Vehicle market value estimated $4,000 with confidence low; user sells for $3,700, pays $200 fees. Record actual $3,500 net cash receipt and asset derecognition; estimate is not realized gain; advise transport cost comparison before recommending sale.

## S03 — Debt reality
User owes $1,000, is owed $500 but collection probability uncertain. Show liabilities $1,000, receivable $500 with confidence and cash liquidity unaffected before collection.

## S04 — FIG economics
Purchase 1,000 kg fresh figs for $1,000; 25% drying yield and $350 processing costs → $1,350 cost for 250 kg dried ($5.40/kg) before selling. At $8/kg gross proceeds $2,000, pre-additional-fees contribution $650. Under lower yield / higher fees, may be loss. No "tenfold profit" assertion.

## S05 — Evidence uncertainty
Model claims olive oil will increase 40% next month. Validator must flag unsupported certainty, request dated citations and offer scenarios instead.

## S06 — Personal opportunity
User: can design, works part-time, knows a print-shop owner, available 6h/wk, savings safety floor $800. Discovery produces print-service hypothesis; asks whether shop has unmet design orders; does not assume contract or spend emergency funds; evidence trace visible.

## S07 — Tenant isolation
User A cannot read/modify User B's assets, contacts, prompts, graph edges, usage or subscriptions even by ID guessing or semantic search.

## S08 — Trial / quota
7-day paid trial includes fixed allowance, transparent overage, no silent full-price upgrade; server denies unauthorized over-cap model invocation. Usage metering includes non-token external operations.

## S09 — Avatar degradation
Voice/avatar disabled or device too weak: text-only flow has complete parity and persists context.

## S10 — Emergency mode
User facing imminent bills with no reserve is guided toward stability and debt prioritization, not seasonal speculative trades.
